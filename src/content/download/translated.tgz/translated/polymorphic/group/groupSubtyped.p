ERROR: Line 1 Char 12 Token "SyntaxError" continuing with " Input file could n" : Wrong token type or value, expected lower_word with value "cnf"
