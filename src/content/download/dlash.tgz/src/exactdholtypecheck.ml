open Syntax
open State

let rec to_dtp a =
  if a = 0 then prop_trm
  else if is_base a then
    begin
      let n = no_basename (ty_get_no a) in
      match n with
      | "$i" -> ind_trm
      | n' -> DName(n',typ_trm)
    end
  else if is_ar a then
    let al_dtp = to_dtp (ty_get_l a) in
    let ar_dtp = to_dtp (ty_get_r a) in
    DPi(al_dtp,ar_dtp)
  else raise (Failure "to_dtp: impossible case")
  
let rec get_dtp cx m =
  match m with
  | False -> prop_trm
  | True -> prop_trm
  | Choice(_) -> raise (Failure "DHOL does not support choice")
  | Name(_,a) -> to_dtp a
  | DName(_,a) -> a
  | DB(i,_) -> shift (List.nth cx i) 0 (i+1)
  | Neg -> DPi(prop_trm,prop_trm)
  | Imp -> DPi(prop_trm,DPi(prop_trm,prop_trm))
  | And -> DPi(prop_trm,DPi(prop_trm,prop_trm))
  | Or -> DPi(prop_trm,DPi(prop_trm,prop_trm))
  | Iff -> DPi(prop_trm,DPi(prop_trm,prop_trm))
  | Exists(a) ->
     let a' = to_dtp a in
     DPi(DPi(a',prop_trm),prop_trm)
  | DExists(a) ->
     DPi(DPi(a,prop_trm),prop_trm)
  | Ap(DChoice(a),_) -> a
  | Forall(a) ->
     let a' = to_dtp a in
     DPi(DPi(a',prop_trm),prop_trm)
  | DForall(a) ->
     DPi(DPi(a,prop_trm),prop_trm)
  | Lam(a,m1) ->
     let a' = to_dtp a in
     let b = get_dtp (a'::cx) m1 in
     DPi(a',b)
  | DLam(a,m1) ->
     let b = get_dtp (a::cx) m1 in
     DPi(a,b)
  | Ap(Neg,_)
  | Ap(Ap(Imp,_),_) | Ap(Ap(And,_),_) | Ap(Ap(Or,_),_) | Ap(Ap(Iff,_),_)
  | Ap(Exists(_),_) | Ap(DExists(_),_) | Ap(Forall(_),_) | Ap(DForall(_),_) -> prop_trm
  | Ap(Ap(Eq(a),_),_) ->
     let a' = to_dtp a in
     DPi(a',DPi(a',prop_trm))
  | Ap(Ap(DEq(a),_),_) -> DPi(a,DPi(a,prop_trm))
  | Ap(m1,m2) ->
     begin
       match get_dtp cx m1 with
       | DPi(b,c) ->
          subst c 0 m2
       | _ -> raise (Failure "gen_type_constraints: impossible case 1")
     end
  | DChoice(a) -> DPi(DPi(a,prop_trm),shift a 0 1)
  | _ -> raise (Failure "gen_type_constraints: impossible case 2")
let rec gen_tcs tcx tp el al =
  match (tp,el,al) with
  | (DPi(tph,tpt),eh::et,ah::at) ->
     if eh <> ah then
     begin
       let eq =
         match tph with
         | DName(x,_) ->
            if Hashtbl.mem name_base x
            then Eq(mk_base (basename_no x))
            else if x = "_bool"
            then Eq(mk_prop)
            else raise (Failure "gen_type_constraints: impossible case 3")
         | _ -> DEq(tph)
       in
       let c = tcx (Ap(Ap(eq,eh),ah)) in
       let c' = tcx (Ap(Ap(eq,ah),eh)) in
       if List.mem c !type_constraints || List.mem c' !type_constraints
       then ()
       else type_constraints := c :: !type_constraints
     end;
     gen_tcs tcx (subst tpt 0 eh) et at
  | (tpp,[],[]) when tpp = typ_trm -> ()
  | _ -> raise (Failure "gen_type_constraints: impossible case 4")
    
let rec tc_dtp_go tcx e a =
  (* JN TODO remove if e <> a then Printf.printf "Expected: [%s] Actual: [%s]\n" (trm_str e) (trm_str a); *)
  match (e,a) with               
  | (DPi(e1,e2),DPi(a1,a2)) ->
     tc_dtp_go tcx e1 a1;
     tc_dtp_go tcx e2 a2
  | (_,_) ->
    begin
      let (eh,el) = head_spine e in
      let (_,al) = head_spine a in
      match eh with
      | DName(_,tp) -> gen_tcs tcx tp el al
      | _ -> raise (Failure "gen_type_constraints: impossible case 5")
    end

let rec tc_trm_go tcx cx m a =
  match m with
  | DB(i,_) -> tc_dtp_go tcx a (shift (List.nth cx i) 0 (i+1))
  | DName(x,b) -> tc_dtp_go tcx a b
  | Ap(Neg,m1) ->
     let tcx1 = fun h -> tcx (Ap(Neg,h)) in
     tc_trm_go tcx1 cx m1 prop_trm
  | Lam(b,m1) ->
     begin
       match a with
       | DPi(a1,a2) ->
          let b' = to_dtp b in
          let tcx1 = fun h -> tcx (forall b h) in
          tc_trm_go tcx1 (b'::cx) m1 a2
       | _ -> raise (Failure "gen_type_constraints: impossible case 6")
     end
  | DLam(n,m2) ->
     begin
       match a with
       | DPi(a1,a2) ->
          let tcx1 = fun h -> tcx (dforall n h) in
          tc_dtp_go tcx a1 n;
          tc_trm_go tcx1 (n::cx) m2 a2
       | _ -> raise (Failure "gen_type_constraints: impossible case 7")
     end
  | Ap(Ap(Imp,m1),m2) ->
     (* dependent implication *)
     let tcx2 = fun h -> tcx (Ap(Ap(Imp,m1),h)) in
     tc_trm_go tcx cx m1 prop_trm;
     tc_trm_go tcx2 cx m2 prop_trm
  | Ap(Ap(And,m1),m2) ->
     (* dependent implication *)
     let tcx2 = fun h -> tcx (Ap(Ap(Imp,m1),h)) in
     tc_trm_go tcx cx m1 prop_trm;
     tc_trm_go tcx2 cx m2 prop_trm
  | Ap(Ap(Or,m1),m2) ->
     (* dependent implication *)
     let tcx2 = fun h -> tcx (Ap(Ap(Imp,Ap(Neg,m1)),h)) in
     tc_trm_go tcx cx m1 prop_trm;
     tc_trm_go tcx2 cx m2 prop_trm
  | Ap(Ap(Iff,m1),m2) ->
     let tcx1 = fun h -> tcx (Ap(Ap(Imp,m2),h)) in
     let tcx2 = fun h -> tcx (Ap(Ap(Imp,m1),h)) in
     tc_trm_go tcx1 cx m1 prop_trm;
     tc_trm_go tcx2 cx m2 prop_trm
  | Ap(Lam(b,m1),m2) ->
     let b' = to_dtp b in
     let tcx1 = fun h -> tcx (forall b h) in
     tc_trm_go tcx1 (b'::cx) m1 a;
     tc_trm_go tcx cx m2 b'
  | Ap(DLam(n,m1),m2) ->
     let tcx1 = fun h -> tcx (dforall n h) in
     let n1 = get_dtp (n::cx) m1 in
     tc_dtp_go tcx a (subst n1 0 m2);
     tc_trm_go tcx1 (n::cx) m1 n1;
     tc_trm_go tcx cx m2 n
  | Ap(Exists(b),Lam(_,m1)) ->
     let b' = to_dtp b in
     let tcx1 = fun h -> tcx (exists b h) in
     tc_trm_go tcx1 (b'::cx) m1 prop_trm
  | Ap(DExists(n),DLam(n',m1)) ->
     let tcx1 = fun h -> tcx (dexists n h) in
     tc_dtp_go tcx n n';
     tc_trm_go tcx1 (n::cx) m1 prop_trm
  | Ap(Forall(b),Lam(_,m1)) ->
     let b' = to_dtp b in
     let tcx1 = fun h -> tcx (forall b h) in
     tc_trm_go tcx1 (b'::cx) m1 prop_trm
  | Ap(DForall(n),DLam(n',m1)) ->
     let tcx1 = fun h -> tcx (dforall n h) in
     tc_dtp_go tcx n n';
     tc_trm_go tcx1 (n::cx) m1 prop_trm
  | Ap(Ap(Eq(b),m1),m2) ->
     tc_trm_go tcx cx m1 (to_dtp b);
     tc_trm_go tcx cx m2 (to_dtp b)
  | Ap(Ap(DEq(n),m1),m2) ->
     tc_trm_go tcx cx m1 n;
     tc_trm_go tcx cx m2 n
  | Ap(DChoice(n),DLam(n',m1)) ->
     let tcx1 = fun h -> tcx (dforall n h) in
     tc_dtp_go tcx n n';
     tc_trm_go tcx1 (n::cx) m1 prop_trm;
     let c =
       if !dchoice_weak
       then tcx (Ap(DExists(n),DLam(n,True)))
       else tcx (Ap(DExists(n),DLam(n,m1)))
     in
     if List.mem c !type_constraints
     then ()
     else type_constraints := c :: !type_constraints
  | Ap(m1,m2) ->
     begin
       match get_dtp cx m1 with
       | DPi(b,c) ->
          let c_applied = subst c 0 m2 in
          tc_dtp_go tcx a c_applied; 
          tc_trm_go tcx cx m1 (DPi(b,c));
          tc_trm_go tcx cx m2 b
       | _ -> raise (Failure "gen_type_constraints: impossible case 8")
     end
  | _ -> ()

let gen_type_constraints (m,a) = tc_trm_go (fun h -> h) [] m a

let rec apply_imp_directly m =
  match m with
  | Ap(Ap(Lam(_,Lam(_,Ap(Ap(Imp,x),y))),m1),m2) -> 
     Ap(Ap(Imp,apply_imp_directly m1),apply_imp_directly m2)
  | Lam(a1,m1) ->
     Lam(a1,apply_imp_directly m1)
  | DLam(n1,m1) ->
     DLam(n1,apply_imp_directly m1)
  | Ap(m1,m2) ->
     Ap(apply_imp_directly m1,apply_imp_directly m2)
  | _ -> m

let get_terms_and_dtypes pis =
  let combine ms pi =
    match pi with
    | ProbDef(_,a,m,_,_) ->
       begin
         match a with
         | DTp(aa) -> (apply_imp_directly m,aa) :: ms
         | STp(aa) -> (apply_imp_directly m,to_dtp aa) :: ms
       end
    | ProbAx(_,_,m,_,_) -> (apply_imp_directly m,prop_trm) :: ms
    | ProbConj(_,m,_,_) -> (apply_imp_directly m,prop_trm) :: ms
  in
  List.fold_left combine [] pis
