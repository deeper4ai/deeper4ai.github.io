open Syntax
open State
val get_terms_and_dtypes: probitem list -> (trm * trm) list
val gen_type_constraints: (trm * trm) -> unit
