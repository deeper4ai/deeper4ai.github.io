#!/bin/bash
for prob in ../dhol_examples/dhol_test_*.p
do
   echo "Problem $prob" 
  ./lash "$prob" -m ../modes/erasure_eq
  ./lash "$prob" -m ../modes/erasure_eq_istai
  ./lash "$prob" -m ../modes/erasure_symtrans
  ./lash "$prob" -m ../modes/erasure_symtrans_istai
  ./lash "$prob" -m ../modes/dhol_rules
  ./lash "$prob" -m ../modes/dhol_rules_istai
done
