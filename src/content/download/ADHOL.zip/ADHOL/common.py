from math import log10
from time import perf_counter_ns
from typing import Generator
max_fresh_symbol : int = 0

SECONDS 		= 1_000_000_000
MILLISECONDS 	= 1_000_000

debug_print_on = True
def dbp(*s):
	if debug_print_on:
		print(*s)

def fmt_ns(ns : int, bar_scale : float = 1.0):
	time_string = f"{ns//1_000_000}ms"
	return f"{time_string:>10}|{"-" * (int(bar_scale * ns) // (10 * MILLISECONDS))}"

def reset_fresh_symbol():
	global max_fresh_symbol
	max_fresh_symbol = 0

def next_fresh_symbol(type : int = 0) -> str:
	global max_fresh_symbol
	max_fresh_symbol += 1
	return "N" + str(max_fresh_symbol)

from datatypes import *
from random import randint

class Unifier(dict):
	def __str__(self):
		s = "{"
		for key,value in self.items():
			s += "(" + f"{str(key)} ↦ {str(value)}" + "), "
		return s + "}"
	
	def composed(self, old_unifier : Unifier):
		new_unifier = Unifier()
		for other_key in old_unifier.keys():
			for u in self.keys:
				if not isinstance(self[u], (Term, str)):
					raise TypeError
				new_unifier[other_key] = substituted(u, self[u], old_unifier[other_key])
		for u in self.keys():
			if old_unifier.get(u, None) == None:
				old_unifier[u] = self[u]
		return new_unifier
	
	def applied(self, term):
		ret = copy_term(term)
		for k in self.keys():
			if not isinstance(self[k], (Term, str)):
				raise TypeError
			ret = substituted(k, self[k], ret)
		return ret


def fast_applied_unifier(term : Term, unifier : Unifier, with_types : bool = True):
	if isinstance(term, str):
		return unifier.get(term, term)
	if isinstance(term, App):
		return App(fast_applied_unifier(term.operator, unifier, with_types), fast_applied_unifier(term.operand, unifier, with_types))
	if isinstance(term, Quantifier):
		if term.var in unifier:
			var = next_fresh_symbol()
			body = fast_applied_unifier(term.body, {term.var : var}, with_types)
		else:
			var = term.var
			body = term.body
		return term.__class__(var, fast_applied_unifier(term.var_type, unifier, with_types) if with_types else term.var_type, fast_applied_unifier(body, unifier, with_types))
	if isinstance(term, Literal):
		return Literal(fast_applied_unifier(term.term, unifier, with_types), term.pol)
	if isinstance(term, list):
		return [fast_applied_unifier(c, unifier, with_types) for c in term]
	if isinstance(term, tuple):
		return tuple(fast_applied_unifier(c, unifier, with_types) for c in term)
	raise TypeError(f"{term}, {type(term)}")


def applied_unifier(term : Term, unifier : Unifier):
	for k,v in unifier.items():
		term = substituted(k, v, term)
	return term

def combine_unifiers(unif0 : Unifier, unif1 : Unifier) -> Unifier | None:
	unif = unif1.composed(Unifier(unif0.copy()))
	for k,v in unif1.items():
		if u := unif.get(k, None) != None:
			return None # TODO: allow combination? if aeq in context
		if not isinstance(v, (Term, str)):
			raise TypeError
		unif[k] = v
	return unif

def combine_unifier_list(unifs : list[Unifier]) -> Unifier | None:
	unif = Unifier()
	for u in unifs:
		unif = combine_unifiers(unif, u)
	return unif

def ctx_substituted(ctx : Ctx, sub : Subs) -> Ctx:
	return [tuple(sub.applied(n) for n in tup) for tup in ctx]

class Subs(Ctx):
	def applied(self, to : Term) -> Term:
		for pair in self:
			to = substituted(pair[0], pair[1], to)
		return to
	
	def comp(self, rhs : Subs) -> Subs:
		if not isinstance(rhs, Subs):
			raise TypeError(rhs)
		return Subs(ctx_substituted(self, rhs))
	
	def __str__(self):
		s = "{"
		for p0, p1 in self:
			s += f"[{p0} -> {p1}], "
		else:
			if len(s) > 2:
				s = s[:-2]
		return s + "}"

class Eqns(Ctx):
	def __str__(self):
		s = "["
		for pair in self:
			s += f"({pair[0]}=={pair[1]}), "
		return s + "]"
	
def removed(self : Eqns, idx):
	return self[:idx] + self[idx+1:]


def substituted(replacing : str, replacement : Term, formula : Term) -> Term:
	if isinstance(formula, str):
		if formula == replacing:
			return replacement
		return formula
	elif isinstance(formula, App):
		return App(substituted(replacing, replacement, formula.operator), substituted(replacing, replacement, formula.operand))
	elif isinstance(formula, Quantifier):
		vartype = formula.var_type
		if vartype != None:
			vartype = substituted(replacing, replacement, formula.var_type)

		if formula.var == replacing or formula.var == replacement:
			new_symbol = next_fresh_symbol()
			if formula.var == replacement:
				return formula.__class__(new_symbol, vartype, substituted(replacing, replacement, substituted(formula.var, new_symbol, formula.body)))
			return formula.__class__(new_symbol, vartype, substituted(formula.var, new_symbol, formula.body))
		else:
			return formula.__class__(formula.var, vartype, substituted(replacing, replacement, formula.body))
	if isinstance(formula, list):
		return list([substituted(replacing, replacement, f) for f in formula])
	if isinstance(formula, tuple):
		return tuple(substituted(replacing, replacement, f) for f in formula)
	if isinstance(formula, Literal):
		return Literal(substituted(replacing, replacement, formula.term), formula.pol)
	raise ValueError(str(formula), type(formula))


def copy_term(term : Term) -> Term:
	if isinstance(term, str):
		return term
	elif isinstance(term, App):
		return App(copy_term(term.operator), copy_term(term.operand))
	elif isinstance(term, Quantifier):
		return term.__class__(term.var, copy_term(term.var_type), copy_term(term.body))
	elif isinstance(term, Literal):
		return Literal(copy_term(term.term), term.pol)
	elif term == None:
		return None
	else:
		raise ValueError("Cases not exhaustive in term copy, formula=", term)
	

def free_variables(term, binding : list[tuple], include_types : bool = False) -> set[str]:
	if isinstance(term, Quantifier):
		if include_types:
			return free_variables(term.body, binding + [(term.var, "B")], include_types) | free_variables(term.var_type, binding, include_types)
		return free_variables(term.body, binding + [(term.var, "B")], include_types)
	elif isinstance(term, App):
		return free_variables(term.operator, binding) | free_variables(term.operand, binding)
	elif isinstance(term, str):
		for b in binding:
			if b[0] == term:
				return set()
		return {term}
	elif isinstance(term, Literal):
		return free_variables(term.term, binding, include_types)
	elif hasattr(term, "__iter__"): # Match-all case for any containers like CNF, unifiers, eqns...
		s = set()
		for l in term:
			s |= free_variables(l, binding, include_types)
		return s
	else:
		raise ValueError(f"Not a valid formula : {term} (type={type(term)}")
	

## Helpers
def AND(formula1, formula2):
	return _binop("and", formula1, formula2)
def OR(formula1, formula2):
	return _binop("or", formula1, formula2)
def IMPL(formula1, formula2):
	return _binop("impl", formula1, formula2)
def NOT(formula1):
	return App("not", formula1)
def _binop(op, formula1, formula2):
	return App(App(op, formula1),formula2)

def EQ(typeof, term1, term2):
	return long_app("EQ", typeof, term1, term2)

def beta_reduced(formula) -> Term:
	if isinstance(formula, CNF) or isinstance(formula, Clause):
		return list(map(beta_reduced, formula))
	elif isinstance(formula, Literal):
		return Literal(beta_reduced(formula.term), formula.pol)
	
	if isinstance(formula, App):
		if isinstance(formula.operator, Abs):
			return substituted(formula.operator.var, formula.operand, formula.operator.body)
		return App(beta_reduced(formula.operator), beta_reduced(formula.operand))
	elif isinstance(formula, Quantifier):
		return formula.__class__(formula.var, formula.var_type, beta_reduced(formula.body))
	elif isinstance(formula, str):
		return formula

def substitute_inplace(replacing : str, replacement : Term, formula : Term, yes_even_types : bool = False) -> None:
	if isinstance(formula, str):
		return
	
	if isinstance(formula, App):

		if isinstance(formula.operator, str) and formula.operator == replacing:
			formula.operator = replacement
		if isinstance(formula.operand, str) and formula.operand == replacing:
			formula.operand = replacement

		substitute_inplace(replacing, replacement, formula.operator, yes_even_types)
		substitute_inplace(replacing, replacement, formula.operand, yes_even_types)

	if isinstance(formula, Quantifier):
		# First, check for collision and rename the inner part if there is one 
		if formula.var == replacing:
			formula.var = next_fresh_symbol()
			substitute_inplace(replacing, formula.var, formula, yes_even_types)

		if yes_even_types:
			if isinstance(formula.var_type, str):
				if formula.var_type == replacing:
					formula.var_type = next_fresh_symbol(1)
			else:
				substitute_inplace(replacing, replacement, formula.var_type, yes_even_types)

		if isinstance(formula.body, str) and formula.body == replacing:
			formula.body = replacement

		substitute_inplace(replacing, replacement, formula.body, yes_even_types)
	

# Note that this cannot beta-reduce a TOP-level redex because of reference semantics-- this will need to be done another way
def beta_reduce_inplace(formula : Term) -> bool:
	changed = False

	if isinstance(formula, str):

		return False
	
	if isinstance(formula, Quantifier):

		while isinstance(formula.body, App) and  isinstance(formula.body.operator, Abs):
			substitute_inplace(formula.body.operator.var, formula.body.operand, formula.body.operator.body)
			formula.body = formula.body.operator.body
			changed = True

		return beta_reduce_inplace(formula.body) or changed
	
	if isinstance(formula, App):

		while isinstance(formula.operator, App) and isinstance(formula.operator.operator, Abs):

			if isinstance(formula.operator.operator.body, str) and formula.operator.operator.body == formula.operator.operator.var:
				formula.operator.operator.body = formula.operator.operand

			substitute_inplace(formula.operator.operator.var, formula.operator.operand, formula.operator.operator.body)
			formula.operator = formula.operator.operator.body
			changed = True

		while isinstance(formula.operand, App) and isinstance(formula.operand.operator, Abs):

			if isinstance(formula.operand.operator.body, str) and formula.operand.operator.body == formula.operand.operator.var:
				formula.operand.operator.body = formula.operand.operand

			substitute_inplace(formula.operand.operator.var, formula.operand.operand, formula.operand.operator.body)
			formula.operand = formula.operand.operator.body
			changed = True

		r1 = beta_reduce_inplace(formula.operator)
		r2 = beta_reduce_inplace(formula.operand)
		return r1 or r2 or changed



def random_type_symbol() -> str:
	return chr(ord('A') + randint(0, 25))

def random_symbol() -> str:
	return chr(ord('a') + randint(0, 25))

def random_theory(num_entries : int, dhol_type_complexity : int = 2) -> list[tuple]:
	th = []
	for i in range(0, num_entries):
		th.append((random_symbol(), random_dhol_type(dhol_type_complexity)))
	return th

def random_dhol_type(n : int, binding = []) -> Pi:
	if n == 0:
		return random_type_symbol()
	else:
		symbol = random_symbol()
		typ = random_type_symbol()

		return Pi(symbol, typ, random_dhol_type(n-1, binding + [(symbol, typ)]))

def random_term(n : int, allow_loose_abstractions : bool = False) -> Term:
	if n == 0:
		return random_symbol()
	subformulas = [
		lambda : App(random_term(n-1), random_term(n-1)),
		lambda : App(Abs(random_symbol(), random_type_symbol(), random_term(n-1)),random_term(n-1)),
		# lambda : OR(random_term(n-1), random_term(n-1)),
		# lambda : NOT(random_term(n-1))
	]
	if allow_loose_abstractions:
		subformulas.extend([
			lambda : Abs(random_symbol(), random_type_symbol(), random_term(n-1))
		])
	return subformulas[randint(0,len(subformulas) - 1)]()

def flatten_bnf_abstraction(term : Term) -> tuple[Ctx, Term, list[Term]]:
	if isinstance(term, (Abs, Pi)):
		binding, head, args = flatten_bnf_abstraction(term.body)
		return binding + [(term.var, term.var_type)], head, args
	if isinstance(term, App):
		binding, head, args = flatten_bnf_abstraction(term.operator)
		return binding, head, args + term.operand
	if isinstance(term, str):
		return [], term, []


def return_type(typ : Term, ctx : Ctx = Ctx()) -> Term:
	if isinstance(typ, Pi):
		return return_type(typ.body, ctx + [(typ.var,typ.var_type)])
	else:
		for c0, c1 in ctx:
			typ = substituted(c0, c1, typ)
		return typ


# A genius function which accepts an associative list (s:t) and a dictionary (t:ss) and yields possible all well-typed substitutions of s -> ss
def type_combinations(l1_var_types : list[tuple], l2_bins : dict, timeout : int = -1, from_idx : int = 0, allow_unmatched : bool = False) -> Generator[dict, None, None]:
	if from_idx >= len(l1_var_types):
		yield {}
		return
	l1 = l1_var_types[from_idx]

	got = l2_bins.get(l1[1],[])
	if not got:
		return

	for bb in got:
		for com in type_combinations(l1_var_types, l2_bins, timeout, from_idx + 1):
			com[l1[0]] = bb
			yield com
			if timeout != -1 and perf_counter_ns() > timeout:
				return