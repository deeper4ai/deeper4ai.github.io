from typing import Generator

from hol import *
from datatypes import *
from flat_term import *
from random import shuffle

DEBUG_PREUNIFICATION = 0
def dbp(s, recursion_depth : int, force : bool = False):
	(force or DEBUG_PREUNIFICATION) and print(('    '*recursion_depth) + s)
RECR_LIMIT = 50
SIG = None

class LHNFError(Exception): pass

def set_sig(sig : Sig):
	global SIG ; SIG = sig

def lhnf(any_term, binding_ctx : Ctx, global_ctx : Ctx, iter_limit : int = 100) -> FlatTerm:
	if isinstance(any_term, Term):
		flat_term = flatten(beta_reduce_repeatedly(any_term))
	elif isinstance(any_term, FlatTerm):
		flat_term = any_term
	elif isinstance(any_term, str):
		flat_term = FlatTerm([], any_term, [])

	ct_type = flatten(get_from_context(SIG, global_ctx + binding_ctx + flat_term.quantifiers, flat_term.head), True)
	if ct_type == None:
		print(f"Failed to get type of head {flat_term.head} of term {flat_term} in gctx = {Ctx(global_ctx)}, bctx = {Ctx(binding_ctx)}, sig = {SIG.constants} ")
		print(f"Sig id = {id(SIG)}")
		raise LHNFError(flat_term)

	eta_expansion = [(q0 if q0 else SIG.next_bound(), q1) for q0, q1 in ct_type.quantifiers[len(flat_term.arguments):]]

	ret = FlatTerm(
		[(c[0], lhnf(c[1], binding_ctx, global_ctx)) for c in flat_term.quantifiers] + eta_expansion,
		flat_term.head,
		flat_term.arguments + [flatten(q0) for q0,_ in eta_expansion]
	)
	return ret

def lhnf_eqns(eqns : Eqns, b : Ctx, g : Ctx):
	return Eqns([(lhnf(e[0], b, g), lhnf(e[1], b, g)) for e in eqns])

unif_idx = 0
class UnifProblem():
	ctx	 	: Ctx
	subs	: Unifier
	dag	 	: Eqns
	matching: bool 		= False
	unif_id : int 		= 0

	def __init__(self, ctx, subs, dag, matching:bool = False):
		self.ctx = ctx ; self.subs = subs ; self.dag = dag ; self.matching = matching
		global unif_idx
		self.unif_id = unif_idx + 1
		unif_idx += 1 

	def is_solved(self, constants : set):
		return not any(d[0] in constants for d in self.dag)
	
	def __str__(self):
		return f"Unif{self.unif_id}:({Unifier(self.subs)})[{Eqns(self.dag)}]"

	def dag_extended(self, d : Eqns):
		return UnifProblem(self.ctx, self.subs, self.dag + d)
	
	def dag_popped(self):
		return UnifProblem(self.ctx, self.subs, self.dag[:-1])
	
	def validate(self):
		try:
			trying = "ctx"
			for c in self.ctx:
				assert isinstance(c[0], str) and isinstance(c[1], FlatTerm), c
				c[1].validate()
			trying = "subs"
			for s in self.subs.keys():
				assert isinstance(s, str) and isinstance(self.subs[s], FlatTerm)
				self.subs[s].validate()
			trying = "dag"
			for e0,e1 in self.dag:
				assert isinstance(e0, FlatTerm) and isinstance(e1, FlatTerm)
				e0.validate() ; e1.validate()
		except Exception as a:
			print(f"UnifProblem {self.unif_id} had type error ({trying}) with ctx={Ctx(self.ctx)}, subs={Unifier(self.subs)}, dag={Eqns(self.dag)}")
			raise a

def _r(binding : Ctx, type1 : FlatTerm, type2 : FlatTerm, depth : int = 0) -> Eqns | None:
	dbp(f"Performing _r on types {type1}, {type2}", depth)
	if depth > 100:
		dbp(f"R: depth limit 100 reached", depth)
		return None
	if len(type1.arguments) != len(type2.arguments) or len(type1.quantifiers) != len(type2.quantifiers):
		dbp(f"Failed to R-unify {type1}, {type2} because they had different structures")
		return None

	if (len(type1.arguments) + len(type1.quantifiers) == 0):
		return Eqns()
	
	elif (len(type1.quantifiers) == 0):
		return Eqns(_r(binding, last_argument_removed(type1), last_argument_removed(type2)) + [(
			quantified_by_context(type1.arguments[-1], binding),
			quantified_by_context(type2.arguments[-1], binding),
		)])
	
	else:
		lhs = Eqns(_r(binding, type1.quantifiers[0][1], type2.quantifiers[0][1]))
		lhs.extend(_r(binding + [(type1.quantifiers[0][0], type1.quantifiers[0][1])], 
				first_quantifier_removed(type1), 
				flat_substituted({type2.quantifiers[0][0]: type1.quantifiers[0][0]}, first_quantifier_removed(type2))
		))
		return Eqns(lhs)

def lhnf_is_rigid(t : FlatTerm, sig : Sig):
	return (get_from_context(sig, [], t.head) != None) or (any(q[0] == t.head for q in t.quantifiers))

def pair_awt(term1 : FlatTerm, term2 : FlatTerm):
	if len(term1.quantifiers) != len(term2.quantifiers):
		dbp(f"Terms are not AWT, quantifiers do not match", 0)
		return False
	if len(term1.arguments) != len(term2.arguments):
		dbp(f"Terms are not AWT, args do not match", 0)
		return False
	# This is not up to alpha-equality, and not contextualised, because there should be no dependency in the types
	for i in range(len(term1.quantifiers)):
		if not flat_aeq(approximate_type(term1.quantifiers[i][1]), approximate_type(term2.quantifiers[i][1])):
			dbp(f"HEY! Terms are not approximately well-typed. LHS was {term1.quantifiers[i][1]} ({type(term1.quantifiers[i][1])}) and RHS was {term2.quantifiers[i][1]} ({type(term2.quantifiers[i][1])})", 0)
			return False
	
	return True
	
def is_flex_flex(term1 : FlatTerm, term2 : FlatTerm, sig : Sig):
	return not (lhnf_is_rigid(term1, sig) or lhnf_is_rigid(term2, sig))

def is_rigid_rigid(term1 : FlatTerm, term2 : FlatTerm, sig : Sig):
	return lhnf_is_rigid(term1, sig) and lhnf_is_rigid(term2, sig)

def is_flex_rigid(term1 : FlatTerm, term2 : FlatTerm, sig : Sig):
	return (not lhnf_is_rigid(term1, sig)) and lhnf_is_rigid(term2, sig)


def unify_eqns(ctx : Ctx, sig : Sig, eqn_list : Eqns, loud : bool = True, one_only : bool = False) -> Generator[tuple[Ctx, Unifier], None, None]:
	global DEBUG_PREUNIFICATION ; DEBUG_PREUNIFICATION = loud
	global SIG ; SIG = sig
	ctx = [(c[0], flatten(c[1])) for c in ctx]
	for u in generate_solutions(UnifProblem(ctx, Unifier(), [(lhnf(e[0], [], ctx), lhnf(e[1], [], ctx)) for e in eqn_list]), 0):
		yield unflatten_ctx(ctx), Unifier({uk : unflatten(uv) for uk,uv in u.items()})
		if one_only:
			return

def unify_flat_pair(ctx : Ctx, sig : Sig, start_eqn : tuple, loud : bool = False, match : bool = False):
	global DEBUG_PREUNIFICATION ; DEBUG_PREUNIFICATION = loud
	global SIG ; SIG = sig
	start_eqn = tuple(lhnf(e, [], ctx) for e in start_eqn)
	for u in generate_solutions(UnifProblem(ctx, Unifier(), [start_eqn], match), 0):
		yield Ctx([(v0, flatten(v1)) for v0, v1 in ctx]), u

def occurs(unif : Unifier, up : UnifProblem) -> bool:
	for k in unif.keys():
		if k in free_variables(unflatten(unif[k]), [(c[0], unflatten(c[1])) for c in up.ctx if SIG.constants.get(c[0], False) != False], True):
			return True
	return False

def generate_solutions(problem : UnifProblem, recr : int) -> Generator[Unifier, None, None]:
	if recr > RECR_LIMIT:
		dbp(f"generate_solutions: hit recr limit ({RECR_LIMIT})", recr)
		return
	
	dbp(f"generate_solutions: generating for unif problem {Eqns(problem.dag)} ({len(problem.dag)} terms)", recr)
	problem.validate()

	strategy = 1

	if strategy == 0:
		for u in generate_solutions_horizontal(problem, recr):
			dbp(f"generate_solutions: got {Unifier(u)}", recr)
			yield u
	
	if strategy == 1:
		for u in generate_solutions_vertical(problem, recr):
			dbp(f"generate_solutions: got {Unifier(u)}", recr)
			yield u


def generate_solutions_vertical(problem : UnifProblem, recr : int) -> Generator[Unifier, None, None]:
	if len(problem.dag) == 0:
		dbp(f"generate_solutions_vertical: dag empty, returning empty unifier", recr)
		yield {}
		return
	
	rem = removed(problem.dag, 0)
	for u in pair_solutions(problem.dag[0][0], problem.dag[0][1], UnifProblem(problem.ctx, {}, [], problem.matching), recr+1):
		dbp(f"generate_solutions_vertical: got u = {Unifier(u)}", recr)
		if len(problem.dag) == 1:
			yield u
			continue
		dbp(f"generate_solutions_vertical: applying u to rest of DAG... ({len(rem)} terms)", recr)

		for v in generate_solutions(UnifProblem(problem.ctx, {}, applied_to_eqns(rem, u), problem.matching), recr+1):
			res = composed_flat_unifiers(u, v)
			dbp(f"generate_solutions_vertical: got v = {Unifier(v)}, finalised = {Unifier(res)}", recr)
			yield res
			# for w in pair_solutions(applied_flat_unifier(problem.dag[0][0], res), applied_flat_unifier(problem.dag[0][1], res), UnifProblem(problem.ctx, {}, []), recr+1):
			# 	if w == {}:
			# 		yield res
			# 		break
			# 	else:
			# 		dbp(f"generate_solutions_vertical: unifier {res} does NOT unify head pair. Must recompose and continue", recr)


 
def generate_solutions_horizontal(problem : UnifProblem, recr : int) -> Generator[Unifier, None, None]:
	raise TabError # Bar's closed. 

# Apply SIMPL, MATCH etc. 
def pair_solutions(s : FlatTerm, t : FlatTerm, up : UnifProblem, recr : int) -> Generator[Unifier, None, None]:
	#s = lhnf(beta_reduce_repeatedly(unflatten(s)), [], up.ctx) ; t = lhnf(beta_reduce_repeatedly(unflatten(t)), [], up.ctx)
	up.validate() ; s.validate() ; t.validate() ; (type_check(unflatten(f), [], up.ctx, True) for f in (s,t))
	s = lhnf(s, [], up.ctx)
	t = lhnf(t, [], up.ctx)

	# ATP, we can identify pattern fragments and send them off to nipkow
	dbp(f"pair_solutions: solving {s}=={t}", recr)
	dbp(f"pair_solutions: s_type = {flat_type_check_native(s, SIG, up.ctx, [], recr)[0]}", recr)
	dbp(f"pair_solutions: t_type = {flat_type_check_native(t, SIG, up.ctx, [], recr)[0]}", recr)
	# Can do a short-circuit operation here based on aeq to reduce recursion depth

	if is_rigid_rigid(s, t, SIG):
		dbp(f"pair_solutions: rigid-rigid, running SIMPL...", recr)
		for u in SIMPL(s, t, up, recr=recr):
			yield u
		return
	
	elif is_flex_flex(s, t, SIG):
		# Wary of this being theoretically sound for a matching
		#print(f"flex-flex ''unifier'': {s} -> {t}")
		yield {s:t}
		# for u in PATTERN(s, t, up, recr):
		# 	if u != None:
		# 		yield u
		return
	
	elif is_flex_rigid(t, s, SIG) and not up.matching: # If matching, skip
		dbp(f"pair_solutions: rigid-flex, orienting", recr)
		tmp = t ; t = s ; s = tmp
	
	if is_flex_rigid(s, t, SIG):
		dbp(f"pair_solutions: flex-rigid, running MATCH...", recr)
		for u in MATCH(s, t, up, recr=recr):
			yield u
		return
	
	raise ValueError(s, t)

def SIMPL(s : FlatTerm, t : FlatTerm, up : UnifProblem, recr : int) -> Generator[Unifier, None, None]:
	up.validate() ; s.validate() ; t.validate() ; (type_check(unflatten(f), [], up.ctx, True) for f in (s,t))

	dbp(f"SIMPL: solving {s}=={t}", recr)

	if s.head != t.head:
		dbp(f"SIMPL: rigid heads did not match", recr)
		return 
	if not pair_awt(s,t):
		raise LHNFError(f"{s}, {t} not AWT; up was {up}")
	
	# This is < ^M_i, ^M'_i > for 1 ≤ i ≤ m 
	eqs = Eqns([(FlatTerm(s.quantifiers + s.arguments[a].quantifiers, s.arguments[a].head, s.arguments[a].arguments), FlatTerm(t.quantifiers + t.arguments[a].quantifiers, t.arguments[a].head, t.arguments[a].arguments)) for a in range(len(s.arguments))])

	# This DAG is the above, union D' (where D == D' u <M,M'>)
	for u in generate_solutions(UnifProblem(up.ctx, {}, eqs + up.dag, up.matching), recr=recr+1):
		dbp(f"SIMPL: problem {s}, {t} is solved", recr)
		dbp(f"SIMPL: yielding {u}", recr)
		yield u
	
	dbp(f"SIMPL: unifiers exhausted", recr)
	

# Basically very similar to nipkow.MATCH()
def MATCH(s : FlatTerm, t : FlatTerm, up : UnifProblem, recr : int) -> Generator[Unifier, None, None]:
	up.validate() ; s.validate() ; t.validate() ; (type_check(unflatten(f), [], up.ctx, True) for f in (s,t))

	dbp(f"MATCH: solving {s}=={t}", recr)

	for imit,pj in _match(s, t, up.ctx, [], recr):
		dbp(f"MATCH: unifier was {pj}", recr)
		type_dag = []
		if not imit:
			type_dag = disagreeing_types(s, pj[s.head], up.ctx, recr)
			dbp(f"MATCH: type_dag was {Eqns(type_dag)}", recr)
			if type_dag == None:
				dbp(f"MATCH: type dag undefined, continuing", recr)
				continue
		augment_dtypes(pj, up.ctx, recr)
		reunif = generate_solutions(UnifProblem(up.ctx, {}, applied_to_eqns([(s,t)] + up.dag, pj) + type_dag, up.matching), recr+1)
		for u in reunif:
			comp = composed_flat_unifiers(pj, u)
			dbp(f"MATCH: problem {s}, {t} is solved", recr)
			dbp(f"MATCH: yielding {comp}", recr)
			yield comp
	
	dbp(f"MATCH: unifiers exhausted", recr)

def _match(s, t, c, b, r) -> Generator[tuple[bool,Unifier], None, None]:
	for u in imitate.__call__(s, t, c, b, r if DEBUG_PREUNIFICATION else -1):
		yield True,u
	for u in project.__call__(s, t, c, b, r if DEBUG_PREUNIFICATION else -1):
		yield False,u

def project(s : FlatTerm, t : FlatTerm, ctx : Ctx, bctx : Ctx, recr : int = -1) -> Generator[Unifier, None, None]:
	db = lambda st : True and dbp(st,recr)
	bctx = bctx + s.quantifiers
	db(f"PROJ: projecting {s} for {t}")
	flat_head_type,obs = flat_type_check_native(s.head, SIG, ctx, bctx+s.quantifiers, recr)
	if flat_head_type == None or len(obs) > 0:
		db(f"PROJ: flat head type was invalid or had obligations = {obs}")
		return
	
	db(f"PROJ: Flat head type of {s} is {flat_head_type}")

	for arg in flat_head_type.quantifiers:
		flat_arg_type = flatten(arg[1])
		db(f"PROJ: Flat arg type = {flat_arg_type}")
		dqf_arg = FlatTerm([], flat_arg_type.head, flat_arg_type.arguments)
		dqf_head = FlatTerm([], flat_head_type.head, flat_head_type.arguments)
		if flat_aeq(dqf_arg, dqf_head):
			
			body = FlatTerm(flat_head_type.quantifiers, arg[0], [])

			for sigma_type, _ in flat_arg_type.quantifiers:
				body.arguments.append(FlatTerm([], 'p'+SIG.next_huet(), [flatten(qf[0]) for qf in flat_head_type.quantifiers]))
				ctx.append((body.arguments[-1].head, flat_head_type.quantifiers + [(SIG.next_bound(), sigma_type)]))
			
			u = Unifier({s.head : body})
			db(f"PROJ: yielding {u}")
			if occurs(u):
				db(f"PROJ: occurs, invalid")
				continue
			yield u
		else:
			db(f"PROJ: not compatible between arg type {dqf_arg} and {dqf_head}")
	

def imitate(s : FlatTerm, t : FlatTerm, ctx : Ctx, bctx : Ctx, recr : int = -1) -> Generator[Unifier, None, None]:
	db = lambda st : True and dbp(st,recr)
	db(f"IMIT: doing imit for {s}, {t}")

	if t.head not in SIG.constants:
		return

	body = FlatTerm([], t.head, [])
	for subarg in s.arguments: 
		t_type, obs = flat_type_check_native(subarg, SIG, ctx, bctx+s.quantifiers, recr)
		if t_type == None or len(obs) > 0:
			db(f"IMIT: Type of {subarg} was not determinable without obligations. To continue, solve the equations = {obs}")
			return
		body.quantifiers.append((SIG.next_bound(), t_type))

	for t_arg in t.arguments:
		t_type, obs = flat_type_check_native(t_arg, SIG, ctx, bctx+t.quantifiers, recr)
		db(f"IMIT: s={s}")
		db(f"IMIT: t={t}")
		if t_type == None or len(obs) > 0:
			db(f"IMIT: Type of {t_arg} was not determinable without obligations. To continue, solve the equations = {obs}")
			return
		
		body.arguments.append(FlatTerm([], 'i'+SIG.next_huet(), [flatten(qf[0]) for qf in body.quantifiers]))
		h_type = FlatTerm(body.quantifiers, "!", [])
		h_type = flat_substituted({"!": t_type}, h_type)
		dbp(f"h_type after substitution was {h_type}", recr)
		
		for i in range(len(h_type.quantifiers)):
			var = h_type.quantifiers[i][0]
			h_type.quantifiers[i] = (SIG.next_bound(), h_type.quantifiers[i][1])
			h_type = flat_substituted({var: h_type.quantifiers[i][0]}, h_type, i+1)

		ctx.append((body.arguments[-1].head, h_type))
		db(f"IMIT: Appended {ctx[-1][0]}: {ctx[-1][1]} to ctx")
	
	unif = Unifier({s.head: body})
	db(f"IMIT: unifier is {unif}")
	if occurs(unif):
		db(f"IMIT: occurs, invalid")
		return
	yield unif

def disagreeing_types(a : FlatTerm, nb : FlatTerm, ctx : Ctx, recr : int):
	a_type,a_obs = flat_type_check_native(a.head, SIG, ctx, a.quantifiers, recr)
	nb_type,nb_obs = flat_type_check_native(nb, SIG, ctx, a.quantifiers, recr) 
	if a_obs:
		dbp(f"Base type of a={a}'s head {a.head} ({a_type}) came with additional obligations {Eqns(a_obs)}", recr)
	elif nb_obs:
		dbp(f"Base type of nb={nb} ({nb_type}) came with additional obligations {Eqns(nb_obs)}", recr)
	return [tuple((FlatTerm(a.quantifiers + nb.quantifiers + r.quantifiers, r.head, r.arguments)) for r in dag) for dag in (_r([], a_type, nb_type, recr) + a_obs + nb_obs) ]
		
def flat_type_check_native(s : FlatTerm, sig : Sig, ctx : Ctx, flat_binding : Ctx, recr : int, hard : bool = False) -> tuple[FlatTerm, Eqns]:
	'''
	Accepts a flat-term and relevant context structures, outputs a pair of < t, obs > where t is the type of the flat-term
	iff the obligations are true; otherwise t is invalid. Returns < None, [] > if the term is completely ill-typed, i.e. 
	not approximately well-typed. 
	'''
	
	dbp(f"Checking type of flat term {s}...", recr)
	if isinstance(s, str):
		return flatten(get_from_context(sig, ctx+flat_binding, s)), []
	h_type = flatten(get_from_context(sig, ctx+flat_binding+s.quantifiers, s.head), True)
	if h_type == None:
		print(f"Failed to get type of {s.head} from context", recr)
		print(f"Context = {Ctx(ctx)}, flat_binding = {Ctx(flat_binding)}, sig constants = {sig.constants}", recr)
		raise InvalidType(s)
	
	dbp(f"h_type of {s} was {h_type}", recr)
	obs = []
	for i in range(len(s.arguments)):
		t = s.arguments[i]
		typ, t_obs = flat_type_check_native(t, sig, ctx, flat_binding + s.quantifiers, recr + 1, hard)
		if typ == None:
			return None, []
		obs.extend(t_obs)

		h_type = flat_substituted({h_type.quantifiers[i][0]: t}, h_type, i + 1) # critical dependent type step
		dbp(f"Flat substituted {h_type.quantifiers[i][0]} for {t} in {h_type}", recr)
		if not flat_aeq(h_type.quantifiers[i][1], typ):
			if hard:
				raise InvalidType
			dbp(f"h_type={h_type}, typ={typ}, etc. (term was {s})", recr)
			if type_pair_incompatible(h_type.quantifiers[i][1], typ, flat_binding+s.quantifiers, sig):
				return None, []
			obs.append((h_type.quantifiers[i][1], typ))
	
	dbp(f"h_type of {s} became {h_type} after substitution which was {'string' if isinstance(h_type, str) else 'flat'}", recr)
	ret = FlatTerm(s.quantifiers + h_type.quantifiers[len(s.arguments):], h_type.head, h_type.arguments)
	dbp(f"Flat term {s} had type {ret}", recr)
	if len(obs) > 0:
		dbp(f"Flat term {s} is well-typed iff the following are true = {Eqns(obs)}", recr)
		pass
	return ret, obs

def type_pair_incompatible(s : FlatTerm, t : FlatTerm, binding_ctx : Ctx, sig : Sig) -> bool:
	s_rigid = s.head in sig.constants or any([s.head == q[0] for q in binding_ctx])
	if not s_rigid:
		return False
	t_rigid = t.head in sig.constants or any([t.head == q[0] for q in binding_ctx])
	if not t_rigid:
		return False
	return s.head != t.head

def free_variables_native(s : FlatTerm, bound : set = None, include_types : bool = True):
	if bound == None:
		bound = set()
	if (not s.quantifiers) and (not s.arguments):
		if (s.head not in SIG.constants) and (s.head not in bound):
			return {s.head}
		return set()
	vars = set()
	bound = bound.copy()
	for q in s.quantifiers:
		if not q[0]:
			continue
		if include_types:
			vars |= free_variables_native(q[1], bound, include_types)
		bound.add(q[0])

	if s.head not in SIG.constants and s.head not in bound and not s.head.startswith("EQ"):
		vars.add(s.head)
	
	for a in s.arguments:
		vars |= free_variables_native(a, bound, include_types)

	return vars
	
def term_from_flat_literal(f : FLiteral):
	return f.term if f.pol else FlatTerm([], 'not', [f.term])

def flat_aeq(s : FlatTerm, t : FlatTerm, binding : dict = None):
	if isinstance(s, FLiteral):
		s = term_from_flat_literal(s)
	if isinstance(t, FLiteral):
		t = term_from_flat_literal(t)
	
	if len(s.quantifiers) != len(t.quantifiers) or len(s.arguments) != len(t.arguments):
		return False
	
	if binding == None:
		binding = {}
	for i in range(len(s.quantifiers)):
		if not flat_aeq(s.quantifiers[i][1], t.quantifiers[i][1], binding):
			return False
		if s.quantifiers[i][0] != t.quantifiers[i][0]:
			binding = binding.copy()
			binding[t.quantifiers[i][0]] = s.quantifiers[i][0]
	if s.head != t.head and binding.get(t.head, None) == None:
		return False
	
	return all(flat_aeq(s.arguments[i], t.arguments[i], binding) for i in range(len(s.arguments)))

def occurs(unif : Unifier):
	for k,v in unif.items():
		if k in free_variables_native(v):
			return True
	return False

# Modifies the unifier and ctx in place to capture dependent type substitutions; in particular,
# any variable whose type contains (a variable in the unifier) should be replaced with a new
# variable of substituted type. 
def augment_dtypes(unif : Unifier, ctx : Ctx, recr : int = 0):
	if occurs(unif):
		raise ValueError(f"Occurs failure in unifier {unif}")
	changed = True
	while changed:
		changed = False
		for symbol,typ in ctx:
			if symbol in unif:
				continue # Already substituting this symbol
			fvs = free_variables_native(typ)
			for fv in fvs:
				if fv in unif:
					new_symbol = SIG.next_var()
					new_type = flat_substituted(unif, typ)
					ctx.append((new_symbol, new_type)) # Do not get rid of the old symbol, just add the new one 
					unif[symbol] = flatten(new_symbol)
					changed = True
					dbp(f"{fv} was free in the type of symbol {symbol} ({typ}), and it appears in the unifier substituted with {unif[fv]}, so we have to create a new substitution for {symbol}.", recr)
					dbp(f"We replaced the substitution {symbol} : {typ} with {new_symbol} : {new_type}", recr)


def PATTERN(s : FlatTerm, t : FlatTerm, up : UnifProblem, recr : int):
	up.validate() ; s.validate() ; t.validate()
	dbp(f"PATTERN: solving {s}=={t}", recr)

	if (not s.arguments) and (not s.quantifiers):
		if s.head not in free_variables_native(t):
			yield {s.head : t}
		return
	if (not t.arguments) and (not t.quantifiers):
		if t.head not in free_variables_native(s):
			yield {t.head : s}
		return

	if not (flat_is_pattern(s, list(SIG.constants.items()), recr) and flat_is_pattern(t, list(SIG.constants.items()), recr)):
		dbp(f"PATTERN: one or both terms aren't patterns", recr)
		return
	
	if s.head == t.head:
		dbp(f"PATTERN: z_same", recr)
		yield z_same(s, t, up.ctx, [], recr)
	else:
		dbp(f"PATTERN: z_distinct", recr)
		yield z_distinct(s, t, up.ctx, [], recr)


def flat_is_pattern(flat : FlatTerm, in_binding_ctx : Ctx, recr : int = 0):
	if not lhnf_is_rigid(FlatTerm(in_binding_ctx+flat.quantifiers, flat.head, flat.arguments)):

		if len(set([arg.head for arg in flat.arguments])) != len(flat.arguments):
			dbp(f"Flat term {flat} with free head {flat.head} is not applied to distinct symbols", recr)
			return False
		
		for arg in flat.arguments:
			if get_from_context(SIG, in_binding_ctx + flat.quantifiers, arg.head) == None: # Var is not a bound variable
				dbp(f"Flat term {flat} with free head {flat.head} has non-bound argument {arg}", recr)
				return False
			if len(arg.quantifiers) != len(arg.arguments): # Var is not eta-equivalent to its head alone
				dbp(f"Flat term {flat} with free head {flat.head} has non-eta-style {arg}", recr)
				return False
			# Is it also important to check that the quantifiers match the order of the arguments?
	
	ret = all([flat_is_pattern(arg, in_binding_ctx + flat.quantifiers) for arg in flat.arguments])
	if not ret:
		dbp(f"Flat term {flat} had an argument which is not flat...", recr)
	return ret

# Impractical: not enough instantiations available especially with renamed types. We need either a looser constraint
# on potential instantiations (such as AWT) or to instantiate terms by other means (such as choice for all types)
# We could also use a NON-exponential way to 
def unify_instantiated_patterns(s : FlatTerm, t : FlatTerm, up : UnifProblem, bctx : Ctx, recr : int) -> Generator[Unifier, None, None]:
	if recr > 20:
		return
	for u_s in constant_instantiations(s, up.ctx):
		p = applied_flat_unifier(s, u_s)
		q = applied_flat_unifier(t, u_s)

		for u in pair_solutions(p, q, up, recr+1):
			yield composed_flat_unifiers(u_s, u)

# This function works vaguely how I want it to, but there are way too many !!!
def constant_instantiations(s : FlatTerm, ctx : Ctx) -> Generator[Unifier, None, None]:
	head_type = get_from_context(SIG, ctx, s.head)
	if head_type == None:
		raise ValueError(s)
	for term,typ in list(SIG.constants.items()) + SIG.original_subterms:
		if typ == None:
			continue
		if flat_aeq(approximate_type(flatten(typ)), approximate_type(head_type)):
			fterm = flatten(term)
			if fterm.head not in SIG.constants:
				continue
			for v in free_variables_native(fterm):
				if get_from_context(SIG, ctx, v) == None:
					ctx.append((v, flatten(get_from_context(SIG, SIG.original_subterms, v))))
			yield {s.head : fterm}

def z_same(s : FlatTerm, t : FlatTerm, ctx : Ctx, bctx : Ctx, recr : int = 0) -> Unifier:
	if len(s.arguments) != len(t.arguments):
		dbp(f"z_same: different number of arguments, types can't be the same", recr)
		return
	
	# This is the type that H must return 
	s_body_type,obs = flat_type_check_native(FlatTerm([], s.head, s.arguments), SIG, ctx, bctx + s.quantifiers, recr)
	if s_body_type == None:
		dbp(f"z_same: s = {s} could not be well-typed as the body type was none", recr)
		return 
	if obs:
		dbp(f"z_same: s = {s} could not be well-typed as it had obligations {obs}", recr)
		return 
	
	# Add a quantifier for each argument to F. Use the same name
	s_body = FlatTerm([(SIG.next_bound(), flatten(get_from_context(SIG, ctx + bctx + s.quantifiers, arg.head))) for arg in s.arguments], SIG.next_huet(), [])

	h_qfs = Ctx()

	# For each matching argument to G, add an argument to H
	for i in range(len(s.arguments)):
		if s.arguments[i].head == t.arguments[i].head:
			s_body.arguments.append(flatten(s_body.quantifiers[i][0])) # these _should_ line up
			h_qfs.append((SIG.next_bound(), s_body.quantifiers[i][1]))
	
	ctx.append((s_body.head, flat_substituted({"!": s_body_type}, FlatTerm(h_qfs, "!", []))))
	dbp(f"z_same: added {ctx[-1][0]}:{ctx[-1][1]} to ctx", recr)

	dbp(f"z_same: returning {Unifier({s.head: s_body})}", recr)
	return Unifier({s.head : s_body})

# Since we require terms to be in LHNF, the difference in quantifiers should be erased, but just ignore that for now
def z_distinct(s : FlatTerm, t : FlatTerm, ctx : Ctx, bctx : Ctx, recr : int = 0) -> Unifier:
	shared_H = SIG.next_huet()

	# Obviously, should check
	s_body_type,s_obs = flat_type_check_native(FlatTerm([], s.head, s.arguments), SIG, ctx, bctx + s.quantifiers, recr)
	t_body_type,t_obs = flat_type_check_native(FlatTerm([], t.head, t.arguments), SIG, ctx, bctx + t.quantifiers, recr)
	if s_body_type == None:
		dbp(f"z_distinct: s = {s} and/or t = {t} could not be well-typed", recr)
		return None
	if t_body_type == None:
		dbp(f"z_distinct: t = {t} could not be well-typed", recr)
		return None
	if s_obs or t_obs:
		dbp(f"z_distinct: s = {s} came with obligations {s_obs} and t with obligations {t_obs}", recr)
		return None

	s_body = FlatTerm([(SIG.next_bound(), flatten(get_from_context(SIG, ctx + bctx + s.quantifiers, arg.head))) for arg in s.arguments], shared_H, [])
	t_body = FlatTerm([(SIG.next_bound(), flatten(get_from_context(SIG, ctx + bctx + t.quantifiers, arg.head))) for arg in t.arguments], shared_H, [])
	
	h_qfs = Ctx()

	# Intersect the two sets of arguments
	for i in range(len(s.arguments)):
		for j in range(len(t.arguments)):
			if s.arguments[i].head == t.arguments[j].head:
				s_body.arguments.append(flatten(s_body.quantifiers[i][0]))
				t_body.arguments.append(flatten(t_body.quantifiers[j][0]))
				h_qfs.append((SIG.next_bound(), s_body.quantifiers[i][1]))
				break
	
	ctx.append((shared_H, flat_substituted({"!": s_body_type}, FlatTerm(h_qfs, "!", [])))) # Need this because the type might be complex
	dbp(f"z_distinct: added {ctx[-1][0]}:{ctx[-1][1]} to ctx", recr)

	unif = Unifier({s.head : s_body, t.head : t_body})
	dbp(f"z_distinct: returning {unif}", recr)
	return unif