from hol import *
from datatypes import *
from random import shuffle

DEBUG_PREUNIFICATION = 1
def dbp(s):
	DEBUG_PREUNIFICATION and print(s)

CONSTANTS = set() # Reset each time

def approximate_term(term : Term):
	if isinstance(term, str):
		return term
	if isinstance(term, App):
		return App(approximate_term(term.operator), approximate_term(term.operand))
	if isinstance(term, Quantifier):
		return term.__class__(term.var, approximate_type(term.var_type), approximate_term(term.body))

def approximate_type(typ : Term):
	if isinstance(typ, str):
		return typ
	if isinstance(typ, App):
		return approximate_term(typ.operator)
	if isinstance(typ, Quantifier):
		return typ.__class__("", approximate_type(typ.var_type), approximate_type(typ.body))

def lhnf_head(term : Term, depth : int = 0) -> str | int:
	if isinstance(term, str):
		return term
	elif isinstance(term, App):
		return lhnf_head(term.operator)
	elif isinstance(term, Quantifier):
		h = lhnf_head(term.body, depth + 1)
		if isinstance(h, str) and h == term.var:
			return depth
		return h
	raise ValueError(term)

def lhnf_body(term : Term) -> Term:
	if isinstance(term, Quantifier):
		return lhnf_body(term.body)
	if isinstance(term, (App, str)):
		return term

def lhnf(term : Term, bound_vars : Ctx, ctx : Ctx, iter_limit : int = 1000) -> Term:
# Every term with an approximate (well) type has an LHNF. We might need to B-reduce arbitrarily,
# so we try 1000 times until it stops changing. 
	changed = True
	i = 0
	while changed and i < iter_limit:
		term, changed = _lhnf(term, bound_vars, ctx)
		i += 1
	if not changed:
		return term
	else:
		print(f"WARN: lhnf() reached iter_limit in elliott.py")

def is_lhnf(term : Term):
	if isinstance(term, str):
		return True
	if isinstance(term, Quantifier):
		return isinstance(term.body, Quantifier) and is_lhnf(term.body) or isinstance(term.body, App)
	if isinstance(term, App):
		return is_lhnf(term.operator) and not isinstance(term.operator, Quantifier)

def _lhnf(term : Term, bound_vars : Ctx, ctx : Ctx) -> tuple[Term, bool]:
	if isinstance(term, str):
		return term, False
	
	if isinstance(term, App):
		if isinstance(term.operator, (Abs, Pi)):
			ret,_ = _lhnf(substituted(term.operator.var, term.operand, term.operator.body), bound_vars, ctx)
			return ret, True # beta reduction.
		ret,changed = _lhnf(term.operator, bound_vars, ctx)
		return App(ret, term.operand), changed
		
	if isinstance(term, (Pi, Abs)):
		etaexp = False
		binding = bound_vars + [(term.var, term.var_type)]
		if isinstance(term.body, App):
			btype = infer_types(term.body, binding, ctx)
			if isinstance(btype, Pi):
				new_var = next_fresh_symbol()
				term.body = Abs(new_var, btype.var_type, App(term.body, new_var))
				etaexp = True
		
		ret,changed = _lhnf(term.body, binding, ctx)
		return term.__class__(term.var, term.var_type, ret), changed or etaexp
	
	raise ValueError(term)


unif_idx = 0
class UnifProblem():
	ctx	 : Ctx   = Ctx()
	subs	: Subs  = Subs()
	dag	 : Eqns  = Eqns()
	unif_id : int = 0

	def __init__(self, ctx, subs, dag):
		self.ctx = ctx ; self.subs = subs ; self.dag = dag
		global unif_idx
		self.unif_id = unif_idx + 1
		unif_idx += 1 

	def is_solved(self):
		return not any(d[0] in CONSTANTS for d in self.dag)
	
	def __str__(self):
		return f"Unif{self.unif_id}:({Subs(self.subs)})[{Eqns(self.dag)}]"
	

def _r(ctx : Ctx, type1 : Term, type2 : Term, depth : int = 0) -> Eqns | None:
	if depth > 100:
		dbp(f"R: depth limit 100 reached")
		return None
	if isinstance(type1, str) and isinstance(type2, str):
		return Eqns()
	if isinstance(type1, App) and isinstance(type2, App):
		return Eqns(_r(ctx, type1.operator, type2.operator, depth + 1) + [(
			long_abs(*ctx, type1.operand),
			long_abs(*ctx, type2.operand)
		)])
	if isinstance(type1, Abs) and isinstance(type2, Abs):
		return Eqns(_r(ctx, type1.var_type, type2.var_type, depth + 1) + 
					_r(ctx + [(type1.var, type1.var_type)], 
						type1.body, 
						substituted(type2.var, type1.var, type2.body), 
						depth + 1
		))
	if isinstance(type1, Pi) and isinstance(type2, Pi):
		lhs = _r(ctx, type1.var_type, type2.var_type, depth + 1)
		rhs = _r(ctx + [(type1.var, type1.var_type)], 
						type1.body, 
						substituted(type2.var, type1.var, type2.body), 
						depth + 1
		)
		if lhs != None and rhs != None:
			return Eqns(lhs + rhs)
	dbp(f"R: can't AWT-unify {type1} and {type2} in ctx {ctx}")
	return None


def lhnf_has_rigid_head(t : Term, h = None):
	if h == None:
		h = lhnf_head(t)
	if (isinstance(h, str) and h in CONSTANTS) or isinstance(h, int):
		return True
	return False

def lhnf_num_arguments(t : Term):
	if isinstance(t, Quantifier):
		return 1 + lhnf_num_arguments(t.body)
	return 0

def lhnf_quantifiers(t : Term) -> Subs:
	if isinstance(t, Quantifier):
		return [(t.var, t.var_type)] + lhnf_quantifiers(t.body)
	return []

def lhnf_arguments(t : Term, ctx : Ctx) -> tuple[Ctx, Ctx]:
	if isinstance(t, Quantifier):
		return lhnf_arguments(t.body, ctx + [(t.var, t.var_type)])
	if isinstance(t, App):
		ret, ctx = lhnf_arguments(t.operator, ctx)
		if ret == None:
			return None
		try:
			return ret + [(t.operand, type_check(approximate_term(t.operand), [], ctx, True))], ctx
		except InvalidType:
			return None, ctx
	if isinstance(t, str):
		return [], ctx

def start_unification_problem_from_equalities(eqns : Eqns, context : Ctx, constants : set, recursion_depth = 0) -> Subs | None:
	global CONSTANTS
	CONSTANTS = constants
	result = start_unification_problem_from_unifproblem(UnifProblem(context, [], Eqns(eqns)), recursion_depth) # Initial unification problem
	return result

def start_unification_problem_from_unifproblem(problem : UnifProblem, recursion_depth = 0) -> Subs | None:
	
	if recursion_depth > 10:
		raise RecursionError(f"Too deep, problem={problem}")
	
	max_iters = 200
	mandatory_problems = [problem]
	finished_unifiers = []
	i = 0
	db = lambda s : dbp('\t' * recursion_depth + s)

	while len(mandatory_problems) > 0 and max_iters > i:
		current_problem = mandatory_problems.pop()
		i += 1

		# if isinstance(current_problem, list):
		# 	shuffle(current_problem)
		# 	for subproblem in current_problem:
		# 		shuffle(subproblem.ctx)
		# 		shuffle(subproblem.subs)
		# 		shuffle(subproblem.dag)
		# else:
		# 	shuffle(current_problem.ctx)
		# 	shuffle(current_problem.subs)
		# 	shuffle(current_problem.dag)

		db(f"Looking at unification problem {current_problem}")

		
		if isinstance(current_problem, UnifProblem):
			dags_remaining = []
			current_problem.dag = [(lhnf(d[0], [], current_problem.ctx), lhnf(d[1], [], current_problem.ctx)) for d in current_problem.dag]
			if all([is_flex_flex(d[0], d[1]) for d in current_problem.dag]):
				db(f"Everything is flex-flex. Appending subs {current_problem.subs}")
				finished_unifiers.append(current_problem.subs)
				continue
			
			for pair in current_problem.dag:
				if isinstance(pair[0], str) and pair[0] in free_variables(pair[1], [], True) and pair[0] not in CONSTANTS:
					db(f"Occurs check for pair {pair}!")
					return None
				if isinstance(pair[1], str) and pair[1] in free_variables(pair[0], [], True) and pair[1] not in CONSTANTS:
					db(f"Occurs check for pair {pair}!")
					return None

			for i in range(len(current_problem.dag)):
				db(f"Looking at pair {Clause(current_problem.dag[i])}...")
				p0,p1 = current_problem.dag[i]
				
				p0 = lhnf(p0, [], current_problem.ctx) ; p1 = lhnf(p1, [], current_problem.ctx)
				if is_rigid_rigid(p0, p1):
					# Deconstruct rigid-rigid problems or return false
					if distinct_heads(p0, p1):
						db(f"Rigid-rigid heads are distinct in {p0}, {p1}")
						db(f"Heads were [{lhnf_head(p0)}], [{lhnf_head(p1)}]")
						return None
					rr = rigid_rigid(p0, p1, Ctx())
					if rr == None:
						db(f"Rigid-rigid terms have different forms in {p0}, {p1}")
						return None
					dags_remaining.extend(rr)
					db(f"Rigid-rigid, adding dag-pairs {rr}")
				elif is_flex_flex(p0, p1):
					# Keep flex-flex pairs in the group
					dags_remaining.append((p0, p1))
					db(f"Flex-flex, keeping in dags")
				else:
					# Generate possible unifiers for flex-rigid pairs
					new_unif_problems = []
					if is_flex_rigid(p0, p1):
						db(f"Flex-rigid: {p0}, {p1}")
						new_unif_problems = flex_rigid(current_problem, p0, p1, recursion_depth)
					elif is_flex_rigid(p1, p0):
						db(f"Rigid-flex: {p0}, {p1}")
						new_unif_problems = flex_rigid(current_problem, p1, p0, recursion_depth)

					if new_unif_problems == None:
						db(f"No new unification problems from flex-rigid or rigid-flex, must fail")
						return None
					# Just one of these new unification problems needs to succeed
					db(f"New unif problems = {[str(problem) for problem in new_unif_problems]}")
					mandatory_problems.append(new_unif_problems)

			if dags_remaining:
				db(f"Done, adding {Eqns(dags_remaining)} to mandatory problems")
				mandatory_problems.append(UnifProblem(current_problem.ctx, [], Eqns(dags_remaining)))
			else:
				db(f"Successfully unified dags in current problem, removing problem. {len(mandatory_problems)} remaining")
				db(f"Appending subs {current_problem.subs}")
				finished_unifiers.append(current_problem.subs)
		
		if isinstance(current_problem, list):
			# Address a flex-rigid challenge recursively!! If this is a list, it means it's a list of *possible* unifiers
			# so only one of them needs to succeed. 
			solved = False
			for subproblem in current_problem:
				subproblem.dag = [(lhnf(d[0], [], subproblem.ctx), lhnf(d[1], [], subproblem.ctx)) for d in subproblem.dag]
				db(f"Flex-rigid subproblem = {subproblem}")
				subs_or_none = start_unification_problem_from_unifproblem(subproblem, recursion_depth + 1)
				if subs_or_none == None:
					db(f"Flex-rigid subproblem could not be solved")
					db(f"No suitable unifier for flex-rigid problem {subproblem}")
					return None
					continue

				# ERROR: the unifier is not finished. The substitution needs to be applied to the current
				# DAG and the process should resume from the beginning! We need to restructure
				finished_unifiers.append([(sub[0], Subs(subs_or_none).applied(sub[1])) for sub in subproblem.subs])
				solved = True ; break


	if max_iters <= i:
		return None
	final_subs = Subs([v for u in finished_unifiers for v in u])
	db(f"Unification Success for problem {problem.unif_id}: final subs = {final_subs}")

	return final_subs


def pair_awt(ctx : Ctx, term1 : Term, term2 : Term):
	if aeq(term1, term2):
		return True
	awterm1 = approximate_term(term1)
	awterm2 = approximate_term(term2)
	awtype1 = approximate_type(type_check(awterm1, [], ctx, True))
	awtype2 = approximate_type(type_check(awterm2, [], ctx, True))
	if awterm1 and aeq(awtype1, awtype2):
		return True
	dbp(f"Term pair {term1}, {term2} is not AWT:")
	dbp(f"\tctx      ={Ctx(ctx)}")
	dbp(f"\tAWT term1={awterm1}")
	dbp(f"\tAWT term2={awterm2}")
	dbp(f"\tAWT type1={awtype1}")
	dbp(f"\tAWT type2={awtype2}")
	return False

def is_flex_flex(term1 : Term, term2 : Term):
	h1 = lhnf_head(term1) ; h2 = lhnf_head(term2)
	return not (lhnf_has_rigid_head(term1, h1) or lhnf_has_rigid_head(term2, h2))

def is_rigid_rigid(term1 : Term, term2 : Term):
	h1 = lhnf_head(term1) ; h2 = lhnf_head(term2)
	return lhnf_has_rigid_head(term1, h1) and lhnf_has_rigid_head(term2, h2)


def distinct_heads(term1 : Term, term2 : Term):
	return lhnf_head(term1) != lhnf_head(term2)
		
# Returns a list of equations that replace a rigid-rigid equality
def rigid_rigid(term1 : Term, term2 : Term, binding_ctx : Ctx) -> Eqns:
	dbp(f"Rigid-rigid unifying {term1}, {term2}...")
	if isinstance(term1, Quantifier) and isinstance(term2, Quantifier):
		res = rigid_rigid(term1.body, term2.body, binding_ctx + [
			(term1.var, term1.var_type),
			(term2.var, term2.var_type)
		])
		return Eqns(res) if res != None else None
	if isinstance(term1, App) and isinstance(term2, App):
		eq_operands = (long_abs(*binding_ctx, term1.operand), long_abs(*binding_ctx, term2.operand))
		eq_operators = rigid_rigid(term1.operator, term2.operator, binding_ctx)
		# print(f"eq_operands={Eqns([eq_operands])}")
		# print(f"eq_operators={Eqns(eq_operators)}")
		return Eqns([eq_operands] + eq_operators) if eq_operators != None else None
	if not term1.__class__ == term2.__class__:
		dbp(f"Rigid-rigid failed based on object structure, term1: {term1.__class__}, term2: {term2.__class__}")
		return None
	return Eqns()

def is_flex_rigid(term1 : Term, term2 : Term):
	h1 = lhnf_head(term1) ; h2 = lhnf_head(term2)
	return (not lhnf_has_rigid_head(term1, h1)) and lhnf_has_rigid_head(term2, h2)

def rigid_flex(unif_problem : UnifProblem, term1 : Term, term2 : Term) -> list[UnifProblem] | None:
	return flex_rigid(unif_problem, term2, term1)

def flex_rigid(unif_problem : UnifProblem, term1 : Term, term2 : Term, recursion_depth : int) -> list[UnifProblem] | None:
	
	dbp('\t' * recursion_depth + f"Performing MATCH for eqn {term1} == {term2}")
	results = []
	imit_ctx = unif_problem.ctx
	imit = _imitation(term1, term2, set(), imit_ctx)
	if imit:
		imit_subs, imit_ctx = imit
		imit_subs = Subs(imit_subs)
		composed_substitution = Subs(Subs(unif_problem.subs).comp(imit_subs) + imit_subs)
		substituted_dag = [(imit_subs.applied(d[0]), imit_subs.applied(d[1])) for d in unif_problem.dag]
		results.append(UnifProblem(imit_ctx, composed_substitution, substituted_dag))

	proj_ctx = unif_problem.ctx
	proj_subs = _projection(term1, term2, set(), proj_ctx, recursion_depth)

	for pj in proj_subs:
		dbp('\t'*recursion_depth + f"Subbing using {Subs(pj)}")
		composed_substitution = Subs(Subs(unif_problem.subs).comp(pj) + pj)
		types_disagreeing = type_dag(proj_ctx, term1, pj)
		if types_disagreeing == None:
			continue
		substituted_dag = [(composed_substitution.applied(d[0]), composed_substitution.applied(d[1])) for d in unif_problem.dag]
		results.append(UnifProblem(proj_ctx, composed_substitution, substituted_dag))

	return results

def type_dag(ctx : Ctx, flex_term : Term, proj_subs : Subs):
	flex_head = lhnf_head(flex_term)
	head_type,_ = lhnf_head_type(flex_term, ctx)
	nb_term = None
	for p0, p1 in proj_subs:
		if p0 == flex_head:
			nb_term = p1
			break
	
	if not nb_term:
		raise LookupError(f"Could not find a mapping for flex head {flex_head} after projecting! proj_subs={proj_subs}")

	nb_type = type_check(approximate_term(nb_term), lhnf_quantifiers(flex_term), ctx, True)

	dbp(f"Attempting to R-ify types of objects [ {flex_head}: {head_type} ], [ {nb_term}: {nb_type} ]...")
	res =  _r([], head_type, nb_type)

	if res == None:
		dbp(f"R-ify failed")
	else:
		dbp(f"R-ify succeeded, res = {res}")
	return res

def _projection(s : Term, t : Term, v : set, ctx : Ctx, recursion_depth : int) -> list[Subs]:
	if len(ctx) == 0:
		raise ValueError
	rigid_head = lhnf_head(t)
	
	flex_head = lhnf_head(s)
	if isinstance(flex_head, int):
		dbp('\t' * recursion_depth + f"Proj: flex head bound, not imitable (not flex either...)")
		return []
	
	dbp('\t' * recursion_depth + f"Proj: getting flex head {flex_head} type in {s} and context {Ctx(ctx)}")
	flex_head_type, ctx = lhnf_head_type(s, ctx)

	if flex_head_type == None:
		dbp('\t' * recursion_depth + f"Proj: flex head nwt")
		return []
	
	if flex_head in free_variables(t, ctx):
		dbp('\t' * recursion_depth + f"Proj: flex head {flex_head} occurs free in {t}")
		return []
	
	dbp('\t' * recursion_depth + f"Proj: seems valid, doing projection for {s} and {t}")
	
	#dbp(f"Proj: ctx = {ctx}")
	dbp('\t' * recursion_depth + f"Proj: flex_head_type = {flex_head_type}"[:1000])
	dbp('\t' * recursion_depth + f"Proj: flex_head = {flex_head}")
	flex_head_arguments = lhnf_quantifiers(flex_head_type)

	proj_i = []
	dbp('\t' * recursion_depth + f"Proj: flex_head_arguments = {Ctx(flex_head_arguments)}")
	if len(flex_head_arguments) == 0:
		dbp('\t' * recursion_depth + f"Proj: no args, appending ({s}->{t})")
		proj_i.append(Subs([(flex_head, t)]))
	for arg in flex_head_arguments:
		ret = return_type(arg[1])
		dbp('\t' * recursion_depth + f"Proj: flex_head_type is {flex_head_type}")
		dbp('\t' * recursion_depth + f"Proj: comparing {ret} with {return_type(flex_head_type)}")
		type_unifier = start_unification_problem_from_equalities([(ret, return_type(flex_head_type))], ctx, CONSTANTS, recursion_depth + 1)
		if type_unifier != None:
			dbp('\t' * recursion_depth + f"Proj: Valid projection candidate: {ret}, {arg[0]}")
		
			body = arg[0]
			lhnf_args,_ = lhnf_arguments(arg[0], ctx)
			if lhnf_args == None:
				return []

			for arg in lhnf_args: # This needs to be the exact number of arguments that the new head arg[0] takes
				H = 'H' + next_fresh_symbol()
				body = App(body, long_app(H, *[flex[0] for flex in flex_head_arguments]))
				ctx.append((H, long_pi(*[flex[1] for flex in flex_head_arguments], arg[1])))
			
			for flex in reversed(flex_head_arguments):
				if isinstance(s, Pi) or isinstance(t, Pi):
					body = Pi(flex[0], flex[1], body)
				else:
					body = Abs(flex[0], flex[1], body)
			
			subs = Subs(type_unifier + [(flex_head, body)])
			dbp(f"Type unifier = {subs}")
			proj_i.append(subs) # This is NOT a substitution! It is a unifier!

	if len(proj_i) == 0:
		dbp('\t' * recursion_depth + f"Proj: nothing generated")
	for problem in proj_i:
		dbp('\t' * recursion_depth + f"Unif: {Subs(problem)}")
	return proj_i


def _imitation(s : Term, t : Term, v : set, ctx : Ctx) -> tuple[Subs,Ctx] | None:
	if len(ctx) == 0:
		raise ValueError
	
	rigid_head = lhnf_head(t)
	if isinstance(rigid_head, int):
		dbp(f"Imit: rigid head bound, not imitable")
		return None # Not imitable
	
	rigid_head_type, ctx = lhnf_head_type(t, ctx)
	if rigid_head_type == None:
		dbp(f"Imit: rigid head {rigid_head} nwt")
		return None # Not well-typed
	
	flex_head = lhnf_head(s)
	if isinstance(flex_head, int):
		dbp(f"Imit: flex head bound, not imitable")
		return None # Not flex
	
	flex_head_type, ctx = lhnf_head_type(s, ctx)
	if flex_head_type == None:
		dbp(f"Imit: flex head nwt")
		return None # Not well-typed
	
	body = rigid_head
	flex_head_arguments, _ = lhnf_arguments(s, ctx)
	rigid_head_arguments, _ = lhnf_arguments(t, ctx)

	if flex_head_arguments == None or rigid_head_arguments == None:
		return None

	dbp(f"Rigid head args = {Ctx(rigid_head_arguments)}")
	dbp(f"Flex head args  = {Ctx(flex_head_arguments)}")

	for arg_pair in rigid_head_arguments + flex_head_arguments:
		if arg_pair[0] == None or arg_pair[1] == None:
			dbp(f"An argument {arg_pair[0]} was ill-typed")
			return None

	flex_head_symbols = [(next_fresh_symbol(), flex[1]) for flex in flex_head_arguments]

	for arg in rigid_head_arguments:
		H = 'H' + next_fresh_symbol()
		body = App(body, long_app(H, *[flex[0] for flex in flex_head_symbols]))
		ctx.append((H, long_pi(*flex_head_symbols, arg[1])))
		dbp(f"Added to ctx={Ctx([ctx[-1]])}")
	
	for flex in reversed(flex_head_symbols):
		if isinstance(s, Pi) or isinstance(t, Pi):
			body = Pi(flex[0], flex[1], body)
		else:
			body = Abs(flex[0], flex[1], body)
	
	dbp(f"IMIT(s,t,v) = {Subs([(flex_head, body)])}")
	return Subs([(flex_head, body)]), ctx


def lhnf_head_type(t : Term, ctx : Ctx) -> tuple[Term, Ctx]:
	actual_head = lhnf_head(t)
	body_type, ctx = _lhnf_body_type(t, ctx)
	head_type = get_from_context(ctx, actual_head)
	if head_type == None:
		return head_type, ctx
	if isinstance(head_type, str) and head_type in CONSTANTS:
		return head_type, ctx

	max_iters = 10
	while (fvs := free_variables(head_type, [])) and (max_iters):
		max_iters -= 1
		found = False
		for fv in fvs:
			for c0, c1 in ctx:
				if is_ternary_app(c1, "EQ"):
					if c1.operator.operand == fv:
						head_type = substituted(fv, c1.operand, head_type)
						found = True
						break
					if c1.operand == fv:
						head_type = substituted(fv, c1.operator.operand, head_type)
						found = True
						break
		if not found:
			break
	return head_type, ctx

def _lhnf_body_type(t : Term, ctx : Ctx) -> tuple[Term, Ctx]:
	#dbp(f"Getting head type for {t} with ctx {ctx}")
	if isinstance(t, Quantifier):
		return _lhnf_body_type(t.body, ctx + [(t.var, t.var_type)])
	if isinstance(t, App):
		try:
			typ = type_check(approximate_term(t), [], ctx, True)
		except InvalidType:
			return None,ctx
		#print(f"lhnf_head_type: was {typ}, ctx={Ctx(ctx)}")
		return typ, ctx
	if isinstance(t, str):
		if got := get_from_context(ctx, t):
			return got, ctx
		return next_fresh_symbol(1), ctx

