from common import *


class SigConstants(dict):
	def __init__(self, d : dict):
		self.update(d)
	def __str__(self):
		s = "{"
		for p0, p1 in self.items():
			s += f"({p0}: {p1}), "
		return s + "}"
	
METALOGIC : Thy = [
		(BOX, BOX),
		(TP, BOX),
		("bool", TP),
		("ind", TP),
		("true", "bool"),
		("false", "bool"),
		("impl", Pi("a", "bool", Pi("b", "bool", "bool"))),
		("or", Pi("a", "bool", Pi("b", "bool", "bool"))),
		("and", Pi("a", "bool", Pi("b", "bool", "bool"))),
		("not", Pi("a", "bool", "bool")),
	]

class Sig():
	metalogic : Thy
	constants : SigConstants
	last_symbol		= 0

	original_formulas : list
	original_subterms : list

	def __init__(self):
		self.equality_symbols = {}
		self.type_equalities = {}
		self.constants = SigConstants({s:t for s,t in METALOGIC})
		self.last_symbol = 0
		self.original_formulas = []
		self.original_subterms = []

	def __str__(self):
		return str(self.constants)

	def next_huet(self):
		self.last_symbol += 1
		return f"H{self.last_symbol}"
	
	def next_leib(self):
		self.last_symbol += 1
		return f"P{self.last_symbol}"

	def next_bound(self):
		self.last_symbol += 1
		return f"B{self.last_symbol}"

	def next_var(self):
		self.last_symbol += 1
		return f"V{self.last_symbol}"
	
	def next_const(self):
		self.last_symbol += 1
		return f"c{self.last_symbol}"
	
	def next_constf(self):
		self.last_symbol += 1
		return f"cf{self.last_symbol}"
	
	def next_type(self):
		self.last_symbol += 1
		return f"t{self.last_symbol}"
	
	def is_var(self, symbol):
		return isinstance(symbol, str) and symbol.startswith(self.var_prefix)
	def is_constant(self, symbol):
		return (isinstance(symbol, str) and symbol.startswith(self.const_prefix)) or (self.constants.get(symbol, None) != None)
	def is_type(self, symbol):
		return isinstance(symbol, str) and symbol.startswith(self.type_prefix)
	
	last_eq = 0
	equality_symbols : dict
	type_equalities : dict

	def replace_in_equalities(self, replacing, replacement) -> None:
		#print(f"Sig: replacing {replacing} with {replacement} in equalities")
		for i in self.equality_symbols.keys():
			self.equality_symbols[i] = substituted(replacing, replacement, self.equality_symbols[i])

	# Note that this is the UNARY type _t_ associated with the equality symbol, and NOT
	# the type of the symbol (which is _t_ -> _t_ -> bool)
	def type_for_equality_symbol(self, eq_symbol) -> Term:
		if not isinstance(eq_symbol, str):
			return None
		if not eq_symbol.startswith("EQ_"):
			return None
		n = self.equality_symbols.get(int(eq_symbol[3:]), None)
		#print(f"Sig: equality type for {int(eq_symbol[3:])} was {n}")
		return n
	
	# Very slow, but until we can reversibly compress terms this is the best we can do
	def equality_symbol_for_type(self, typ) -> str:
		if n := self.type_equalities.get(typ, None):
			return f"EQ_{(n)}"
		self.last_eq += 1
		self.equality_symbols[self.last_eq] = typ
		self.type_equalities[str(typ)] = self.last_eq
		#print(f"Sig: adding equality symbol EQ_{(self.last_eq)} for type {typ}")
		return f"EQ_{(self.last_eq)}"

# Note that this works with both flat and unflat contexts, though will have to be flattened/unflattened depending.
# SIG is usually always unflat, so if using the sig, must always unflatten
def get_from_context(sig : Sig, context : Ctx, symbol : str) -> Term | None:
	for p in reversed(context):
		if p[0] == symbol:
			return p[1]
	if n := sig.constants.get(symbol, None):
		return n
	if symbol.startswith("EQ_"):
		t = sig.type_for_equality_symbol(symbol)
		return long_pi(("", t), ("", t), 'bool')
	return None

def pop_from_context(context : Ctx, symbol : str) -> Term | None:
	i = len(context) - 1
	while i >= 0:
		if context[i][0] == symbol:
			return context.pop(i)[1]
		i -= 1
	return None


def aeq(term1 : Term, term2 : Term, bound : dict = None):
	if term1.__class__ != term2.__class__:
		return False
	if bound == None:
		bound = {}
	if isinstance(term1, str):
		return term1==term2 or bound.get(term2, None)==term1
	if isinstance(term1, App):
		return aeq(term1.operand, term2.operand, bound) and aeq(term1.operator, term2.operator, bound) # Optimised based on LHNF form
	if isinstance(term1, Quantifier):
		if not aeq(term1.var_type, term2.var_type, bound):
			return False
		bound = bound.copy()
		bound[term2.var] = term1.var
		return aeq(term1.body, term2.body)
	if isinstance(term1, Literal):
		return term1.pol == term2.pol and aeq(term1.term, term2.term, bound)
	
	raise ValueError(f"{term1} ({type(term1)}), {term2} ({type(term2)})")


def beta_reduce_repeatedly(formula : Term) -> Term:
	max_iters = 100
	copy = "copy"
	while max_iters > 0 and not aeq(formula, copy):
		copy = copy_term(formula)
		formula = beta_reduced(formula)
		max_iters -= 1
	if max_iters <= 0:
		dbp(f"Repeated beta-reduction hit max_iters!")
	return formula

# Returns the _approximation_ of a type according to Elliott
def type_approximate(typ : Term):
	if isinstance(typ, str):
		return typ
	if isinstance(typ, App):
		return type_approximate(typ.operator)
	if isinstance(typ, Pi):
		return Pi("", type_approximate(typ.var_type), type_approximate(typ.body))

# Returns the approximate type of a term according to Elliott
def approximate_type_check(term : Term, ctx : Ctx, sig : Sig):
	ret = None
	if isinstance(term, str):
		ret = type_approximate(get_from_context(sig, ctx, term))
	if isinstance(term, App):
		if is_ternary_app(term, 'EQ'):
			ret = 'bool'
		else:
			op_type = approximate_type_check(term.operator, ctx, sig)
			if isinstance(op_type, Pi):
				ret = approximate_type_check(op_type.body, ctx, sig)
			else:
				ret = sig.next_type()
	if isinstance(term, Abs):
		ret = Pi("", type_approximate(term.var_type), approximate_type_check(term.body, ctx, sig))
	if isinstance(term, Quantifier):
		ret = 'bool'
	return ret


def type_check_obligations(formula : Term, sig : Sig, bound_vars : Ctx, global_ctx : Ctx) -> tuple[Term,Eqns]:
	debug_obs = 1

	if isinstance(formula, str):
		b = get_from_context(sig, bound_vars, formula)
		if b == None:
			b = get_from_context(sig, global_ctx, formula)
		if b == None:
			raise InvalidType(formula) # nothing good can come of this case
		return b,[]
	
	debug_obs and print(f"Getting obligations... {formula} : {type(formula)}")
	
	if is_eq(formula):
		lhs,rhs = eq_parts(formula)
		lhs_obs = type_check_obligations(lhs, sig, bound_vars, global_ctx)
		rhs_obs = type_check_obligations(rhs, sig, bound_vars, global_ctx)
		if lhs_obs == rhs_obs and lhs_obs == sig.type_for_equality_symbol(formula.operator.operator):
			debug_obs and print(f"obs = {lhs_obs[1] + rhs_obs[1]}")
			return 'bool', lhs_obs[1] + rhs_obs[1]
		
		debug_obs and print(f"Type of the equality symbol {formula.operator.operator} was {sig.type_for_equality_symbol(formula.operator.operator)} (compare lhs type = {lhs_obs[0]})")
		return 'bool', [(lhs_obs[0], rhs_obs[0]), (lhs_obs[0], sig.type_for_equality_symbol(formula.operator.operator))] + lhs_obs[1] + rhs_obs[1]
	
	if isinstance(formula, App):
		operator_type = type_check_obligations(formula.operator, sig, bound_vars, global_ctx)
		operand_type = type_check_obligations(formula.operand, sig, bound_vars, global_ctx)

		if operator_type[0] == None or operand_type[0] == None:
			raise ValueError(operator_type, operand_type)

		if not isinstance(operator_type[0], Pi):
			return operator_type[0], operator_type[1] + operand_type[1] + [(operator_type[0], Pi(sig.next_bound(), operand_type[0], sig.next_var()))]
		
		obs = []
		if not aeq(operand_type[0], operator_type[0].var_type, {c[0]:c[1] for c in global_ctx}):
			obs = [(operator_type[0].var_type, operand_type[0])] # This is the crucial part of the function

		debug_obs and (operator_type[1] or operand_type[1] or obs) and print(f"App obs = {operator_type[1] + operand_type[1] + obs}")
		return substituted(operator_type[0].var, formula.operand, operator_type[0].body), operator_type[1] + operand_type[1] + obs
	
	if isinstance(formula, Abs):
		obs = type_check_obligations(formula.body, sig, bound_vars + [(formula.var, formula.var_type)], global_ctx)
		return Pi(formula.var, formula.var_type, obs[0]), obs[1] # Assume well-formed, conflicts handled in App case
	
	if isinstance(formula, Pi):
		obs = type_check_obligations(formula.body, sig, bound_vars + [(formula.var, formula.var_type)], global_ctx)
		if obs[0] == TP:
			return obs
		return TP,obs[1] + [(obs[0], TP)] # Assume it's a type but return an equality obligation
	
	if isinstance(formula, (All,Ext)):
		obs = type_check_obligations(formula.body, sig, bound_vars + [(formula.var, formula.var_type)], global_ctx)
		if obs[0] == 'bool':
			return obs
		return 'bool',obs[1] + [(obs[0], 'bool')] # Assume bool but return an equality obligation
	
	raise ValueError(formula, type(formula))


# Checks types without doing any inference; everything must be well-typed in the context.
# hard_check param will throw an error if anything is invalid
def type_check(formula : Term, sig : Sig, bound_vars : Ctx, global_ctx : Ctx, hard_check : bool = True, shh : bool = False) -> Term:
	#print(f"Type checking formula {formula}...")
	def bug(s, pr : bool = True):
		if pr:
			if not shh:
				dbp(f"{s}: in formula {formula} with bound_vars={Ctx(bound_vars)} and ctx={Ctx(global_ctx)} and sig = {[(str(e0), str(e1)) for e0,e1 in sig.constants.items()]}")
			if hard_check:
				raise InvalidType(f"{s}: in formula {formula} with bound_vars={Ctx(bound_vars)} and ctx={Ctx(global_ctx)}")
		elif not shh:
			dbp(s)
		if hard_check:
			raise InvalidType
	
	if isinstance(formula, str):
		b = get_from_context(sig, global_ctx + bound_vars, formula)
		if formula == BOX:
			return BOX # hack and not strictly true
		if b == None:
			bug("Missing type for symbol")
		return b
	
	if isinstance(formula, App):
		operator_type = type_check(formula.operator, sig, bound_vars, global_ctx, hard_check, shh)
		operand_type = type_check(formula.operand, sig, bound_vars, global_ctx, hard_check, shh)

		if not isinstance(operator_type, Pi):
			bug("Operator is not function type, was " + str(type(operator_type)))
			return None
		
		if not aeq(operand_type, operator_type.var_type):
			if operand_type == BOX and operator_type.var_type == TP: # HACK
				pass
			else:
				bug(f"Incompatible application types {operator_type.var_type} and {operand_type}\nFormula was {formula}", False)
				return None
		
		#print(f"{formula}: operator_type={operator_type}, operand_type={operand_type}")
		#print(f"{formula}: the type of this term is {substituted(operator_type.var, formula.operand, operator_type.body)}")
		#dbp(f"{formula}: formula had type {substituted(operator_type.var, formula.operand, operator_type.body)}")
		return substituted(operator_type.var, formula.operand, operator_type.body)
	
	if isinstance(formula, Abs):
		body = type_check(formula.body, sig, bound_vars + [(formula.var, formula.var_type)], global_ctx, hard_check, shh)
		if body == None:
			bug("Body type of abstraction is invalid")
			return None
		elif formula.var_type == None:
			bug("Var type of abstraction is invalid")
			return None
		return Pi(formula.var, formula.var_type, body)
	if isinstance(formula, (Pi, All, Ext)):
		body = type_check(formula.body, sig, bound_vars + [(formula.var, formula.var_type)], global_ctx, hard_check, shh)
		if body == None:
			bug("Body type of quantified formula is invalid")
			return None
		if formula.var_type == None:
			bug("Var type of quantified formula is invalid")
			return None
		if isinstance(formula, Pi) and body != TP:
			bug(f"Body type {body} is not TP for pi-quantifier")
			return None
		elif isinstance(formula, (All,Ext)) and body != 'bool':
			bug(f"Body type {body} is not bool for exist/univ quantifier")
			return None
		return body # Either TP or bool, ideally
	
	raise ValueError(formula, type(formula))

def quantifiers_renamed(in_formula : Term, sig : Sig) -> Term:
	if isinstance(in_formula, tuple):
		assert (len(in_formula) == 2)
		return (in_formula[0], quantifiers_renamed(in_formula[1], sig))
	
	if isinstance(in_formula, str):
		return in_formula
	if isinstance(in_formula, App):
		return App(quantifiers_renamed(in_formula.operator, sig), quantifiers_renamed(in_formula.operand, sig))
	if isinstance(in_formula, Quantifier):
		new_var = sig.next_bound()
		print(f"quantifiers_renamed: started with formula {in_formula} : {type(in_formula)}")
		print(f"quantifiers_renamed: new_var={new_var}, var_type={in_formula.var_type}, substituting {in_formula.var} for {new_var} in {in_formula.body}...")
		return in_formula.__class__(
			new_var, in_formula.var_type, quantifiers_renamed(substituted(in_formula.var, new_var, in_formula.body), sig)
		)
	raise ValueError(in_formula, type(in_formula))

def type_equalities(in_formula : Term, sig : Sig, global_ctx : Ctx, binding_ctx : Ctx) -> Term:
	if isinstance(in_formula, tuple):
		assert len(in_formula) == 2
		return (in_formula[0], type_equalities(in_formula[1], sig, global_ctx, binding_ctx))

	if isinstance(in_formula, Quantifier):
		return in_formula.__class__(in_formula.var, in_formula.var_type,
			type_equalities(in_formula.body, sig, global_ctx, binding_ctx + [(in_formula.var, in_formula.var_type)]))
	
	if isinstance(in_formula, App):
		if is_unary_app(in_formula, 'eq'):
			in_formula.operand = type_equalities(in_formula.operand, sig, global_ctx, binding_ctx)
			lhs_type = type_check(in_formula.operand, sig, binding_ctx, global_ctx, False)
			#print(f"type_equalities: type of {in_formula.operand} was {lhs_type}")
			if lhs_type == None:
				raise InvalidType(f"No type found for {in_formula.operand} in formula={in_formula}, \nglobal_ctx={Ctx(global_ctx)}, \nbinding_ctx={Ctx(binding_ctx)}")
			#print(f"type_equalities: this type is given the eq symbol {sig.equality_symbol_for_type(lhs_type)}")
			return App(sig.equality_symbol_for_type(lhs_type), type_equalities(in_formula.operand, sig, global_ctx, binding_ctx))
		return App(type_equalities(in_formula.operator, sig, global_ctx, binding_ctx), type_equalities(in_formula.operand, sig, global_ctx, binding_ctx))
	
	if isinstance(in_formula, str):
		return in_formula
	
	raise ValueError

def unbound_subterms(t, sig : Sig, ctx : Ctx, bctx : Ctx):
	if isinstance(t, str):
		return [(t, get_from_context(sig, ctx, t))]
	if isinstance(t, App):
		opt = unbound_subterms(t.operator, sig, ctx, bctx)
		opd = unbound_subterms(t.operand, sig, ctx, bctx)
		t_type = type_check(t, sig, bctx, ctx, False)
		return opt + opd + [(t, t_type)]
	if isinstance(t, Quantifier):
		return unbound_subterms(t.body, sig, ctx, bctx + [(t.var, t.var_type)]) + [(t, type_check(t, sig, bctx, ctx, False))]
	if isinstance(t, Literal):
		return unbound_subterms(t.term, sig, ctx, bctx)
	if hasattr(t, "__iter__"):
		ubt = []
		for l in t:
			ubt += unbound_subterms(l, sig, ctx, bctx)
		return ubt
	raise ValueError

def free_in_fast(v : str, t : Term):
	if isinstance(t, str):
		return v == t
	if isinstance(t, App):
		return free_in_fast(v, t.operand) or free_in_fast(v, t.operator)
	if isinstance(t, Quantifier):
		if v == t.var:
			return False
		return free_in_fast(v, t.body)
	