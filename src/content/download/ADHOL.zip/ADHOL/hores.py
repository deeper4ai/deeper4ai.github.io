
from typing import Generator

from common import *
from boolean import *
from random import shuffle

class Unsatisfiable(Exception):
	pass
class Valid(Exception):
	pass

debug_hores = 1
def db(s):
	if debug_hores:
		dbp(s)

def _is_unification_constraint(literal : Literal):
	return (not literal.pol) and (is_ternary_app(literal.term, "EQ"))

def _is_proper_literal(literal : Literal):
	return not _is_unification_constraint(literal)

def _is_almost_empty(clause : Clause):
	return all(map(_is_unification_constraint, clause))

def _constraints_of(clause : Clause):
	return filter(_is_unification_constraint, clause)

def _apply_rule(context : Ctx, rule : function, cnf : CNF, constants : set) -> bool:
	return any([rule(context, c, constants) for c in cnf])

def normalise_cnf(constants : set, cnf : CNF, ctx : Ctx) -> Ctx:
	debug_norm = False
	db = lambda s : (not debug_norm) or (not debug_hores) or dbp(s)
	assert isinstance(cnf, CNF)
	for clause_idx in range(len(cnf)):
		clause = Clause(cnf[clause_idx])
		for literal_idx in range(len(clause)):
			literal = clause[literal_idx]
			db(f"Normalising literal {literal}")
			clause[literal_idx] = beta_reduce_repeatedly(literal)
			db(f"Normalised to {clause[literal_idx]}")

		# db(f"Free variables={Clause(fvs)}")
		# for replacing_variable in fvs:
		# 	base_var = replacing_variable.split(".")[0]
		# 	replacement_variable = base_var + "." + str(clause_idx)
		# 	new_vars.append((replacement_variable, get_from_context(ctx, base_var)))
		# 	for literal_idx in range(len(clause)):
		# 		literal = clause[literal_idx]
		# 		if isinstance(literal.term, str):
		# 			if literal.term == replacing_variable:
		# 				clause[literal_idx] = Literal(replacement_variable, literal.pol)
		# 		else:
		# 			literal.term = substituted(replacing_variable, replacement_variable, literal.term)

		cnf[clause_idx] = clause
	
	subsumable = set()
	for clause_i in range(len(cnf)):
		if clause_i in subsumable:
			continue
		for clause_j in range(clause_i + 1, len(cnf)):
			if clause_j in subsumable:
				continue
			if cnf[clause_i] == cnf[clause_j]:
				subsumable.add(clause_j)
	for index in sorted(list(subsumable), reverse=True):
		cnf.pop(index)


def _rule_alpha(context : Ctx, clause : Clause, constants : set) -> bool:
	db(f"Alpha: running...")
	changed = False
	fvs = free_variables(clause, [(c, 'idk') for c in constants])
	for literal in _constraints_of(clause):
		assert isinstance(literal.term, App)
		assert isinstance(literal.term.operator, App)
		lhs = literal.term.operator.operand
		rhs = literal.term.operand

		if not (isinstance(lhs, Abs) and isinstance(rhs, Abs)):
			continue
		
		# Hack: force the abstractions to have the same symbol
		# If debruijned, we don't have to do this
		rhs.body = substituted(rhs.var, lhs.var, rhs.body)

		# Create a new literal and do the substitution. This function
		# will return the unquantified equation
		new_term, skontext = skolemise(
			Ext(lhs.var, lhs.var_type, EQ(lhs.body, rhs.body)),
			fvs, context
		)
		for skonstant in skontext:
			constants.add(skonstant)

		if type_check(new_term, [], context + skontext, True) == None:
			pass

		context.extend(skontext)
		db(f"Alpha: substituted term {literal.term} with {new_term} in clause {clause}")
		literal.term = new_term
		changed = True

	if changed:
		db("Alpha: changed")
	return changed

def _rule_eta(context : Ctx, clause : Clause, constants : set) -> bool:
	db(f"Eta: running...")
	changed = False
	fvs = free_variables(clause, [(c, 'idk') for c in constants])
	for literal in _constraints_of(clause):
		assert isinstance(literal.term, App)
		assert isinstance(literal.term.operator, App)
		lhs = literal.term.operator.operand
		rhs = literal.term.operand

		if not (isinstance(lhs, Abs)):
			continue

		# Create a new skolem term and apply it to both operands of =,
		# even though B might not be an abstraction. 
		sk, skontext = skolemise(Ext(lhs.var, lhs.var_type, lhs.body), fvs, context)

		for skonstant in skontext:
			constants.add(skonstant)

		new_term = EQ(type_check(sk, [], context + skontext, True), sk, rhs)

		new_term.operand = App(new_term.operand, skontext[0][0])
		db(f"Eta: substituted term {literal.term} with {new_term} in clause {clause}")
		literal.term = new_term
		changed = True

	if changed:
		db("Eta: changed")
	return changed

def _rule_dec(context : Ctx, clause : Clause, constants : set) -> bool:
	db("Dec: running...")
	changed = False
	for literal in _constraints_of(clause):
		assert isinstance(literal.term, App)
		assert isinstance(literal.term.operator, App)
		lhs = literal.term.operator.operand
		rhs = literal.term.operand
		lchanged = False

		to_append = []

		while isinstance(lhs, App) and isinstance(rhs, App) and aeq(lhs.operator, rhs.operator, constants):

			eq_obs = type_check_obligations(lhs.operand, [], context)
			# rhs_type = type_check(rhs.operand, [], context, True)
			# if rhs_type != eq_type:
			# 	to_append = []
			# 	break
			eq_type = eq_obs[0]
			new_literal = Literal(EQ(eq_type, lhs.operand, rhs.operand), False)
			for ob in eq_obs[2]:
				to_append.append(Literal(EQ(TP, ob[0], ob[1]), False))
			to_append.append(new_literal)
			lhs = lhs.operator
			rhs = rhs.operator
			lchanged = True
		
		clause.extend(to_append)

		if len(to_append) > 0:
			pass
			db(f"Dec: split literal {literal} into parts {[str(a) for a in to_append]} in clause {clause}")
		if lchanged:
			literal.term = "true"
			literal.pol = False
			changed = True
	
	if changed:
		db("Dec: changed")
	return changed

def _rule_triv(context : Ctx, clause : Clause, constants : set) -> bool:
	db("Triv: running...")
	changed = False
	for literal in _constraints_of(clause):
		assert isinstance(literal.term, App)
		assert isinstance(literal.term.operator, App)
		lhs = literal.term.operator.operand
		rhs = literal.term.operand
		if lhs == rhs:
			db(f"Triv: removed trivial {literal.term} in clause {clause}")
			literal.term = "true"
			literal.pol = False
			changed = True
	if changed:
		db("Triv: changed")
	return changed

def _rule_subst(context : Ctx, clause : Clause, constants : set) -> bool:
	db("Subst: running...")

	changed = False
	substitutions = {}
	for literal in _constraints_of(clause):
		assert isinstance(literal.term, App)
		assert isinstance(literal.term.operator, App)
		lhs = literal.term.operator.operand
		rhs = literal.term.operand

		# This rule is suspicious: we should do both substitutions, the paper also says
		# it needs to be an MGU for completeness, but that doesn't make any sense. If they're both free, the substitution should go both ways

		#Clause is "solved" if LHS is not free in RHS. 
		if isinstance(lhs, str) and lhs not in constants and lhs not in free_variables(rhs, []):
			substitutions[lhs] = rhs
			literal.term = "true" ; literal.pol = False ; changed = True
		elif isinstance(rhs, str) and rhs not in constants and rhs not in free_variables(lhs, []):
			substitutions[rhs] = lhs
			literal.term = "true" ; literal.pol = False ; changed = True

	for any_literal in clause:
		for r in free_variables(any_literal.term, []):
			if sub := substitutions.get(r, False):
				any_literal.term = substituted(r, sub, any_literal.term)
				db(f"Subst: substituted {r} for {sub} in {any_literal.term} in clause {clause}")
				changed = True

	if changed:
		db("Subst: changed")
	return changed

def _rule_gb(context : Ctx, clause : Clause, constants : set) -> bool:
	return False # TODO!

def _apply_unification_rules_once(ctx : Ctx, cnf : CNF, cst : set) -> bool:
	any_changed = False
	for rule in [
		_rule_alpha,
		_rule_eta,
		_rule_dec,
		_rule_triv,
		_rule_subst,
	]:
		any_changed |= _apply_rule(ctx, rule, cnf, cst)
		_pc(cnf, ctx)
	
	# TODO: check occurs etc.
	if any_changed:
		db(f"UNIF: changed")
	else:
		db(f"UNIF: no change")
	return any_changed


def _rule_res(ctx : Ctx, cnf : CNF, max_resolvents : int = 3):
	db(f"RES: running...")
	resolvents = 0
	bumpable = []
	for i in range(len(cnf)):
		for j in range(i + 1, len(cnf)):
			n_clause = cnf[i]
			m_clause = cnf[j]
			for n in range(len(n_clause)):
				for m in range(len(m_clause)):
					n_lit = n_clause[n]
					m_lit = m_clause[m]
					if n_lit.pol != m_lit.pol:
						try:
							n_at = approximate_type_check(n_lit.term, ctx)
							m_at = approximate_type_check(m_lit.term, ctx)
							if n_at != m_at:
								print(f"Approximate types of {n_lit} ({n_at}), {m_lit} ({m_at}) differed so resolution skipped")
								continue
						except InvalidType:
							continue
						c = [n_clause[a] for a in range(len(n_clause)) if a != n]
						d = [m_clause[a] for a in range(len(m_clause)) if a != m]
						m_obs = type_check_obligations(m_lit.term, [], ctx)
						n_obs = type_check_obligations(n_lit.term, [], ctx)

						cnf.append(Clause(c + d + [Literal(EQ(n_obs[0], n_lit.term, m_lit.term), False)]))
						# for ob in n_obs[2] + m_obs[2]:
						# 	cnf[-1].append(Literal(EQ(TP, ob[0], ob[1]), False))
						# if n_obs[0] != m_obs[0]:
						# 	cnf[-1].append(Literal(EQ(TP, n_obs[0], m_obs[0]), False))

						# eq_type = type_check(n_lit.term, [], ctx, True)
						# cnf.append(Clause(c + d + [Literal(EQ(eq_type, n_lit.term, m_lit.term), False)]))
						# m_type = type_check(m_lit.term, [], ctx, True)
						# if m_type != eq_type:
						# 	cnf[-1].append(Literal(EQ(TP, m_type, eq_type), False))
							
						db(f"RES: Added unif constraint clause {cnf[-1]} from clauses ({i}, {j})")

						bumpable.append(i) ; bumpable.append(j)
						resolvents += 1
						if resolvents >= max_resolvents:
							db(f"RES done (maxed={resolvents}).")
							for bump_idx in bumpable: # Inefficient algorithm but who cares? Honestly?
								cnf.append(cnf[bump_idx])
								cnf.pop(bump_idx) 
							return
	for bump_idx in bumpable: # Inefficient algorithm but who cares? Honestly?
		cnf.append(cnf[bump_idx])
		cnf.pop(bump_idx) 
						
	db(f"RES: did {resolvents} resolvents")

def _rule_fac(ctx : Ctx, cnf : CNF, max_resolvents : int = 3):
	#db(f"FAC: running...")
	resolvents = 0
	factors = []
	bumpable = []
	for i in range(len(cnf)):
		clause = cnf[i]
		for n in range(len(clause)):
			for m in range(n + 1, len(clause)):
				n_lit = clause[n]
				m_lit = clause[m]
				if n_lit.pol == m_lit.pol:
					try:
						if approximate_type_check(n_lit.term, ctx) != approximate_type_check(m_lit.term, ctx):
							continue
					except InvalidType:
						continue
					c = [clause[a] for a in range(len(clause)) if a != n and a != m]
					#db(f"(ctx was {Ctx(ctx)})")
					n_obs = type_check_obligations(n_lit.term, [], ctx)
					m_obs = type_check_obligations(m_lit.term, [], ctx)
						
					factors.append(Clause(c + [n_lit, Literal(EQ(n_obs[0], n_lit.term, m_lit.term), False)]))
					# for ob in n_obs[2] + m_obs[2]:
					# 	factors[-1].append(Literal(EQ(TP, ob[0], ob[1]), False))
					# if n_obs[0] != m_obs[0]:
					# 	factors[-1].append(Literal(EQ(TP, n_obs[0], m_obs[0]), False))

					db(f"FAC: Added unif constraint clause {factors[-1]} from clause ({i})")
					bumpable.append(i)
					resolvents += 1
					if resolvents >= max_resolvents:
						cnf.extend(factors)
						for i in bumpable:
							cnf.append(cnf[i])
							cnf.pop(i)
						db(f"FAC done (maxed).")
						return
	
	for i in bumpable:
		cnf.append(cnf[i])
		cnf.pop(i)
	cnf.extend(factors)
	db(f"FAC done.")

def _rule_prim(ctx : Ctx, cnf : CNF):
	return

def _pc(cnf : CNF, ctx : Ctx) -> bool:
	cnf_clean_inplace(cnf)
	remove_ill_typed(ctx, cnf)
	db(f"------------------ CNF = {str(CNF(cnf))}...")
	if len(cnf) == 0:
		raise Valid
	for i in range(len(cnf)):
		c = cnf[i]
		if _is_almost_empty(c):
			cnf.pop(i)
			raise Unsatisfiable(c)
			

def resolve(ctx : Ctx, cnf : CNF, constants : set, stop_rounds : int = 100, show_progress : bool = True) -> Generator[Clause, None, None]:
	# The normalisation function we use here is a shortcut for logical axioms, it's nowhere near complete.
	empty_clauses = []
	global debug_hores ; debug_hores = show_progress

	for i in range(stop_rounds):
		try:
			print(f"Resolving, step = {i}, clauses = {len(cnf)}, context = {len(ctx)}")
			db(f"------------------ Resolving CNF -------------------")
			normalise_cnf(constants, cnf, ctx)
			_rule_res(ctx, cnf)
			_pc(cnf, ctx)
			_rule_fac(ctx, cnf)
			_pc(cnf, ctx)
			_apply_unification_rules_once(ctx, cnf, constants)
			_pc(cnf, ctx)
			normalise_cnf(constants, cnf, ctx)
			_pc(cnf, ctx)
		except Unsatisfiable as u:
			# if any([aeq(c,u.args[0]) for c in empty_clauses]):
			# 	db(f"Produced empty clause {u} but it was a duplicate")
			# else:
				db(f"Resolving produced empty clause... {u}")
				empty_clauses.append(u.args[0])
				yield u.args[0]

		except Valid:
			db("Resolving finished (formula is valid")
			raise StopIteration
		except KeyboardInterrupt:
			db(f"Resolving terminated by user. CNF had {len(cnf)} clauses")
			raise StopIteration
	
	db(f"Resolving finished (max iters)")
		