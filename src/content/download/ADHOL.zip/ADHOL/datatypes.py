

TP = "*"
BOX = "[_]"

class Ctx(list[tuple]):
	def __str__(self):
		s = "["
		for pair in self:
			s += f"({pair[0]}: {pair[1]})"
		return s + "]"

class Thy(Ctx):
	pass

class InvalidType(Exception):
	pass

class Term: # Abstract
	def __str__(self):
		return "Error: abstract term"
	
	def size(self):
		return 0
	
	def __hash__(self):
		return canonical_string(self).__hash__()
	
	def __eq__(self, other):
		return self.__class__ == other.__class__ and canonical_string(self) == canonical_string(other)


class Quantifier(Term): # Abstract
	var 		: str
	var_type	: Term | str
	body 		: Term

	def __init__(self, var : str, typ : Term | str, body : Term):
		self.var = var
		self.var_type = typ
		self.body = body
	
	def size(self):
		return 1 + self.body.size()


class All(Quantifier):
	def __str__(self):
		return f"(∀{self.var}:{self.var_type}. {self.body})"

class Ext(Quantifier):
	def __str__(self):
		return f"(∃{self.var}:{self.var_type}. {self.body})"

class Abs(Quantifier):
	def __str__(self):
		if self.var_type:
			return f"(λ{self.var}:{self.var_type}. {self.body})"
		return f"(λ{self.var}. {self.body})"
	
class Pi(Quantifier):
	def __str__(self):
		if self.var != "":
			return f"(Π{self.var}:{self.var_type}. {self.body})"
		return f"({self.var_type} → {self.body})"

class App(Term):
	operator 	: Term
	operand 	: Term

	def __init__(self, h : Term, b : Term):
		self.operator = h
		self.operand = b

	def __str__(self):
		return _stringify_if_boolean_application(self)
	
	def size(self):
		return self.operator.size() + self.operand.size()


def is_unary_app(term : Term, operator : Term):
	return isinstance(term, App) and term.operator == operator

def is_binary_app(term : Term, operator : Term):
	return isinstance(term, App) and is_unary_app(term.operator, operator)

def is_ternary_app(term : Term, operator : Term):
	return isinstance(term, App) and is_binary_app(term.operator, operator)

def is_eq(term : Term):
	return isinstance(term, App) and isinstance(term.operator, App) and isinstance(term.operator.operator, str) and term.operator.operator.startswith("EQ_")

def eq_parts(term : Term):
	assert is_eq(term)
	return term.operator.operand, term.operand

class Literal():
	term : Term | str
	pol : bool 

	def __init__(self, term_ : Term | str, pol_ : bool):
		if isinstance(term_, App) and term_.operator == "NOT":
			term_ = term_.operand
			pol_ = not pol_
		self.term = term_
		self.pol = pol_
	
	def __bool__(self):
		return self.pol
	
	def __str__(self):
		if not self.pol:
			return f"~({self.term})"
		return f"({self.term})"
	
class Clause(list[Literal]):
	def __init__(self, lst : list[Literal]):
		self.extend(lst)

	def __str__(self):
		literals = ""
		for l in range(len(self)):
			literals += str(self[l])
			if l != len(self) - 1:
				literals += ", "
		return "{" + literals + "}"

class CNF(list[Clause]):
	def __str__(self):
		clauses = ""
		for c in range(len(self)):
			clauses += str(Clause(self[c]))
			if c != len(self) - 1:
				clauses += ", "
		return "(" + clauses + ")"

def _stringify_if_boolean_application(app : App):
	if isinstance(app.operator, str):
		if app.operator == "not":
			return f"(~{app.operand})"
	if isinstance(app.operator, App):
		if isinstance(app.operator.operator, str):
			if app.operator.operator.startswith("EQ_"):
				return f"({app.operator.operand} == {app.operand})" # Strongly typed non-polymorphic equality (types internally represented in signature)
			if is_binary_app(app, "and"):
				return f"({app.operator.operand} ⋀ {app.operand})"
			if is_binary_app(app, "or"):
				return f"({app.operator.operand} ⋁ {app.operand})"
			if is_binary_app(app, "impl"):
				return f"({app.operator.operand} ⇒ {app.operand})"
			if is_binary_app(app, "eq"):
				return f"({app.operator.operand} = {app.operand})" # Untyped equality
	return f"({app.operator} {app.operand})"


def long_abs(*terms):
	if len(terms) < 1:
		raise ValueError
	if len(terms) == 1:
		return terms[0]
	if isinstance(terms[0], str):
		return Abs(terms[0], "", long_abs(*terms[1:]))
	else:
		return Abs(terms[0][0], terms[0][1], long_abs(*terms[1:]))

def long_pi(*terms):
	if len(terms) < 1:
		raise ValueError(terms)
	if len(terms) == 1:
		if isinstance(terms[0], str):
			return terms[0]
		elif isinstance(terms[0], tuple):
			return terms[0][0]
		else:
			return terms[0]
	
	if isinstance(terms[0], str):
		return Pi(terms[0], "", long_pi(*terms[1:]))
	elif isinstance(terms[0], tuple):
		return Pi(terms[0][0], terms[0][1], long_pi(*terms[1:]))
	else:
		raise ValueError(terms)

# Applies (f x y), e.g, like ((f x) y).
def long_app(*terms):
	if len(terms) < 1:
		print(terms)
		raise ValueError
	if len(terms) == 1:
		return terms[0]
	if len(terms) == 2:
		return App(terms[0], terms[1])
	return App(long_app(*terms[:-1]), terms[-1])

# Applies (x y z) like ((x AND y) AND z)
def conj(*terms):
	if len(terms) == 0:
		return "true"
	if len(terms) == 1:
		return terms[0]
	return App(App("and", terms[0]), conj(*terms[1:]))

def disj(*terms):
	if len(terms) == 0:
		return "false"
	if len(terms) == 1:
		return terms[0]
	return App(App("or", terms[0]), disj(*terms[1:]))

def canonical_string(term : Term, debruijn : dict = {}) -> tuple:
	if isinstance(term,str):
		return debruijn.get(term, term)
	if isinstance(term,App):
		return (canonical_string(term.operand), canonical_string(term.operator)) # Optimisation based on LHNF
	if isinstance(term, Quantifier):
		if term.var:
			debruijn[term.var] = len(debruijn) + 1
		if isinstance(term, Abs):
			qf = "L"
		elif isinstance(term, Pi):
			qf = "P"
		elif isinstance(term, All):
			qf = "A"
		elif isinstance(term, Ext):
			qf = "E"
		ret = (qf, canonical_string(term.var_type, debruijn), canonical_string(term.body, debruijn))
		if term.var:
			debruijn.pop(term.var)
		return ret
	if isinstance(term, Literal):
		return canonical_string(term.term if term.pol else App("not", term.term))
	
	raise ValueError(term)
