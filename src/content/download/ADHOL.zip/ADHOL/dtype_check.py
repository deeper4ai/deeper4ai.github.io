
from odter import *
from boolean import cnf_convert


def type_check_cnf(cnf : CNF, sig : Sig, ctx : Ctx, debug_level : int = 0, filename : str = "", resolution_timeout : int = 50 * SECONDS):
	db = lambda s : debug_level >= 1 and print(f"type_check_cnf: {filename}: {s}")
	dbx = lambda s : debug_level >= 2 and print(f"type_check_cnf: {filename}: {s}")
	set_odter_sig(sig)
	set_sig(sig)

	db(f"Ctx = {Ctx(ctx)}")
	fcnf = to_fcnf(cnf, ctx) # Converts and copies
	db(f"FCNF =")
	for fclause in fcnf:
		db(f"\t{fclause.clindex}: {fclause}")
	
	tcnf = []
	last_iter_filtered = []

	for flindex in range(len(fcnf)):
		fclause = fcnf[flindex]
		db(f"Processing clause {fclause.clindex}: {fclause}")
		db(f"Clause ctx = {fclause.a}")

		if last_iter_filtered:
			db(f"Carried {len(last_iter_filtered)} theorems from previous iteration")

		# We go left-to-right because it is more sound to prove type correctness using only type-correct clauses
		# however (probably) the type-correctness can depend on any clause since they do not share variables.
		# 
		ordinary_indexes = {fcnf[i].clindex for i in range(0, flindex)}
		tcnf = [fcnf[i] for i in range(0, flindex)] + [l for l in last_iter_filtered if l.clindex not in ordinary_indexes]
		negated_ctx = fclause.a

		for i in range(len(fclause)):
			ns = perf_counter_ns()

			if is_flat_eq(fclause[i].term):
				# HACK: sig may store incorrect equality type (i.e. unflattened version). Assume it is always LHS-typed
				lhs_type,_ = flat_type_check_native(fclause[i].term.arguments[0], sig, negated_ctx, [], 0)
				if not lhs_type:
					raise TypeError(fclause[i].term.arguments[0])
				fclause[i].term.head = sig.equality_symbol_for_type(lhs_type)

			term_type,obs = flat_type_check_native(fclause[i].term, sig, negated_ctx, [], 0)
			if term_type and not obs:
				db(f"Literal {fclause[i]} is trivially well-typed")
				tcnf.append(FClause([FLiteral(not fclause[i].pol, fclause[i].term)], negated_ctx)) # Append negation
				tcnf[-1].heritage.append(fclause.clindex)
				continue
			if not term_type:
				raise TypeError(fclause[i].term)
			
			db(f"Proving literal {fclause[i]} is well-typed")
			dclause : list[FLiteral] = []

			for o1,o2 in obs:
				db(f"Attempting to encode obligations {o1}==={o2}")
				lhs_type,oobs = flat_type_check_native(o1, sig, negated_ctx, [], 0)
				if lhs_type == None or oobs:
					print(f"Failed to get obligation-free type of obligation {o1} with sig constants = {sig.constants}, and ctx = {negated_ctx}")
					raise InvalidType
				
				term = FlatTerm([], sig.equality_symbol_for_type(lhs_type), [o1, o2])
				
				unif = Unifier()
				for fv in free_variables_native(term, [], True):
					unif[fv] = sig.next_const()
					sig.constants[unif[fv]] = get_from_context(sig, negated_ctx, fv)
					if sig.constants[unif[fv]] == None:
						print(f"Failed to get type of fv={fv} in term {term} with context={negated_ctx} and sig={sig}")
				term = flat_substituted(unif, term) # Skølemise replacing free variables, because we are negating this

				dclause.append(FLiteral(False, term))
			
			db(f"Type checking with {len(tcnf)} assumptions")
			for t in tcnf:
				dbx(f"\t{t.clindex}: {t}")
			


			tcnf.append(FClause(dclause, negated_ctx))
			tcnf[-1].heritage = [fclause.clindex]
			tcnf[-1].inferences.append("type_obligation")
			conjecture_index = tcnf[-1].clindex

			db(f"The literal is well-typed iff the following is unsatisfiable:")
			db(f"\t{conjecture_index}: {tcnf[-1]}")

			unifs = resolve_odter([], [], sig, debug_odter=(debug_level>=1), debug_show_resolvents=(debug_level>=2), debug_extreme=(debug_level>=3), filename=f"{filename}(TC)", 
				resolution_timeout=ns+resolution_timeout,
				unprocessed=tcnf, active=[], passive=[]
			)

			type_proven = False
			for u,tup in unifs:
				type_proven = True
				nns = perf_counter_ns()
				db(f"Proof succeeded: {flindex}:{i} > {fmt_ns(nns - ns, 0.1)}")
				db("")
				print_odter_success((u,tup))

				# Cache all resolvents that are not associated with the conjecture, as they are still valid in next iteration
				tcnf = filter_consistent_heritage(tup, conjecture_index, debug_level=debug_level)
				tcnf.append(FClause([FLiteral(not fclause[i].pol, fclause[i].term)], negated_ctx)) # Add the negation of the literal we just proved is type correct
				tcnf[-1].heritage.append(fclause.clindex)
				db(f"{len(tcnf)} theorems valid in negated clause-{fclause.clindex} theory will be carried")
				break

			if not type_proven:
				nns = perf_counter_ns()
				db(f"Proof failed:    {flindex}:{i} > {fmt_ns(nns - ns, 0.1)}")
				return False
		
		if flindex < len(fcnf) - 1:
			last_iter_filtered = filter_consistent_heritage((tcnf,[],[],[]), fclause.clindex)
		
	return True


def filter_consistent_heritage(res_clauses : tuple, conjecture_index : int, debug_level : int = 0) -> FCNF:
	if debug_level >= 2:
		print(f"filter_consistent_heritage: filtering based on index {conjecture_index}")
		set_names = ["active", "passive", "unprocessed", "dead"]
		for i in range(len(res_clauses)):
			print(f"filter_consistent_heritage: set {set_names[i]}")
			for r in sorted(res_clauses[i], key=lambda x : x.clindex):
				print(f"\t{str(r.heritage):>10} ⊢ {r.clindex}: {r}")

	generated_clauses : list[FClause] = res_clauses[0] + res_clauses[1] + res_clauses[2] + res_clauses[3] # active + passive + unprocessed + DEAD
	if debug_level >= 2:
		generated_clauses.sort(key=lambda c : c.clindex)
	# The inclusion of DEAD is because a clause might have been subsumed by an inconsistent clause, meaning that 
	# it may not have been subsumed by a consistent clause, i.e. it should still be valid

	# Proceed forward through the clause set and propagate "inconsistent" property
	# Clauses which are consistent will not have the negated conjecture in their heritage
	inconsistent = [conjecture_index]
	to_pop = {conjecture_index}
	while inconsistent:
		c = inconsistent.pop()
		for clause in generated_clauses:
			if clause.clindex in to_pop: # Already caught
				continue
			if c in clause.heritage:
				inconsistent.append(clause.clindex)
				to_pop.add(clause.clindex)

	if debug_level >= 1:
		total = len(generated_clauses)
		filtered = len(to_pop)
		print(f"filter_consistent: filtered {filtered}/{total} ({int(100*filtered/total)}%)")
		if debug_level >= 1:
			for c in generated_clauses:
				if c.clindex in to_pop:
					print(f"\t{str(c.heritage):>10} |- {c.clindex}: {c}")
	
	# There is possibly a trick here with active and passive, but naively assuming active=active' and passive=passive' 
	# appears to lead to incompleteness. We assume all of them are unprocessed to force reprocessing, but this
	# is probably causing a significant slowdown (25_000+ unprocessed is very slow)

	return [c for c in generated_clauses if c.clindex not in to_pop]
