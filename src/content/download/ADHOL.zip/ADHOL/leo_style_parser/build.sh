#!/bin/sh

rm -rf ./build
rm -rf ./bin

cmake -DCMAKE_OSX_SYSROOT=$(xcrun --sdk macosx --show-sdk-path) -B./build -S./src/cpp
cd ./build
make
