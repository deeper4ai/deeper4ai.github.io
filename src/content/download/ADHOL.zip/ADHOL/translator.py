
from flat_term import *
from hol import *
from elliott import lhnf, set_sig, LHNFError


''' TODO
- 

Procedure to automatically run Leo on the outputs
'''
DEBUG = 1
def erased(cnf : CNF, ctx : Ctx, sig : Sig) -> tuple[CNF, Ctx, Sig]:
	
	if DEBUG:
		print(f"Performing erasure on CNF:")
		for clause in cnf:
			print(f"\t{clause}")
		print(f"\nCNF had context: {Ctx(ctx)}")
		print(f"\nSignature = {sig}")
		print()

	unif = Unifier()

	# Generate direct type obligations and add them to clauses
	for clause in cnf:
		obligations = set()
		for literal in clause:
			
			_,obs = type_check_obligations(literal.term, sig, [], ctx)
			obs = set(obs)

			if DEBUG and obs:
				print(f"Type checking literal {literal} gave {len(obs)} obligations:")
				for o in obs:
					print(f"\t[{o[0]}={o[1]}]")

			while obs:
				o1,o2 = obs.pop()
				
				DEBUG and print(f"Popped obligations o1={o1}, o2={o2}")

				if aeq(o1,o2):
					DEBUG and print(f"Disagreement trivial, continuing")
					continue
				
				otype = type_check(o1, sig, [], ctx)

				DEBUG and print(f"Checking disagreement between o1={o1} : {otype}, o2={o2}")

				if otype == TP:
					breakdown = _break_down_types(o1, o2, ctx, sig)
					if breakdown == None:
						raise LHNFError
					DEBUG and print(f"Disagreement was between types, breakdown = {Eqns(breakdown)}, adding to set...")
					obs |= breakdown
					continue
				
				ob_literal = Literal(long_app(sig.equality_symbol_for_type(otype), o1, o2), False)
				if ob_literal in obligations:
					continue
				
				DEBUG and print(f"Added obligation literal {ob_literal} to clause")

				obligations.add(ob_literal)
				_,oobs = type_check_obligations(ob_literal.term, sig, [], ctx)

				if DEBUG and oobs:
					print(f"Type checking recursive obligations for {ob_literal.term}:")
					for o in oobs:
						print(f"\t[{o[0]}={o[1]}]")

				obs |= set(oobs)

		clause.extend(obligations)

		DEBUG and print(f"Clause after obligations = {clause}")

	# Get stuff from da signature TODO: types cannot be functions
	new_sig = Sig()
	for constant in sig.constants:
		
		if constant in METALOGIC:
			continue
		
		approximated = type_approximate(sig.constants[constant])
		if not aeq(approximated, sig.constants[constant]):
			const_minus = constant + "Minus"
			unif[constant] = const_minus
			approx = type_approximate(sig.constants[constant])

			if _is_type(approx):
				new_sig.constants[const_minus] = TP
			else:
				new_sig.constants[const_minus] = approx
		else:
			if _is_type(sig.constants[constant]):
				new_sig.constants[constant] = TP
			else:
				new_sig.constants[constant] = sig.constants[constant]


	new_ctx = Ctx()
	for sym,typ in ctx:
		approximated = type_approximate(typ)

		if aeq(approximated, typ):
			new_ctx.append((sym,fast_applied_unifier(typ, unif)))
			continue
		
		var_minus = sym + "Minus"
		new_ctx.append((var_minus, approximated))
		unif[sym] = var_minus
	
	# Deep update, slow 
	changed = True
	while changed:
		changed = False
		for sym,typ in new_sig.constants.items():
			new_typ = fast_applied_unifier(typ, unif, True)
			if not aeq(new_typ, typ):
				changed = True
				new_sig.constants[sym] = new_typ

		for i in range(len(new_ctx)):
			sym,typ = new_ctx[i]
			new_typ = fast_applied_unifier(typ, unif, True)
			if not aeq(new_typ, typ):
				changed = True
				new_ctx[i] = (sym, new_typ)
				

	new_cnf = CNF()
	for clause in cnf:
		new_clause = Clause([])

		for literal in clause:
			new_literal = Literal(fast_applied_unifier(literal.term, unif), literal.pol)
			new_clause.append(new_literal)

		new_cnf.append(Clause(new_clause))
	
	if DEBUG:
		print(f"Erasure completed, new CNF:")
		for clause in new_cnf:
			print(f"\t{clause}")

	return new_cnf,new_ctx,new_sig

def _is_type(term : Term):
	if isinstance(term, str) and term == TP:
		return True
	if isinstance(term, Pi):
		return _is_type(term.body)
	return False

def erased_cnf(cnf : CNF, ctx : Ctx, sig : Sig):
	return format_cnf(*erased(cnf, ctx, sig), True)

def format_cnf(cnf : CNF, ctx : Ctx, sig : Sig, as_hol : bool = False):
	contents = []

	i = 0
	metal = {s[0] for s in METALOGIC}
	for s in sig.constants:
		if s in metal:
			continue
		contents.append(f"thf(ty{i},type,{s}:\n\t{_format_term(sig.constants[s], as_hol)}).\n")
		i += 1

	i = 0
	for clause in cnf:
		as_plain = _format_clause(clause, ctx, sig, as_hol)
		if i < len(cnf) - 1:
			contents.append(f"thf(cnf{i},axiom,\n\t{as_plain}).\n")
		else:
			# Spuriously treat the final clause as a negated conjecture (it is indeed already negated)
			# LEO wants to see either a conjecture or negated_conjecture to do resolution
			contents.append(f"thf(cnf{i},negated_conjecture,\n\t{as_plain}).\n")
		i += 1
	
	return contents


def _format_clause(f : Clause, ctx : Ctx, sig : Sig, as_hol : bool = False) -> str:
	
	as_term = (disj(*[l.term if l.pol else NOT(l.term) for l in f]))

	s = ""
	context = _relevant_context(f, ctx, sig)
	if len(context) > 0:
		return f"( ! [{", ".join([f"{c[0]}: {_format_term(c[1], as_hol)}" for c in context])}] : ( {_format_term(as_term, as_hol)} ) )"
	else:
		return f"{_format_term(as_term, as_hol)}"



def _relevant_context(c : Clause, ctx : Ctx, sig : Sig):
	relevant = free_variables(c, sig.constants, True)
	done = set()
	rectx = Ctx()

	while relevant:
		p = relevant.pop()
		if p.startswith("EQ"):
			continue
		if p in sig.constants:
			continue
		if p in done:
			continue
		t = get_from_context(sig, ctx, p)
		if t == None:
			raise ValueError(p, "in", str(Clause(c)), "ctx", str(Ctx(ctx)), "sig", str(sig))
		rectx.append((p, t))
		relevant |= free_variables(t, [], True)
		done.add(p)
	
	return rectx

primitive_binary = {
	"impl" : "=>",
	"and" : "&",
	"or" : "|",
}
primitive_type = {
	BOX : "$tType",
	TP : "$tType",
	"bool" : "$o",
	"ind" : "$i",
}

def _format_term(t : Term, as_hol : bool = False) -> str:
	if isinstance(t, Literal):
		if t.pol:
			return _format_term(t.term, as_hol)
		return _format_term(NOT(t.term), as_hol)

	if isinstance(t, Quantifier):
		if isinstance(t, Pi) and not as_hol:
			return f"!>[{t.var}: {_format_term(t.var_type, as_hol)}] : {_format_term(t.body, as_hol)}"
		elif isinstance(t, Pi):
			if isinstance(t.var_type, Pi):
				return f"({_format_term(t.var_type, as_hol)}) > {_format_term(t.body, as_hol)}"
			return f"{_format_term(t.var_type, as_hol)} > {_format_term(t.body, as_hol)}"
		elif isinstance(t, Ext):
			return f"? [{t.var}: {_format_term(t.var_type, as_hol)}] : {_format_term(t.body, as_hol)}"
		elif isinstance(t, All):
			return f"! [{t.var}: {_format_term(t.var_type, as_hol)}] : {_format_term(t.body, as_hol)}"
		elif isinstance(t, Abs):
			return f"^ [{t.var}: {_format_term(t.var_type, as_hol)}] : {_format_term(t.body, as_hol)}"

	elif isinstance(t, str):
		return primitive_type.get(t, t)
	
	elif isinstance(t, App):
		# Binary boolean primitive
		if isinstance(t.operator, str) and t.operator == "not":
			return f"( ~ ( {_format_term(t.operand, as_hol)} ) )"
		symbol = "@"
		if isinstance(t.operator, App) and isinstance(t.operator.operator, str):
			# Check infix
			if t.operator.operator.startswith("EQ"):
				symbol = "="
			else:
				symbol = primitive_binary.get(t.operator.operator, "")

			if symbol:
				return f"( {_format_term(t.operator.operand, as_hol)} {symbol} {_format_term(t.operand, as_hol)} )"
			
			return f"( {_format_term(t.operator, as_hol)} @ {_format_term(t.operand, as_hol)} )"

		return f"( {_format_term(t.operator, as_hol)} {symbol} {_format_term(t.operand, as_hol)} )"
	
	raise ValueError


def _break_down_types(s : Term, t : Term, ctx : Ctx, sig : Sig) -> set[tuple] | None:
	'''
	Turn a disagreement of types into a disagreement of their arguments. Returns
	None if the types are incompatible (different heads, different structures, or not $tType)
	See Elliott (1989)
	'''
	set_sig(sig)
	# Use flat terms because it's easier (namely head access)
	fs = lhnf(s, [], ctx)
	ft = lhnf(t, [], ctx)
	s_head_type = get_from_context(sig, ctx, fs.head)
	t_head_type = get_from_context(sig, ctx, ft.head)
	dags = set()

	if s_head_type != t_head_type:
		return None
	if len(fs.quantifiers) != len(ft.quantifiers):
		return None
	if len(fs.arguments) != len(ft.arguments):
		return None

	DEBUG and print(f"Breakdown: terms {s}, {t} had disagreements:")

	for i in range(len(fs.quantifiers)):
		dags.add((fs.quantifiers[i][1], ft.quantifiers[i][1]))
		DEBUG and print(f"\tQ: {fs.quantifiers[i][1]}, {ft.quantifiers[i][1]}") 
	for j in range(len(fs.arguments)):
		dags.add((fs.arguments[j], ft.arguments[j]))
		DEBUG and print(f"\tA: {fs.arguments[j]}, {ft.arguments[j]}") 
	
	return {(unflatten(d1), unflatten(d2)) for d1,d2 in dags}