from typing import Generator
from hol import *
from flat_term import *
from elliott import *
from boolean import cnf_convert


SIG : Sig
CLINDEX : int 	= 0
DEBUG_STEP 		= False
DEBUG_ODTER 	= False
DEBUG_ODTER_XTR	= False
DEBUG_UNIF 		= False
DEBUG_RVENTS	= False

DEAD 			= []

def dbp(s): DEBUG_ODTER and print(s)
def dbx(s): DEBUG_ODTER_XTR and (input(s) if DEBUG_STEP else print(s))
def dbu(s): DEBUG_UNIF and print(s)
def dbr(s): DEBUG_RVENTS and print(s)

class FClause(list[FLiteral]): 
	a : Ctx
	clindex : int
	heritage : list
	inferences : list
	def __init__(self, l : list, c : Ctx, skip_cache : bool = False, skip_rename : bool = False, skip_clindex : bool = False):
		self.extend([FLiteral(ll.pol, copy_flat_term(ll.term)) for ll in l])
		self.a = []
		self.a.extend(c)
		self.constants_in = set()
		self.prebin_l = Ctx()
		self.prebin_r = {}
		self.heritage = []
		self.inferences = []
		if not skip_clindex:
			global CLINDEX ; self.clindex = CLINDEX ; CLINDEX += 1
		if not skip_rename:
			self.rename()
		if not skip_cache:
			self.subsumption_recache()
	
	def __str__(self):
		s = "{"
		for l in self:
			s += f"[{l}], "
		return s + "}"
	
	def trivialise(self):
		self.clear() ; self.a = [] ; self.prebin_l = Ctx() ; self.prebin_r = {}
		self.constants_in = {'true'}
		self.append(FLiteral(True, FlatTerm([], 'true', [])))
	
	constants_in : set
	prebin_l : Ctx
	prebin_r : dict

	def num_with_pol(self, pol : bool):
		return len([1 for l in self if l.pol == pol])

	def subsumption_recache(self):
		self.prebin_l = [(fv, flat_canonical_string(approximate_type(flatten(ty)), {})) for fv,ty in self.a]
		r = {typ:[] for typ in [t for _,t in self.prebin_l]}
		for v,t in self.prebin_l:
			r[t].append(v)
		self.prebin_r = r

	# Checks if a clause consists only of flex-flex inequalities. If so, then the problem is trivially solvable
	def is_almost_empty(self):
		for l in self:
			if l.pol or not is_flat_eq(l.term):
				return False
			lhs,rhs = flat_eq_parts(l.term)
			for side in [lhs,rhs]:
				if side.quantifiers or side.head in SIG.constants:
					return False
			if lhs.head == rhs.head:
				# If the sides are the same we cannot necessarily always solve it unless we prove args are the same
				if not all(flat_aeq(lhs.arguments[i],rhs.arguments[i], {}) for i in range(len(lhs.arguments))):
					return False
		return True

	# Rename variables in an indexed fashion by the clindex. Will also remove unused context variables
	def rename(self, force_reindex : bool = False):
		if force_reindex:
			global CLINDEX ; self.clindex = CLINDEX ; CLINDEX += 1
		
		free = _simplify_free(self)
		subs = Unifier({fv: _renamed(fv, self.clindex) for fv in free})

		for sub in subs:
			if get_from_context(SIG, self.a, sub) == None:
				print(f"Failed to get variable {sub} from context")
				print(f"In clause index {self.clindex} with ctx={Ctx(self.a)}")
				raise ValueError

		# dbx(f"rename: renaming clause {self.clindex} using subs {Unifier(subs)}")
		# dbx(f"rename: old clause = {self}")
		# dbx(f"rename: old ctx = {Ctx(self.a)}")

		# Substitute in terms
		for i in range(len(self)):
			self[i].term = flat_substituted(subs, self[i].term)
		new_ctx = Ctx()

		# Substitute in types: this does not have to be transitive because all substitutions are atomic
		for j in range(len(self.a)):
			if self.a[j][0] not in subs:
				new_ctx.append((self.a[j][0], flat_substituted(subs, self.a[j][1])))

		new_ctx.extend([(subs[s], flat_substituted(subs, get_from_context(Sig(), self.a, s))) for s in subs])
		self.a = new_ctx

		# dbx(f"rename: new clause = {self}")
		# dbx(f"rename: new ctx = {self.a}")

	
def set_odter_sig(sig : Sig):
	global SIG ; SIG = sig
	set_sig(sig)

def _renamed(var : str, index : int):
	return var.split(".")[0].replace("v","")+"."+str(index)

class FCNF(list[FClause]):
	def __str__(self):
		s = "("
		for c in self:
			s += str(c) + ","
		return s + ")"

def to_fcnf(cnf : CNF, ctx : Ctx) -> FCNF:
	
	for i in range(len(ctx)):
		ctx[i] = (ctx[i][0], flatten(ctx[i][1]))

	fcnf = FCNF()
	for cidx in range(len(cnf)):
		literals = []
		for lidx in range(len(cnf[cidx])):
			l = cnf[cidx][lidx]
			#dbx(f"_to_fcnf: {l}")
			literals.append(FLiteral(l.pol, flatten(l.term)))
			#dbx(f"_to_fcnf: got {literals[-1]}")

		# This adds the whole context, but renaming will purge unused variables (it takes a surprisingly long time)
		fclause = FClause(literals, ctx)
		fcnf.append(fclause)
	
	#dbx(f"Flattened context = {ctx}")
	
	return fcnf

## Things to improve and test 
#	- Don't automatically remove Leibniz equality
#		- Improve clausal equality reasoning
#		- Permit resolution & factoring on unification constraints
#		- Allow equalities to be turned into Leibniz if desired
# 	- Add clause selection
#	- Improve subsumption? Look at literature, don't just guess
#	- Boolean extensionality, (mostly) meaning instantiation of predicates as booleans

def resolve_odter(cnf : CNF, ctx : Ctx, sig : Sig, 
			resolution_timeout 		: int 	= 0,
			timeout_finish_iter		: bool 	= False,
			reset_clindex 			: bool 	= False,
			debug_step 				: bool 	= False, 
			debug_odter 			: bool 	= False,
			debug_unif 				: bool 	= False,
			debug_extreme 			: bool 	= False,
			debug_show_resolvents 	: bool 	= False,
			filename 				: str 	= "",

			active 					: FCNF 	= None,
			passive 				: FCNF 	= None,
			unprocessed 			: FCNF 	= None
		) 							-> Generator[tuple[FClause, tuple], None, None]:
	global SIG ; SIG = sig
	global STEP ; STEP = debug_step
	global DEBUG_ODTER ; DEBUG_ODTER = debug_odter
	global DEBUG_UNIF ; DEBUG_UNIF = debug_unif
	global DEBUG_ODTER_XTR ; DEBUG_ODTER_XTR = debug_extreme
	global DEBUG_RVENTS ; DEBUG_RVENTS = debug_show_resolvents
	if reset_clindex: 
		global CLINDEX ; CLINDEX = 0

	DEAD.clear()
	set_sig(sig) # Ensures SIG is set in Elliott functions before conversion (for constants and to avoid namespace bugs)

	if not active: active = FCNF()
	if not passive: passive = FCNF()
	if not unprocessed: unprocessed = FCNF()

	unprocessed.extend(to_fcnf(cnf, ctx))
	given = None

	dbp(f"Beginning oDTer resolution with {len(unprocessed)} unprocessed ({len(cnf)} from cnf), {len(active)} active, {len(passive)} passive")
	if resolution_timeout:
		dbp(f"oDTer will time out in {int((resolution_timeout - perf_counter_ns())/SECONDS)} seconds")

	iter = 0
	while resolution_timeout == 0 or perf_counter_ns() <= resolution_timeout:
		
		dbp(f"{filename}: oDTer iter={iter}: unprocessed={len(unprocessed)}, active={len(active)}, passive={len(passive)}")
		iter += 1

		try:
			new = None
			new_unprocessed = []
			while unprocessed:
				new = unprocessed.pop()
				dbr(f"\nNew: processing {new.clindex}: {new}")
				if new.is_almost_empty():
					yield new, (active,passive,unprocessed,DEAD)
					return
				if _retain(new):
					_forward_simplify(new, active, passive)

					if new.is_almost_empty():
						yield new, (active,passive,unprocessed,DEAD)
						return
					
					if _retain(new):
						new_unprocessed.extend(_backward_simplify(active, passive, new))
						passive.append(new)
						continue
					
				dbr(f"{new.clindex} was not retained")
				
				if resolution_timeout == 0 or perf_counter_ns() <= resolution_timeout:
					continue
				return

			if not passive:
				return
			
			unprocessed = new_unprocessed
			given = _select_pop(passive)
			dbr(f"\nGiven = {given.clindex}: {given}")
			active.append(given)
			unprocessed.extend(_forward_infer(given, active))
			unprocessed.extend(_backward_infer(given, active))
			given = None

		except KeyboardInterrupt:
			print()

			if new and not given:
				unprocessed.append(new) # Put back in queue if interrupted (forces some repeated work)
			if given:
				passive.append(given)

			if new and not given:
				print(f"\nStopped while processing new = {new.clindex}: {new}")
			elif given:
				print(f"\nStopped while processing given = {given.clindex}: {given}")

			print(f"\nBase ctx = {ctx}")
			print(f"\nConstants including skolem = {SIG.constants}")
			print(f"\nUnprocessed (:20) = ")
			for i in range(min(len(unprocessed), 20)):
				print(f"\t{unprocessed[i].clindex:2>}: {unprocessed[i]}")
			print(f"\nActive (:20)      = ")
			for i in range(min(len(active), 20)):
				print(f"\t{active[i].clindex:2>}: {active[i]}")
			print(f"\nPassive (:20)     = ")
			for i in range(min(len(passive), 20)):
				print(f"\t{passive[i].clindex:2>}: {passive[i]}")


			print(f"\nTotals: active={len(active)}, passive={len(passive)}, unprocessed={len(unprocessed)}, dead={len(DEAD)}")
			try:
				wait_time = perf_counter_ns()
				response = input(f"CTRL+C again to stop (hard), otherwise 'skip' to end this resolution, anything else to continue \n > ")
				if response.lower() == "skip":
					return
				if response.lower() == "step":
					global DEBUG_STEP ; DEBUG_STEP = True
				resolution_timeout += perf_counter_ns() - wait_time
			except KeyboardInterrupt as e:
				raise e

##################
## Core inferences

def _select_pop(passive : FCNF) -> FClause:
	''' 
	Selects a clause from the passive set as the given clause
	'''
	return passive.pop(0)

def _retain(f : FClause):
	'''
	Decides whether a clause should be retained, i.e., it is not a tautology.
	Only checks for trivial tautologies, could do aeq testing as well
	'''
	for literal in f:
		if literal.pol == True and literal.term.head == 'true':
			return False
		if literal.pol == False and literal.term.head == 'false':
			return False
	return True

def _forward_simplify(d : FClause, active : FCNF, passive : FCNF) -> FCNF:
	'''
	Rewriting/demodulation ; subsumption ; unit deletion(?)
	'''
	_unification_replace(d)
	_clear_triv_false(d)
	if _forward_subsume_fclause(active, d) or _forward_subsume_fclause(passive, d):
		d.trivialise()

def _backward_simplify(active : FCNF, passive : FCNF, f : FClause) -> FCNF:
	'''
	rewriting/demodulation ; subsumption ; unit deletion (but backwards)
	'''
	leib = _leibnizify(f)
	_backward_subsume_fcnf(f, active)
	_backward_subsume_fcnf(f, passive)
	leib.extend(_simplify_unification_constraints(f))
	return leib

def _forward_infer(f : FClause, active : FCNF) -> FCNF:
	'''
	Perform resolution, paramodulation, ...
	'''
	rvents = FCNF()
	for a in active:
		if a.clindex == f.clindex:
			continue
		rvents.extend(_clause_resolvents(f, a))
	rvents.extend(_clause_factors(f))
	rvents.extend(_definitional_replaced(f, active))
	return rvents

def _backward_infer(f : FClause, active : FCNF) -> FCNF:
	'''
	likely to be redundant here because we are not 'scheduling' any inferences
	'''
	rvents = []
	for a in active:
		rvents.extend(_definitional_replaced(a, [f]))
	return rvents


#######################
## Specific inferences


def _clause_factors(e : FClause) -> FCNF:
	factors = []
	for ei in range(len(e)):
		for ej in range(ei+1, len(e)):
			ilit = e[ei]
			jlit = e[ej]
			if ilit.pol != jlit.pol:
				continue
			if is_flat_unif(ilit) or is_flat_unif(jlit):
				continue
			
			js = [jlit]
			if is_flat_eq(jlit.term): # Symmetry of equality
				lhs,rhs = flat_eq_parts(jlit.term)
				js.append(FLiteral(jlit.pol, FlatTerm([], jlit.term.head, [rhs,lhs])))
			
			for j in js:
				dbx(f"clause_factors: comparing literals {ilit}, {j}")

				preunifiers = apply_unif(ilit.term, j.term, e.a)
				for ctx,preunif_list in preunifiers:
					factor = FClause(
						[e[k] for k in range(len(e)) if k != ej] + preunif_list,
						ctx
					)
					factor.heritage = [e.clindex]
					factor.inferences.append("fac")
					factors.append(factor)
					dbx(f"clause_factors: got factor {factor.clindex}: {factor}")
	
	if factors:
		dbr(f"_clause_factors: generated factors:")
		for f in factors:
			dbr(f"\t{f.clindex}: {f}")
	return factors

def _clause_resolvents(e : FClause, f : FClause) -> FCNF:
	resolvents = []
	dbx(f"clause_resolvents: now looking at clauses:")
	dbx(f"                   {e.clindex:>4}: {e}")
	dbx(f"                   {f.clindex:>4}: {f}")
	for ei in range(len(e)):
		for fi in range(len(f)):
			elit = e[ei]
			flit = f[fi]
			if elit.pol == flit.pol:
				continue
			if is_flat_unif(elit) or is_flat_unif(flit):
				continue
			joined_ctx = e.a + f.a

			js = [flit]
			if is_flat_eq(flit.term): # Symmetry of equality
				lhs,rhs = flat_eq_parts(flit.term)
				js.append(FLiteral(flit.pol, FlatTerm([], flit.term.head, [rhs,lhs])))
			
			for j in js:
				dbx(f"clause_resolvents: comparing literals {elit}, {j}")
				preunifiers = apply_unif(elit.term, j.term, joined_ctx)
				for preunif_ctx, preunif_list in preunifiers:
					resolvent = FClause(
						[e[k] for k in range(len(e)) if k != ei] + preunif_list + [f[k] for k in range(len(f)) if k != fi],
						preunif_ctx
					)
					resolvent.heritage = [e.clindex, f.clindex]
					resolvent.inferences.append("res")
					resolvents.append(resolvent)
					dbx(f"clause_resolvents: got resolvent {resolvent.clindex}: {resolvent}")
					dbx(f"clause_resolvents: preunif_list was {[str(p) for p in preunif_list]}")
	
	if resolvents:
		dbr(f"_clause_resolvents: generated clauses ({e.clindex}, {f.clindex}):")
		for r in resolvents:
			dbr(f"\t{r.clindex}: {r}")
	return resolvents


###################################
## Unification via Elliott. Returns None or an FCNF consisting of every possible "preunified" clause.

def apply_unif(lhs : FlatTerm, rhs : FlatTerm, clause_ctx : Ctx, match : bool = False) -> Generator[tuple[Ctx, list[FLiteral]], None, None]:
	dbx(f"apply_unif: attempting to unify {lhs} with {rhs}")
	for ctx, unifier in unify_flat_pair(clause_ctx, SIG, (lhs,rhs), DEBUG_UNIF, match):
		dbx(f"apply_unif: got unifier {Unifier(unifier)}")
		## NOTE: this datastructure is only appropriate for actual substitutions, whereas
		## we actually want an associative list, because pairs may appear in multiple (flex-flex) equalities
		unif = []
		for unif_l, unif_r in unifier.items(): # Normalise to ensure everything is flat term for flat term
			if isinstance(unif_l, str):
				unif_l = FlatTerm([], unif_l, [])
			if isinstance(unif_r, str):
				unif_r = FlatTerm([], unif_r, [])
			unif.append(FLiteral(False, flat_eq(ctx, unif_l, unif_r)))
		dbx(f"apply_unif: unif was {[str(u) for u in unif]}")
		yield ctx, unif

def flat_eq(ctx : Ctx, lhs : FlatTerm, rhs : FlatTerm) -> FlatTerm:
	lhs_type,_ = flat_type_check_native(lhs, SIG, ctx, [], 0) # Obs ignored because of AWT invariant (we hope)
	eq_symbol = SIG.equality_symbol_for_type(lhs_type)
	return FlatTerm([], eq_symbol, [lhs, rhs])


def is_flat_unif(f : FLiteral) -> bool:
	return is_flat_eq(f.term) and len(f.term.quantifiers) == 0 and not f.pol


###################################
## Subsumption

BSUB_TIMEOUT = 50_000_000 # Does not formally affect completeness
def _forward_subsume_fclause(fcnf : FCNF, f : FClause):
	timer = perf_counter_ns() + BSUB_TIMEOUT
	for g in fcnf:
		if g.clindex == f.clindex:
			continue
		if r_subsumes(g, f, timer):
			dbr(f"_forward_subsume_fclause: {f.clindex} was subsumed by {g.clindex}: {g}")
			dead_copy = FClause([l for l in f], f.a)
			dead_copy.heritage = f.heritage
			dead_copy.inferences.append("subsume")
			dead_copy.inferences.append(f"by={g.clindex}")
			DEAD.append(dead_copy)
			return True
	return False

def _backward_subsume_fcnf(f : FClause, fcnf : FCNF):
	to_pop = set()
	i = 0
	timer = perf_counter_ns() + BSUB_TIMEOUT

	while i < len(fcnf):
		if i in to_pop:
			i += 1 
			continue
		if r_subsumes(f, fcnf[i], timer):
			to_pop.add(i)
		if perf_counter_ns() > timer:
			break
		i += 1 
	
	if to_pop:
		cleaned_fcnf = [fcnf[i] for i in range(len(fcnf)) if i not in to_pop]
		dead = [fcnf[i] for i in to_pop]
		DEAD.extend(dead)
		dbr(f"_backward_subsume_fcnf: removed clauses {str([d.clindex for d in dead]).strip("[]")}")
		fcnf.clear()
		fcnf.extend(cleaned_fcnf)

def simple_subsumes(f : FClause, g : FClause):
	return all(any(flat_aeq(l0,l1) for l1 in g) for l0 in f)

def r_subsumes(f : FClause, g : FClause, timeout : int):
	if len(f) > len(g):
		return False
	if not _presubsumes(f, g):
		return False
	if len(f.prebin_l) == 0:
		return simple_subsumes(f, g)
	
	## Temporarily disabled, simple subsumption only: the below code takes about 80% of the total execution time
	## Obviously, there are better ways to do this
	if f.constants_in - g.constants_in:
		return False
	
	# This is possibly avoidable using unifiers instead (more intelligently)
	tcs = type_combinations(f.prebin_l, g.prebin_r, timeout)
	joint_ctx = []
	for p in tcs:
		if joint_ctx == []:
			joint_ctx = f.a + g.a
		applied = FClause([FLiteral(f[i].pol, flat_substituted(p, f[i].term)) for i in range(len(f))], joint_ctx, True, True, True)
		# print(f"\tApplied  = {applied}")
		# print(f"\tComparing: {g}")
		if simple_subsumes(applied, g):
			# print(f"\t Subsumption success")
			# print(f"\t\t Unif    = {p}")
			# print(f"\t\t applied = {applied}")
			return True
		if perf_counter_ns() > timeout:
			return False
		
		
	return False

# Since subsumption is simple and based on variable renaming, we can compare the shape
# of terms to make it much more efficient
def _presubsumes(f : FClause, g : FClause):
	return all(any(gl.pol == l.pol and _term_shape(gl.term, set()) == _term_shape(l.term, set()) for gl in g) for l in f)

def _term_shape(f : FlatTerm, qf_set : set):
	for q in f.quantifiers:
		qf_set.add(q[0])
	head = 'v'
	if f.head in SIG.constants or f.head.startswith("EQ"):
		head = f.head
	elif f.head in qf_set:
		head = 'b'
	if len(f.quantifiers) == 0 and len(f.arguments) == 0:
		return head
	return (len(f.quantifiers), head, [_term_shape(a, qf_set) for a in f.arguments])

def _is_rigid(term : FlatTerm):
	return term.head in SIG.constants or term.head.startswith("EQ") or any(c0 == term.head for c0,_ in term.quantifiers)

#######################
## Extensionality rules

# Converts all equalities in the clause to extensional 
def _leibnizify(clause : FClause) -> FCNF:
	leib_lits = []
	leib_vars = []
	leibed = False
	for l in clause:
		if is_flat_eq(l.term):
			leibed = True
			lhs,rhs = flat_eq_parts(l.term)
			try:
				eq_type,_ = flat_type_check_native(lhs, SIG, clause.a, [], 0, False)
			except InvalidType as e:
				print(f"Error getting eq type in clause {clause.clindex}: literal was {l}, context was {clause.a}")
				raise e
			
			if eq_type.quantifiers:
				# Function case. Create a new skolem constant for each quantifier in the term, apply and beta-reduce
				application = {}
				app_order = []
				ctx = []
				if l.pol:
					for q,t in eq_type.quantifiers:
						v = SIG.next_var()
						application[q] = v
						app_order.append(v)
						ctx.append((v, flat_substituted(application, t)))
				else:
					for q,t in eq_type.quantifiers:
						c = SIG.next_const()
						SIG.constants[c] = flat_substituted(application, t)
						application[q] = c
						app_order.append(c)
				
				dbx(f"Leibniz: applying function {l} to args {app_order}")

				lhs_lhnf = lhnf(long_app(unflatten(lhs), *app_order), [], clause.a + ctx)
				rhs_lhnf = lhnf(long_app(unflatten(rhs), *app_order), [], clause.a + ctx)

				leib_lits.append(FLiteral(l.pol, flat_eq(clause.a + ctx, lhs_lhnf, rhs_lhnf)))
				dbx(f"Leibniz: obtained literal {leib_lits[-1]}")
				dbx(f"Leibniz: ...from literal {l}")
				leib_vars.extend(ctx)
			elif eq_type.head != 'bool':
				# General Leibniz. Really, we should also generate Leibniz definitions for booleans
				# but they have their own rule based on equivalence/biimplication
				if l.pol:
					leib_head = SIG.next_leib()
					leib_vars.append((leib_head, FlatTerm([(SIG.next_bound(), eq_type)], 'bool', [])))
					leib_lits.append(FLiteral(True, FlatTerm([], 'impl', [FlatTerm([], leib_head, [lhs]), FlatTerm([], leib_head, [rhs])])))
				else:
					# In the FALSE case, we need to skolemise P immediately, so do this manually
					leib_head = SIG.next_constf()
					dbx(f"Leibniz: added {leib_head} to sig (id={id(SIG)})")
					SIG.constants[leib_head] = Pi('', eq_type, 'bool')
					leib_lits.append(FLiteral(False, FlatTerm([], 'impl', [FlatTerm([], leib_head, [lhs]), FlatTerm([], leib_head, [rhs])])))
			else:
				leib_lits.append(FLiteral(l.pol, FlatTerm([], 'and', [FlatTerm([], 'impl', [lhs, rhs]), FlatTerm([], 'impl', [rhs, lhs])])))

		else:
			leib_lits.append(l)
	
	if not leibed:
		return []
	dbx(f"Leibnizifying clause {clause.clindex}, was = {clause}")
	dbx(f"Clause had context = {clause.a}")
	dbx(f"Clause generated leibniz context = {Ctx(leib_vars)}")
	dbx(f"After leibniz = {[str(l) for l in leib_lits]}")

	# This unflattens all terms and does Boolean reasoning using the normal inductive representation of terms,
	# which is a little slow but probably not significant
	ctx = clause.a + leib_vars
	re_fcnf = _reconvert_cnf(leib_lits, ctx) # Context may change (i.e. skolemisation) and gets baked into clause.a
	for c in re_fcnf:
		c.heritage = [clause.clindex]
		c.inferences.append("leib")

	if re_fcnf:
		dbr(f"_leibnizify: generated clauses:")
		for r in re_fcnf:
			dbr(f"\t{r.clindex}: {r}")
	return re_fcnf

def _reconvert_cnf(clause_list : list[FLiteral], flat_context : Ctx) -> FCNF:
	unflattened = []
	unflattened_ctx = []
	for l in clause_list:
		#dbx(f"reconvert_cnf: literal = {l}")
		if not l.pol:
			t = FlatTerm([], 'not', [l.term])
		else:
			t = l.term
		unflattened.append(unflatten(t))
	for s,t in flat_context:
		unflattened_ctx.append((s, unflatten(t, True)))
	
	cnf = disj(*unflattened)
	univ = unflattened_ctx.copy()
	while univ:
		s,t = univ.pop()
		cnf = All(s, t, cnf)
	
	rectx = Ctx()
	#dbx(f"reconvert_cnf: original literals = {[str(c) for c in clause_list]}")
	#dbx(f"reconvert_cnf: reconverting {cnf}...")
	cnf = cnf_convert(rectx, SIG, cnf)
	#dbx(f"reconvert_cnf: got clauses {cnf}")
	#dbx(f"reconvert_cnf: rectx was {rectx}")
	return to_fcnf(cnf, rectx)


def _simplify_unification_constraints(d : FClause) -> FCNF:
	# re-simplify constraints as much as reasonable using Elliott algorithm (non-instantiating)
	simplifications = []
	dbx(f"Simplfying constraints in {d}...")
	for i in range(len(d)):
		l = d[i]
		if is_flat_unif(l):
			lhs,rhs = flat_eq_parts(l.term)
			unifs = apply_unif(lhs, rhs, d.a)
			for new_ctx, unif_list in unifs:
				simplifications.append(FClause([d[j] for j in range(len(d)) if j != i] + unif_list, new_ctx))
				simplifications[-1].heritage = [d.clindex]
				simplifications[-1].heritage.append("unif")
	if simplifications:
		dbx(f"Got {len(simplifications)} simplifications for clause {d.clindex}")
		dbx(f"Init = {d}")
		dbx(f"Simp = {simplifications[0]}")
	return simplifications

##########
## Helpers

def _simplify_free(d : FClause):
	# Remove redundant variables in the context to permit much faster renaming.
	# Returns the set of free variables in the clause (for convenience)
	# 
	# This operation is surprisingly slow. There are no obvious optimisations except
	# calling it less often

	dbx(f"Simplifing clause for: {d.clindex} = {d}")

	# Convert context to dict. Probably not super important, but slightly more efficient 
	ctx_dict = {c0:c1 for c0,c1 in d.a}
	keep_vars = set()
	for l in d:
		keep_vars |= free_variables_native(l.term, include_types=False)
	
	# A list of variables appearing in terms (i.e. not in types)
	ret_vars = keep_vars.copy()
	# Dict representing the (new) context
	keep_dict = {}

	dbx(f"keep_vars = {keep_vars}")
	dbx(f"ctx_dict = {Unifier(ctx_dict)}")

	# For each variable, add its type entry to keep_dict if it is kept. Add all
	# free variables appearing in that type to keep_vars, and repeat
	while keep_vars:
		v = keep_vars.pop()
		if v in keep_dict:
			continue
		if v not in ctx_dict:
			print(f"CRITICAL: variable {v} in the clause ({d.clindex}) did not appear in context")
			print(f"\t{d.clindex}: {d}")
			print(f"\tctx_dict = {Unifier(ctx_dict)}")
			print(f"\tclause.a = {Ctx(d.a)}")
			raise ValueError
		keep_dict[v] = ctx_dict[v]
		fvs = free_variables_native(ctx_dict[v])
		keep_vars |= fvs
		ret_vars |= fvs
	
	# So, we have effectively removed all unnecessary variables
	d.a = [(c0,c1) for c0,c1 in keep_dict.items()]
	return ret_vars
	
def _is_trivially_false(l : FLiteral):
	if (l.pol and l.term.head == 'false') or (not l.pol and l.term.head == 'true'):
		return True
	if is_flat_unif(l):
		lhs,rhs = flat_eq_parts(l.term)
		if flat_aeq(lhs,rhs):
			return True

def _is_trivially_true(l : FLiteral):
	return (l.pol and l.term.head == 'true') or (not l.pol and l.term.head == 'false')



def _definitional_replaced(d : FClause, active : FCNF):
	# Replacement by definitions
	subs = {}
	clontext = Ctx()
	heritage = []
	for back_clause in active:
		if back_clause.clindex == d.clindex:
			continue
		if len(back_clause) != 1:
			continue
		if not is_flat_eq(back_clause[0].term) or not back_clause[0].pol:
			continue
		lhs,rhs = flat_eq_parts(back_clause[0].term) # assumes orientation
		if lhs.quantifiers or lhs.arguments:
			continue # TODO: allow generalised LHS replacements, via unifiers (paramodulation) - requires ordering as well, for simplification
		if not any(contains_symbol(l.term, lhs.head) for l in d):
			continue # TODO: this filter prevents transitive substitutions, i.e. (x[x == y, y == z] => y), which is incomplete.
		if flat_aeq(lhs,rhs):
			continue
		
		subs[lhs.head] = rhs
		clontext.extend(back_clause.a)
		heritage.append(back_clause.clindex)
	
	if not subs:
		return []

	if not any(contains_symbol(l.term, s) for l in d for s in subs):
		return []

	dbx(f"_definitional_replaced: substituting {d} with subs {Unifier(subs)}")
	nclause = FClause([FLiteral(l.pol, flat_substituted(subs, l.term)) for l in d], d.a + clontext)
	nclauses = _reconvert_cnf(nclause, nclause.a)
	dbx(f"_definitional_replaced: result was {nclauses}")

	if nclauses:
		dbr(f"_definitional_replaced: applied replacement {Unifier(subs)}")
		dbr(f"_definitional_replaced: rewrote {d.clindex}:")
		for n in nclauses:
			n.heritage = [d.clindex] + heritage
			n.inferences.append(f"def_repl={Unifier(subs)}")
			dbr(f"\t{n.clindex}: {n}")

	return nclauses

def _unification_replace(d : FClause):
	replaced = False
	j = 0
	dbx(f"Unification replacing for {d}")
	while j < len(d):
		l = d[j]
		j += 1
		if not is_flat_unif(l):
			dbx(f"Literal {l} is not flat unif")
			continue
		
		lhs,rhs = flat_eq_parts(l.term)
		# Very naive term ordering 
		if rhs.head in SIG.constants:
			pass
		elif (len(lhs.quantifiers) != 0 or len(lhs.arguments) != 0 or rhs.head < lhs.head) and len(rhs.quantifiers) == 0 and len(rhs.arguments) == 0:
			l.term.arguments[0],l.term.arguments[1] = l.term.arguments[1], l.term.arguments[0]
			lhs,rhs = l.term.arguments[0],l.term.arguments[1]


		if len(lhs.quantifiers) == 0 and len(lhs.arguments) == 0:
			if lhs.head not in SIG.constants and not lhs.head.startswith("EQ"):
				dbx(f"_forward_simplify: clause {d} will use the substitution {l}")
				if lhs.head in free_variables_native(rhs, set()):
					dbx(f"_forward_simplify: occurs, skipping")
					continue
				for literal in d:
					literal.term = flat_substituted({lhs.head:rhs}, literal.term)
				l.pol = False
				l.term = FlatTerm([], 'true', [])
				replaced = True
			else:
				dbx(f"_forward_simplify: skipped because head {lhs.head} is constant")
		else:
			dbx(f"_forward_simplify: skipped because head {lhs.head} is not atomic")
	if replaced:
		dbx(f"_unification_replaced: rewrote {d.clindex}: {d}")


def _clear_triv_false(d : FClause):
	to_pop = set()
	for i in range(len(d)):
		if _is_trivially_false(d[i]):
			to_pop.add(i)
	for p in sorted(to_pop, reverse=True):
		d.pop(p)


def print_odter_success(odter_output : tuple, must_include : int = -1):
	empty_clause : FClause = odter_output[0]
	active,passive,_,dead = odter_output[1]
	to_find = empty_clause.heritage.copy()
	to_keep = [empty_clause]
	saved = {empty_clause.clindex}
	while to_find:
		idx = to_find.pop()
		if idx in saved:
			continue
		for clause in active + passive + dead:
			if clause.clindex == idx:
				to_keep.append(clause)
				saved.add(clause.clindex)
				to_find.extend(clause.heritage)
	to_keep.sort(key=lambda x : x.clindex)

	for clause in to_keep:
		print(f"\t{str(clause.heritage):>12} ⊢ {clause.clindex:>5}: {clause} ({str(clause.inferences).strip("[]").replace("'", "")})")

	if must_include >= 0 and must_include not in saved:
		print(f"CRITICAL: SOUNDNESS! Refutation did not include must_include={must_include}")
		raise ValueError