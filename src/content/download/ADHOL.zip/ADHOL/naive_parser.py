
from common import Ctx
from datatypes import *
from hol import infer_types, hol_constants, get_from_context

DEBUG_PARSER = 1
dbp = lambda s : (not DEBUG_PARSER) or print(s)

TOKENS = [
	('(' 	, 'LPAREN', 	'PAREN',	'PAREN'),
	(')' 	, 'RPAREN', 	'PAREN',	'PAREN'),
	('[' 	, 'LSQPAREN', 	'SQPAREN',	'PAREN'),
	(']' 	, 'RSQPAREN',	'SQPAREN',	'PAREN'),
	('=>' 	, 'IMPL',		'INFIX',	'LASSOC'),

	('!>' 	, 'PI',			'PREFIX', 	'QUANTIFIER'),
	('!' 	, 'FORALL',		'PREFIX', 	'QUANTIFIER'),
	('?' 	, 'EXISTS',		'PREFIX', 	'QUANTIFIER'),

	(',' 	, 'COMMA',		'INFIX',	'LIST'),
	(':' 	, 'OFTYPE',		'INFIX',	'BINARY'),
	('@' 	, 'APP',		'INFIX',	'RASSOC'),
	('>' 	, 'ARROW',		'INFIX',	'LASSOC'),
	('&'	, 'AND',		'INFIX', 	'LASSOC'),
	('|'	, 'OR',			'INFIX',	'LASSOC'),
	('=' 	, 'EQ',			'INFIX',	'BINARY'),
	('~'	, 'NOT',		'PREFIX',	'UNARY'),
	('$' 	, 'TYPE',		'PREFIX',	'UNARY'),
]

def get_token(tok : str):
	for p in TOKENS:
		if p[0] == tok:
			return p[1]

class ParseError(Exception): pass

def parse_file(filename : str) -> list[Term]:
	f = open(filename, 'r', encoding='ascii')
	uncommented = ""
	for l in f.readlines():
		if not l.startswith("%"):
			uncommented += l
	
	
	split_lines = _remove_whitespace(uncommented).split('.')
	tokenised = map(_tokenise, split_lines)
	preamble_parsed = map(parse_tptp_preamble, tokenised)
	preamble_parsed = list(filter(lambda s : bool(s), preamble_parsed))
	all_terms = []

	for pp_name, pp_type, pp_formula in preamble_parsed:
		if pp_type == 'type':
			p = (pp_formula[0], to_internal_term(parse_declaration(pp_formula[2:])))
		else:
			p = to_internal_term(parse_declaration(pp_formula))
		#dbp(f"{filename}: Parsed {pp_name} as {p}")
		all_terms.append(p)
	return all_terms


def _remove_whitespace(string : str):
	split_lines = "".join(string.split('\n'))
	split_lines = "".join(split_lines.split(' '))
	split_lines = "".join(split_lines.split('\t'))
	return split_lines

def _tokenise(line : str):
	# Bracketise the line 
	tokens = []
	token = ""
	token_is_symbol = False
	i = 0
	while i < len(line):
		if line[i] == '(':
			tokens.append(token)
			token = ""
			j = i + 1
			k = 0
			while j < len(line):
				if line[j] == '(':
					k += 1 
				if line[j] == ')':
					if k == 0:
						tokens.append(_tokenise(line[i+1 : j]))
						i = j + 1
						break
					else:
						k -= 1
				j += 1
			else:
				raise ParseError(line)
			
		elif line[i] == '[':
			tokens.append(token)
			token = ""
			j = i + 1
			k = 0
			while j < len(line):
				if line[j] == '[':
					k += 1 
				if line[j] == ']':
					if k == 0:
						tokens.append(_tokenise(line[i+1 : j]))
						i = j + 1
						break
					else:
						k -= 1
				j += 1
			else:
				raise ParseError(line)

		else:
			is_symbol = ( get_token(line[i]) == None )
			if is_symbol == token_is_symbol:
				if not token_is_symbol:
					if get_token(token + line[i]) == None:
						tokens.append(token)
						token = ""
				token += line[i]
			else:
				tokens.append(token)
				token = line[i]
			token_is_symbol = is_symbol
			i += 1

	tokens.append(token)
	ret = list(filter(lambda t : len(t) > 0, tokens))
	return ret
		
def parse_tptp_preamble(line_list : list):
	if len(line_list) == 0:
		return None
	if line_list[0] != 'thf':
		raise ParseError
	if len(line_list) < 2:
		raise ParseError
	formula_name = line_list[1][0]
	formula_type = line_list[1][2]
	actual_formula = line_list[1][4:]
	return (formula_name, formula_type, actual_formula)


def index_of_top_level(l : list):
	top = len(TOKENS)
	fst = -1
	idx = -1

	for tindex in range(0, len(l)):
		for ti in range(len(TOKENS)):
			t = TOKENS[ti]
			if t[0] == l[tindex]:
				if ti < top:
					fst = tindex
				if ti <= top:
					top = ti
					idx = tindex
		
	if top < len(TOKENS):
		if TOKENS[top][3] != 'LASSOC':
			return top, idx
		else:
			return top, fst
	return -1, -1


def parse_declaration(decl):
	tok_index, top_index = index_of_top_level(decl)
	if top_index != -1:
		if TOKENS[tok_index][2] == 'INFIX':
			return (TOKENS[tok_index][1], parse_declaration(decl[:top_index]), parse_declaration(decl[top_index+1:]))
		elif TOKENS[tok_index][2] == 'PREFIX':
			return (TOKENS[tok_index][1], parse_declaration(decl[top_index+1:]))
		else:
			raise ParseError(decl)
	elif isinstance(decl[0], list) and len(decl) == 1:
		return parse_declaration(decl[0])
	return decl


def to_internal_term(parsed_ast : tuple):
	match parsed_ast[0]:
		case 'PI':
			return parsed_quantifier(parsed_ast, Pi)
		case 'FORALL':
			return parsed_quantifier(parsed_ast, All)
		case 'EXISTS':
			return parsed_quantifier(parsed_ast, Ext)
		case 'ARROW':
			return Pi("", to_internal_term(parsed_ast[1]), to_internal_term(parsed_ast[2]))
		case 'APP':
			return App(to_internal_term(parsed_ast[1]), to_internal_term(parsed_ast[2]))
		case 'IMPL':
			return App(App('impl', to_internal_term(parsed_ast[1])), to_internal_term(parsed_ast[2]))
		case 'AND':
			return App(App('and', to_internal_term(parsed_ast[1])), to_internal_term(parsed_ast[2]))
		case 'OR':
			return App(App('or', to_internal_term(parsed_ast[1])), to_internal_term(parsed_ast[2]))
		case 'EQ':
			return App(App('eq', to_internal_term(parsed_ast[1])), to_internal_term(parsed_ast[2]))
		case 'OFTYPE':
			return (to_internal_term(parsed_ast[1]), to_internal_term(parsed_ast[2]))
		case 'TYPE':
			return TP
	return parsed_ast[0]
		

def parsed_quantifier(ast : tuple, qf_type):
	assert any([p[1] == ast[0] and p[3] == 'QUANTIFIER' for p in TOKENS])
	assert ast[1][0] == 'OFTYPE'
	parsed_rec = parse_decltype_recursively(to_internal_term(ast[1][2]), ast[1][1], qf_type)
	return parsed_rec


def parse_decltype_recursively(body : tuple, qf_args : tuple, qf_type):
	if qf_args[0] == 'COMMA':
		return parse_decltype_recursively(qf_type(to_internal_term(qf_args[2][1]), to_internal_term(qf_args[2][2]), body), qf_args[1], qf_type)
	elif qf_args[0] == 'OFTYPE':
		return qf_type(to_internal_term(qf_args[1]), to_internal_term(qf_args[2]), body)
	
	raise ParseError(qf_args)

def type_equalities(in_formula : Term, global_ctx : Ctx, binding_ctx : Ctx = Ctx()) -> Term:
	if isinstance(in_formula, Quantifier):
		return in_formula.__class__(in_formula.var, in_formula.var_type,
			type_equalities(in_formula.body, global_ctx, binding_ctx + [(in_formula.var, in_formula.var_type)]))
	
	if isinstance(in_formula, App):
		if is_unary_app(in_formula, 'eq'):
			lhs_type = infer_types(in_formula.operand, global_ctx, binding_ctx)
			if lhs_type == None:
				raise ParseError(f"No type found for {in_formula.operand} in formula={in_formula}, \nglobal_ctx={Ctx(global_ctx)}, \nbinding_ctx={Ctx(binding_ctx)}")
			return App(App('EQ', lhs_type), in_formula.operand)
		return App(type_equalities(in_formula.operator, global_ctx, binding_ctx), type_equalities(in_formula.operand, global_ctx, binding_ctx))
	
	else:
		return in_formula