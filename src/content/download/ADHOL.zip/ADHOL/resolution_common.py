from itertools import combinations_with_replacement
from time import perf_counter_ns
from datatypes import *
from hol import *
from elliott import *

next_clid = -1
def get_next_clid():
	global next_clid
	next_clid += 1
	return next_clid

def reset_clid():
	global next_clid ; next_clid = -1

class TaggedUnifier(Unifier):
	associated_clid = 0
	parent_ids = []
	clause : Clause
	def __init__(self, unif, clid, parents, clause = None):
		self.update(unif)
		self.associated_clid = clid
		self.parent_ids = parents
		self.clause = clause

class AClause(Clause):
	a : Ctx
	heritage : list[TaggedUnifier] = []
	clid : int

	constants_in : set
	prebin_l : Ctx
	prebin_r : dict = {}

	def __init__(self, l : list, a : Ctx, h : list[TaggedUnifier], sig : Sig, skip_subsumption_cache : bool = False):
		self.extend(l)
		self.a = Ctx(a)
		self.heritage = h
		self.clid = get_next_clid()
		if sig == None:
			raise ValueError
		if not skip_subsumption_cache:
			self.subsumption_recache(sig)

	def subsumption_recache(self, sig : Sig):
		fvs = free_variables(self, [], False)
		self.constants_in = {c for c in fvs if c in sig.constants} # Speed up subsumption??

		self.prebin_l = [(fv, canonical_string(type_approximate(get_from_context(sig, self.a, fv)))) for fv in fvs if fv not in sig.constants]
		r = {typ:[] for typ in [t for _,t in self.prebin_l]}
		for v,t in self.prebin_l:
			r[t].append(v)
		self.prebin_r = r
		#input(f"Did subsumption recache for clause {self.clid}. clause = {self}, fvs = {fvs}, constants_in = {self.constants_in}, prebin_l = {self.prebin_l}, prebin_r = {self.prebin_r}")


	def subsumes(self, other : AClause):
		return all(any(aeq(l0,l1) for l1 in other) for l0 in self)

	def r_subsumes(self, other : AClause, timeout : int, sig : Sig):
		return rename_subsumes(self, other, sig, timeout)


def normalise(cnf : CNF, db : function, sig : Sig) -> set[int]:
	changed = set()
	tautology_clauses = set()
	for i in range(len(cnf)):
		clause : AClause = cnf[i]
		for j in range(len(clause)):
			literal = clause[j]
			if is_unary_app(literal.term, "not"):
				literal.term = literal.term.operand
				literal.pol = not literal.pol
				changed.add(clause.clid)
		duplicated = []
		taut = False
		for j in range(len(clause)):
			for k in range(j + 1, len(clause)):
				if aeq(clause[j].term, clause[k].term):
					db(f"\t{clause[j].term}, {clause[k].term} are AEQ")
					if clause[j].pol == clause[k].pol:
						duplicated.append(k)
					else:
						taut = True
						break
			if taut:
				break
		
		if taut:
			tautology_clauses.add(i)
			db(f"Normalised {i}/{len(cnf)}, was a tautology")
		elif len(duplicated) > 0:
			db(f"Normalised {i}/{len(cnf)}, removed {len(duplicated)} aeq literals")
			for idx in sorted(list(set(duplicated)), reverse=True):
				clause.pop(idx)
		else:
			pass
			db(f"Normalised {i}/{len(cnf)}")
		
	db(f"Marked {len(changed)} clauses as changed")
	db(f"Identified and removed {len(tautology_clauses)} tautologies")
	for c in sorted(list(tautology_clauses), reverse=True):
		cnf.pop(c)
	
	for i in range(len(cnf)):
		rename_free(cnf[i], sig, db)
		cnf[i].subsumption_recache(sig)
		pass
	return changed

# TODO: use a single context for all objects?? rather than duplicating for each clause
# TODO: update context to use a dict for very fast access
def rename_free(clause : AClause, sig : Sig, db : function):
	fvs = {c[0] for c in clause.a if sig.constants.get(c[0], None) == None}
	ctx_vars = free_variables({c[1] for c in clause.a}, list(sig.constants.items()), True)
	formula_vars = free_variables(clause, list(sig.constants.items()), True)


	# caught = False
	# catch_symbol = "iH465"
	# if catch_symbol in fvs | ctx_vars | formula_vars:
	# 	caught = True
	# 	print(f"Ya caught the catch symbol. Clause={clause}, clause.a={clause.a}, formula_vars = {formula_vars}, ctx_vars={ctx_vars}")
	# 	input()

	to_pop = []
	popped = set()
	for i in range(len(clause.a)):
		if clause.a[i][0] not in formula_vars and clause.a[i][0] not in ctx_vars:
			to_pop.append(i)
	for p in reversed(to_pop):
		popped.add(clause.a.pop(p))
			
	#db(f"Replacement for clause {clause.clid} got fvs {fvs}, sig constants was {SIG.constants}")
	new_vars = set()
	unif = Unifier()
	for fv in sorted(fvs):
		unif[fv] = sig.next_var()
		new_vars.add(unif[fv])
	for fv in sorted(ctx_vars):
		unif[fv] = sig.next_var()
		new_vars.add(unif[fv])
		ctype = get_from_context(sig, clause.a, fv)
		if ctype == None:
			raise ValueError(f"{fv} free in context but does not itself have a context entry, in {clause.a}")
		clause.a.append((unif[fv], ctype))
	#print(f"Renaming free in {clause.clid}, unif was {unif}")
	#print(f"\tctx_vars was {ctx_vars}")
	for i in range(len(clause)):
		clause[i] = Literal(fast_applied_unifier(clause[i].term, unif, True), clause[i].pol)
	
	for i in range(len(clause.a)):
		clause.a[i] = fast_applied_unifier(clause.a[i], unif)
	clause.heritage.append(TaggedUnifier({k:v for k,v in unif.items() if k in fvs}, clause.clid, ["RENAME"]))

	clause.subsumption_recache(sig)

	# catch_symbol = "iH465"
	# if caught or catch_symbol in fvs | ctx_vars | formula_vars | new_vars or catch_symbol in unif:
	# 	print(f"Wow! You caught the rename. Original FVS={fvs} ctx_vars={ctx_vars}, formula_vars={formula_vars}. Substituted clause = {clause}, clause.a = {clause.a}, clause.heritage={clause.heritage}, unif = {unif}, new_vars={new_vars}", 0)
	# 	print(f"Popped was {popped}", 0)
	# 	input()

RSUB_TIMEOUT = 100_000_000
def subsume(cnf : CNF, db : function, sig : Sig, only_check : set = None, force_simple : bool = False, silent = False):
	if only_check != None and len(only_check) == 0:
		return
	
	to_pop = set()
	i = 0
	skipped = 0
	try:
		while i < len(cnf):
			start_ns = perf_counter_ns()
			time = start_ns + RSUB_TIMEOUT
			subsumed_by_i = 0
			if i in to_pop:
				skipped += 1
				i += 1
				continue
			
			j = 0
			while j < len(cnf):
				if j in to_pop or i == j or (only_check != None and (cnf[i].clid not in only_check) and (cnf[j].clid not in only_check)):
					j += 1
					continue
				if perf_counter_ns() > time:
					break

				if (force_simple and cnf[i].subsumes(cnf[j])) or (not force_simple and cnf[i].r_subsumes(cnf[j], time, sig)):
					to_pop.add(j)
					subsumed_by_i += 1
				j += 1
			end_ns = perf_counter_ns()
			if not silent:
				print(f"{f"Subsumed {i - skipped:>6}/{len(cnf) - len(to_pop):<6} {f"({(-subsumed_by_i):>5})" if subsumed_by_i else " ":>10} {len(cnf[i]):>2}c {len(cnf[i].prebin_l):>2}v":55}{fmt_ns(end_ns - start_ns) + ("X" if end_ns > time else "")}")
			i += 1
	except KeyboardInterrupt as e:
		# Apply any partial progress if interrupted
		for i in sorted(to_pop, reverse=True):
			cnf.pop(i)
		raise e

	db(f"Subsumption deleted {len(to_pop)} unnecessary clauses (-{int(100 * len(to_pop) / len(cnf))}%)")
	tmp = [cnf[i] for i in range(len(cnf)) if i not in to_pop]
	cnf.clear()
	cnf.extend(tmp)

def rename_subsumes(clause1 : AClause, clause2 : AClause, sig : Sig, timeout : int):
	if len(clause1) > len(clause2):
		return False
	if len(clause1.prebin_l) == 0:
		return clause1.subsumes(clause2)
	if clause1.constants_in - clause2.constants_in: # If there is a value here, renaming will never work
		return False
	
	for p in type_combinations(clause1.prebin_l, clause2.prebin_r, timeout):
		#print(f"\tGot typed substitution {p}")
		applied = AClause([Literal(fast_applied_unifier(clause1[j].term, p, True), clause1[j].pol) for j in range(len(clause1))], clause1.a, [], sig, True)
		#print(f"{applied} attempting to subsume {clause2}...")
		if applied.subsumes(clause2):
			#input(f"\t...which worked")
			return True
		if perf_counter_ns() > timeout:
			#input(f"\t...which timed out")
			return False
		#print(f"\t...which did not match, continuing")
	
	#input(f"\t...no type combinations found")
	return False

