%------------------------------------------------------------------------------
% Comments : HOLified version from DT2H2X
%------------------------------------------------------------------------------
thf(is_per_type,type,
    isPer: 
      !>[A: $tType] : ( ( A > A > $o ) > $o ) ).

thf(is_per,definition,
    ! [A: $tType,AStar: A > A > $o] :
      ( ( isPer @ A @ AStar )
    <=> ( ! [X: A,Y: A] :
            ( ( AStar @ X @ Y )
           => ( AStar @ Y @ X ) )
        & ! [X: A,Y: A,Z: A] :
            ( ( AStar @ X @ Y )
           => ( ( AStar @ Y @ Z )
             => ( AStar @ X @ Z ) ) ) ) ) ).

thf(nat_type,type,
    nat: $tType ).

thf(natStar,type,
    natStar: nat > nat > $o ).

thf(natStar_is_eq,axiom,
    ! [X: nat,Y: nat] :
      ( ( natStar @ X @ Y )
    <=> ( X = Y ) ) ).

thf(zero_type,type,
    zero: nat ).

thf(suc_type,type,
    suc: nat > nat ).

thf(plus_type,type,
    plus: nat > nat > nat ).

thf(fin_type,type,
    fin: $tType ).

thf(finStar,type,
    finStar: nat > fin > fin > $o ).

thf(finStarIsPer,axiom,
    ! [C: nat] : ( isPer @ fin @ ( finStar @ C ) ) ).

thf(f1_type,type,
    f1: nat > fin ).

thf(f1_tp_ax,axiom,
    ! [A: nat] : ( finStar @ ( suc @ A ) @ ( f1 @ A ) @ ( f1 @ A ) ) ).

thf(fs_type,type,
    fs: nat > fin > fin ).

thf(fs_tp_ax,axiom,
    ! [A: nat,D: fin,D_prime: fin] :
      ( ( finStar @ A @ D @ D_prime )
     => ( finStar @ ( suc @ A ) @ ( fs @ A @ D ) @ ( fs @ A @ D_prime ) ) ) ).

thf(l_type,type,
    l: nat > nat > fin > fin ).

thf(l_tp_ax,axiom,
    ! [A: nat,B: nat,D: fin,D_prime: fin] :
      ( ( finStar @ A @ D @ D_prime )
     => ( finStar @ ( plus @ A @ B ) @ ( l @ A @ B @ D ) @ ( l @ A @ B @ D_prime ) ) ) ).

thf(r_type,type,
    r: nat > nat > fin > fin ).

thf(r_tp_ax,axiom,
    ! [A: nat,B: nat,D: fin,D_prime: fin] :
      ( ( finStar @ A @ D @ D_prime )
     => ( finStar @ ( plus @ A @ B ) @ ( r @ A @ B @ D ) @ ( r @ A @ B @ D_prime ) ) ) ).

thf(plus_suc,axiom,
    ! [X: nat,Y: nat] :
      ( ( plus @ ( suc @ X ) @ Y )
      = ( suc @ ( plus @ X @ Y ) ) ) ).

thf(plus_zero,axiom,
    ! [X: nat] :
      ( ( plus @ X @ zero )
      = X ) ).

thf(fin_case,axiom,
    ! [P: nat > fin > $o] :
      ( ! [N: nat,D: fin,D_prime: fin] :
          ( ( finStar @ ( suc @ N ) @ D @ D_prime )
         => ( ( P @ N @ D )
            = ( P @ N @ D_prime ) ) )
     => ( ( ! [N: nat] : ( P @ N @ ( f1 @ N ) )
          & ! [N: nat,F: fin] :
              ( ( finStar @ N @ F @ F )
             => ( P @ N @ ( fs @ N @ F ) ) ) )
       => ! [N: nat,F: fin] :
            ( ( finStar @ ( suc @ N ) @ F @ F )
           => ( P @ N @ F ) ) ) ) ).

thf(fin_rec,axiom,
    ! [P: nat > fin > $o] :
      ( ! [N: nat,D: fin,D_prime: fin] :
          ( ( finStar @ ( suc @ N ) @ D @ D_prime )
         => ( ( P @ N @ D )
            = ( P @ N @ D_prime ) ) )
     => ( ( ! [N: nat] : ( P @ N @ ( f1 @ N ) )
          & ! [N: nat,F: fin] :
              ( ( finStar @ ( suc @ N ) @ F @ F )
             => ( ( P @ N @ F )
               => ( P @ ( suc @ N ) @ ( fs @ ( suc @ N ) @ F ) ) ) ) )
       => ! [N: nat,F: fin] :
            ( ( finStar @ ( suc @ N ) @ F @ F )
           => ( P @ N @ F ) ) ) ) ).

thf(l_f1,axiom,
    ! [M: nat,N: nat] : ( finStar @ ( plus @ ( suc @ M ) @ N ) @ ( l @ ( suc @ M ) @ N @ ( f1 @ M ) ) @ ( f1 @ ( plus @ M @ N ) ) ) ).

thf(l_fs,axiom,
    ! [M: nat,N: nat,P: fin] :
      ( ( finStar @ M @ P @ P )
     => ( finStar @ ( plus @ M @ N ) @ ( l @ M @ N @ ( fs @ M @ P ) ) @ ( fs @ ( plus @ M @ N ) @ ( l @ M @ N @ P ) ) ) ) ).

thf(r_0,axiom,
    ! [M: nat,F: fin] :
      ( ( finStar @ M @ F @ F )
     => ( finStar @ ( plus @ M @ zero ) @ ( r @ M @ zero @ F ) @ F ) ) ).

thf(r_s,axiom,
    ! [M: nat,N: nat,F: fin] :
      ( ( finStar @ M @ F @ F )
     => ( finStar @ ( plus @ M @ ( suc @ N ) ) @ ( r @ M @ ( suc @ N ) @ F ) @ ( fs @ ( plus @ M @ N ) @ ( r @ M @ N @ F ) ) ) ) ).

thf(l_r_neq,conjecture,
    ! [M: nat,N: nat,P: fin,Q: fin] :
      ( ( finStar @ N @ P @ P )
     => ( ( finStar @ M @ Q @ Q )
       => ( finStar @ ( plus @ N @ M ) @ ( l @ N @ M @ P ) @ ( r @ M @ N @ Q ) ) ) ) ).

%------------------------------------------------------------------------------
