%------------------------------------------------------------------------------
% File     : DAT338^1 : TPTP v9.2.1. Released v9.2.0.
% Domain   : Data Structures
% Problem  : Nil is a right-neutral element of app, base case
% Version  : Especial.
% English  : Nil is a right-neutral element of app. The proof is by induction
%            with a separate problem file for the base and step case as well as
%            the correct instantiation of the induction axiom for lists. The 
%            main file uses the conjectures of the other files as lemmas in
%            order to prove the final result. To simplify proof search, the
%            lemmas in the problem file for the induction step have been
%            preselected.

% Refs     : [RRB23] Rothgang et al. (2023), Theorem Proving in Dependently
%          : [Rot25] Rothgang (2025), Email to Geoff Sutcliffe
%          : [RK+25] Ranalter et al. (2025), The Dependently Typed Higher-O
% Source   : [Rot25]
% Names    : ListAppNil/list-app-nil-base.p [Rot25]

% Status   : Theorem
% Rating   : ? v9.2.0
% Syntax   : Number of formulae    :   19 (   7 unt;   9 typ;   0 def)
%            Number of atoms       :    9 (   9 equ;   0 cnn)
%            Maximal formula atoms :    2 (   0 avg)
%            Number of connectives :   80 (   3   ~;   0   |;   0   &;  70   @)
%                                         (   0 <=>;   7  =>;   0  <=;   0 <~>)
%            Maximal formula depth :   12 (   5 avg)
%            Number of types       :    3 (   2 usr)
%            Number of type decls  :    9 (   0 !>P;   3 !>D)
%            Number of type conns  :   10 (  10   >;   0   *;   0   +;   0  <<)
%            Number of symbols     :    8 (   7 usr;   2 con; 0-4 aty)
%            Number of variables   :   27 (   0   ^;  23   !;   0   ?;  27   :)
%                                         (   4  !>;   0  ?*;   0  @-;   0  @+)
% SPC      : DH0_THM_EQU_NAR

% Comments :
%------------------------------------------------------------------------------

thf(nat_type,type,
    nat: $tType ).

thf(list_type,type,
    list: nat > $tType ).

thf(zero_type,type,
	zero: nat).

thf(nil_type,type,
	nil: list @ zero).

thf(ax_nil_uniq,axiom,
	! [V: list @ zero, U: list @ zero] : ( V = U ) ).

thf(silly,conjecture,
	! [N : nat, V : list @ N, U : list @ N] : ( ( N = zero ) => ( V = U ) ) ).

%------------------------------------------------------------------------------
