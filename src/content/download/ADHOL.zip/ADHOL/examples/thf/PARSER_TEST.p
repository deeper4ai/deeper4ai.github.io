thf(inf,axiom,
    ? [F: $o] : (~ ( F ) & ( F ))).