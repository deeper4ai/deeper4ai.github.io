%------------------------------------------------------------------------------
% File     : CSR152^1 : TPTP v9.2.1. Released v4.1.0.
% Domain   : Commonsense Reasoning
% Problem  : Does bart know that lisa likes milhouse?
% Version  : Especial > Reduced > Especial.
% English  : Everybody knows that bart is equal to bart. martin likes milhouse. 
%            bart knows that lisa likes whoever martin likes. Does bart know 
%            that lisa likes milhouse?

% Refs     : [PS07]  Pease & Sutcliffe (2007), First Order Reasoning on a L
%          : [BP10]  Benzmueller & Pease (2010), Progress in Automating Hig
%          : [Ben10] Benzmueller (2010), Email to Geoff Sutcliffe
% Source   : [Ben10]
% Names    : paar_8.tq_SUMO_local [Ben10]

% Status   : Theorem
% Rating   : 0.00 v8.2.0, 0.08 v8.1.0, 0.00 v7.4.0, 0.11 v7.2.0, 0.00 v7.1.0, 0.12 v7.0.0, 0.14 v6.4.0, 0.17 v6.3.0, 0.20 v6.2.0, 0.00 v6.1.0, 0.57 v6.0.0, 0.14 v5.5.0, 0.17 v5.4.0, 0.40 v5.3.0, 0.60 v4.1.0
% Syntax   : Number of formulae    :   11 (   1 unt;   7 typ;   0 def)
%            Number of atoms       :    8 (   1 equ;   0 cnn)
%            Maximal formula atoms :    3 (   2 avg)
%            Number of connectives :   15 (   0   ~;   0   |;   0   &;  14   @)
%                                         (   0 <=>;   1  =>;   0  <=;   0 <~>)
%            Maximal formula depth :    6 (   4 avg)
%            Number of types       :    3 (   1 usr)
%            Number of type conns  :    4 (   4   >;   0   *;   0   +;   0  <<)
%            Number of symbols     :    7 (   6 usr;   4 con; 0-2 aty)
%            Number of variables   :    1 (   0   ^;   1   !;   0   ?;   1   :)
% SPC      : TH0_THM_EQU_NAR

% Comments : This is a simple test problem for reasoning in/about SUMO.
%            Initally the problem has been hand generated in KIF syntax in
%            SigmaKEE and then automatically translated by Benzmueller's
%            KIF2TH0 translator into THF syntax.
%          : The translation has been applied in two modes: local and SInE.
%            The local mode only translates the local assumptions and the
%            query. The SInE mode additionally translates the SInE-extract
%            of the loaded knowledge base (usually SUMO).
%          : The examples are selected to illustrate the benefits of
%            higher-order reasoning in ontology reasoning.
%------------------------------------------------------------------------------
%----The extracted Signature
thf(numbers,type,
    num: $tType ).

thf(knows,type,
    knows: $i > $o > $o ).

thf(milhouse,type,
    milhouse: $i ).

thf(bart,type,
    bart: $i ).

thf(martin,type,
    martin: $i ).

thf(lisa,type,
    lisa: $i ).

thf(likes,type,
    likes: $i > $i > $o ).

thf(ax_knowledge,axiom,
    ! [X : $i, Y : $o] : ( knows @ X @ Y => (Y) ) ).

thf(ax_mp,axiom,
    ! [X : $i, Y : $o, Z : $o] : ( ( ( knows @ X @ ( Y => Z ) ) & ( knows @ X @ Y ) ) => ( knows @ X @ Z ) ) ).

%----The translated axioms
thf(ax,axiom,
    knows @ bart @ ( bart = bart ) ).

thf(ax_001,axiom,
    likes @ martin @ milhouse ).

thf(ax_002,axiom,
    ( knows @ bart
    @ ! [X: $i] :
        ( ( likes @ martin @ X )
       => ( likes @ lisa @ X ) ) ) ).

%----The translated conjectures
thf(con,conjecture,
    knows @ bart @ ( likes @ lisa @ milhouse ) ).

%------------------------------------------------------------------------------
