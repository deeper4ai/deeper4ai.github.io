thf(f,type,
    f: $i > $i > $i > $i > $i > $i > $i ).

thf(a,type,
    a: $i ).

thf(b,type,
    b: $i ).

thf(c,type,
    c: $i ).

thf(ax,axiom,
    ! [F: $i > $i > $i > $i > $i > $i > $i > $i > $i > $i > $i > $i > $i] :
      ( ( ( F @ a @ b @ c @ c @ c @ c @ c @ c @ c @ c @ c @ c )
       != ( f @ b @ a @ c @ c @ c @ c ) )
      | ( ( F @ c @ a @ c @ c @ c @ c @ c @ c @ c @ c @ c @ c )
       != ( f @ a @ c @ c @ c @ c @ c ) ) ) ).