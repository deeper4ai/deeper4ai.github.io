%------------------------------------------------------------------------------
% File     : CAT040_HOL^1 : TPTP v9.2.1. Released v9.2.0.
% Domain   : Category Theory
% Problem  : Simple problem from category theory dhol_2
% Version  : Especial.
% English  :

% Refs     : [RRB23] Rothgang et al. (2023), Theorem Proving in Dependently
%          : [Rot25] Rothgang (2025), Email to Geoff Sutcliffe
%          : [RK+25] Ranalter et al. (2025), The Dependently Typed Higher-O
% Source   : [Rot25]
% Names    : CategoryTheory/category-theory-lemmas-dhol_2.p [Rot25]

% Status   : Theorem
% Rating   : ? v9.2.0
% Syntax   : Number of formulae    :    8 (   3 unt;   4 typ;   0 def)
%            Number of atoms       :    8 (   8 equ;   0 cnn)
%            Maximal formula atoms :    5 (   2 avg)
%            Number of connectives :   66 (   0   ~;   0   |;   3   &;  62   @)
%                                         (   0 <=>;   1  =>;   0  <=;   0 <~>)
%            Maximal formula depth :   10 (   7 avg)
%            Number of types       :    1 (   1 usr)
%            Number of type decls  :    4 (   0 !>P;   2 !>D)
%            Number of type conns  :    4 (   4   >;   0   *;   0   +;   0  <<)
%            Number of symbols     :    4 (   3 usr;   0 con; 1-5 aty)
%            Number of variables   :   22 (   0   ^;  18   !;   0   ?;  22   :)
%                                         (   4  !>;   0  ?*;   0  @-;   0  @+)
% SPC      : DH0_THM_EQU_NAR

% Comments :
%------------------------------------------------------------------------------

thf(is_per_type,type,
    isPer: 
      !>[A: $tType] : ( ( A > A > $o ) > $o ) ).

thf(is_per,definition,
    ! [A: $tType,AStar: A > A > $o] :
      ( ( isPer @ A @ AStar )
    <=> ( ! [X: A,Y: A] :
            ( ( AStar @ X @ Y )
           => ( AStar @ Y @ X ) )
        & ! [X: A,Y: A,Z: A] :
            ( ( AStar @ X @ Y )
           => ( ( AStar @ Y @ Z )
             => ( AStar @ X @ Z ) ) ) ) ) ).

thf(obj_type,type,
    obj: $tType ).

thf(objStar,type,
    objStar: obj > obj > $o ).

thf(objStar_is_eq,axiom,
    ! [X: obj,Y: obj] :
      ( ( objStar @ X @ Y )
    <=> ( X = Y ) ) ).

thf(mor_type,type,
    mor: $tType ).

thf(morStar,type,
    morStar: obj > obj > mor > mor > $o ).

thf(morStar_is_per,axiom,
    ! [C: obj,C0: obj] : ( isPer @ mor @ ( morStar @ C @ C0 ) ) ).

thf(id_type,type,
    id: obj > mor ).

thf(id_tp_ax,axiom,
    ! [X: obj] : ( morStar @ X @ X @ ( id @ X ) @ ( id @ X ) ) ).

thf(comp_type,type,
    comp: obj > obj > obj > mor > mor > mor ).

thf(comp_tp_ax,axiom,
    ! [X: obj,Y: obj,Z: obj,D: mor,D_prime: mor] :
      ( ( morStar @ X @ Y @ D @ D_prime )
     => ! [D0: mor,D0_prime: mor] :
          ( ( morStar @ Y @ Z @ D0 @ D0_prime )
         => ( morStar @ X @ Z @ ( comp @ X @ Y @ Z @ D @ D0 ) @ ( comp @ X @ Y @ Z @ D_prime @ D0_prime ) ) ) ) ).

thf(ax1,axiom,
    ! [X: obj,Y: obj,M: mor] :
      ( ( morStar @ X @ Y @ M @ M )
     => ( morStar @ X @ Y @ ( comp @ X @ X @ Y @ ( id @ X ) @ M ) @ M ) ) ).

thf(ax2,axiom,
    ! [X: obj,Y: obj,M: mor] :
      ( ( morStar @ X @ Y @ M @ M )
     => ( morStar @ X @ Y @ ( comp @ X @ Y @ Y @ M @ ( id @ Y ) ) @ M ) ) ).

thf(ax3,axiom,
    ! [X: obj,Y: obj,Z: obj,A: obj,F: mor,G: mor,H: mor] :
      ( ( morStar @ X @ Y @ F @ F )
     => ( ( morStar @ Y @ Z @ G @ G )
       => ( ( morStar @ Z @ A @ H @ H )
         => ( morStar @ X @ A @ ( comp @ X @ Y @ A @ F @ ( comp @ Y @ Z @ A @ G @ H ) ) @ ( comp @ X @ Z @ A @ ( comp @ X @ Y @ Z @ F @ G ) @ H ) ) ) ) ) ).

thf(conj,conjecture,
    ! [X: obj,Y: obj,Z: obj,F: mor,G: mor] :
      ( ( morStar @ X @ Y @ F @ F )
     => ( ( morStar @ Y @ Z @ G @ G )
       => ( ( ( X = Y )
            & ( Y = Z )
            & ( morStar @ X @ Y @ F @ ( id @ X ) )
            & ( morStar @ Y @ Z @ G @ ( id @ Y ) ) )
         => ( morStar @ X @ Z @ ( comp @ X @ Y @ Z @ F @ G ) @ ( id @ Z ) ) ) ) ) ).