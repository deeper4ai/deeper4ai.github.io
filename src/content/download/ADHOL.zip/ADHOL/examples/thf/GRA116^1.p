thf(inj_tp,type,
    inj: ( $i > $i ) > $o ).

thf(inj_def,definition,
    ( inj
    = ( ^ [F: $i > $i] :
        ! [X: $i,Y: $i] :
          ( ( ( F @ X )
            = ( F @ Y ) )
         => ( X = Y ) ) ) ) ).

thf(surj_tp,type,
    surj: ( $i > $i ) > $o ).

thf(surj_def,definition,
    ( surj
    = ( ^ [F: $i > $i] :
        ! [Z: $i] :
        ? [X: $i] :
          ( ( F @ X )
          = Z ) ) ) ).

thf(inf,axiom,
    ? [F: $i > $i] :
      ( ( inj @ F )
      & ~ ( surj @ F ) ) ).

thf(b_tp,type,
    b: $i > $i > $o ).

thf(r_tp,type,
    r: $i > $i > $o ).

thf(rb_cov,axiom,
    ! [X: $i,Y: $i] :
      ( ( X = Y )
      | ( r @ X @ Y )
      | ( b @ X @ Y ) ) ).

thf(axr,axiom,
    ! [X0: $i,X1: $i,X2: $i,X3: $i] :
      ( ~ ( r @ X0 @ X1 )
      | ~ ( r @ X0 @ X2 )
      | ~ ( r @ X1 @ X2 )
      | ~ ( r @ X0 @ X3 )
      | ~ ( r @ X2 @ X3 ) ) ).

thf(axb,axiom,
    ! [X0: $i,X1: $i,X2: $i,X3: $i,X4: $i] :
      ( ~ ( b @ X0 @ X1 )
      | ~ ( b @ X0 @ X2 )
      | ~ ( b @ X1 @ X2 )
      | ~ ( b @ X2 @ X3 )
      | ~ ( b @ X2 @ X4 )
      | ~ ( b @ X3 @ X4 ) ) ).

%------------------------------------------------------------------------------
