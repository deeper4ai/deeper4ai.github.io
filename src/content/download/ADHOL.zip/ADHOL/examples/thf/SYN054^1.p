%--------------------------------------------------------------------------
% File     : SYN054+1 : TPTP v9.2.1. Released v2.0.0.
% Domain   : Syntactic
% Problem  : Pelletier Problem 24
% Version  : Especial.
% English  :

% Refs     : [KM64]  Kalish & Montegue (1964), Logic: Techniques of Formal
%          : [Pel86] Pelletier (1986), Seventy-five Problems for Testing Au
%          : [Hah94] Haehnle (1994), Email to G. Sutcliffe
% Source   : [Hah94]
% Names    : Pelletier 24 [Pel86]

% Status   : Theorem
% Rating   : 0.00 v5.3.0, 0.09 v5.2.0, 0.00 v2.1.0
% Syntax   : Number of formulae    :    5 (   0 unt;   0 def)
%            Number of atoms       :   12 (   0 equ)
%            Maximal formula atoms :    3 (   2 avg)
%            Number of connectives :    9 (   2   ~;   2   |;   2   &)
%                                         (   0 <=>;   3  =>;   0  <=;   0 <~>)
%            Maximal formula depth :    4 (   4 avg)
%            Maximal term depth    :    1 (   1 avg)
%            Number of predicates  :    4 (   4 usr;   0 prp; 1-1 aty)
%            Number of functors    :    0 (   0 usr;   0 con; --- aty)
%            Number of variables   :    6 (   2   !;   4   ?)
% SPC      : FOF_THM_RFO_NEQ

% Comments :
%--------------------------------------------------------------------------

thf(big_p,type, 
    big_p: $i > $o ).
thf(big_s,type, 
    big_s: $i > $o ).
thf(big_q,type, 
    big_q: $i > $o ).
thf(big_r,type, 
    big_r: $i > $o ).

thf(pel24_1,axiom,
    ~ ( ? [X : $i] :
        ( big_s @ X & big_q @ X ) ) ).

thf(pel24_2,axiom,
    ! [X : $i] :
      ( big_p @ X
     => ( big_q @ X
        | big_r @ X ) ) ).

thf(pel24_3,axiom,
    ( ~ ( ? [X : $i] : ( big_p @ X )
   => ? [Y : $i] : ( big_q @ Y ) ) ) ).

thf(pel24_4,axiom,
    ! [X : $i] :
      ( ( big_q @ X
        | big_r @ X )
     => big_s @ X ) ).

thf(pel24,conjecture,
    ? [X : $i] :
      ( big_p @ X
      & big_r @ X ) ).

%--------------------------------------------------------------------------
