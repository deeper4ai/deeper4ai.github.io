from datatypes import *
from hol import *
from random import shuffle

class FlatTerm():
	quantifiers : Ctx
	head : str
	arguments : list[FlatTerm]

	def __init__(self, quantifiers, head, arguments):
		self.quantifiers = quantifiers ; self.head = head ; self.arguments = arguments

	def __str__(self):
		if len(self.quantifiers) == 0 and len(self.arguments) == 0:
			#return self.head.split(".")[0]
			return self.head
		if self.head.startswith("EQ") and self.quantifiers == []:
			return f"[{self.arguments[0]}=={self.arguments[1]}]"
		if self.head in ["knows", "likes", "or", "and", "impl"] and self.quantifiers == []:
			return f"[{self.arguments[0]} {self.head} {self.arguments[1]}]"
		
		s = ""
		if len(self.quantifiers) > 0:
			s += "λ"
		for q in self.quantifiers:
			s += f"{q[0]}:{q[1]},"
		if len(self.quantifiers) > 0:
			s = s[:-1] + ". "
		s += self.head.split(".")[0]
		for arg in self.arguments:
			if len(arg.quantifiers) == 0 and len(arg.arguments) == 0:
				s += f" {arg}"
			else:
				s += f" [{arg}]"
		return s + ""
	
	def __hash__(self):
		return flat_canonical_string(self, {}).__hash__()

	def __eq__(self,other): # Slower than directly
		if isinstance(other, FlatTerm):
			return flat_canonical_string(self, {}) == flat_canonical_string(other, {})
		return False
	
	def validate(self):
		try:
			trying = "quantifiers"
			for q0, q1 in self.quantifiers:
				assert isinstance(q0, str) and isinstance(q1, FlatTerm)
			trying = "head"
			assert isinstance(self.head, str)
			trying = "args"
			for arg in self.arguments:
				if isinstance(arg, FlatTerm):
					arg.validate()
				elif isinstance(arg, str):
					raise TypeError
		except Exception as a:
			print(f"Flat term {self} had type error ({trying}) with quantifiers={Ctx(self.quantifiers)}, head={self.head}, arguments={self.arguments}")
			raise a

class FLiteral():
	pol : bool
	term : FlatTerm
	def __init__(self, pol_ : bool, term_ : FlatTerm):
		if not isinstance(term_, FlatTerm):
			raise ValueError
		self.pol = pol_
		self.term = term_
	
	def __str__(self):
		if self.term.head.startswith("EQ"):
			return f"{self.term.arguments[0]}={"=" if self.pol else "/"}={self.term.arguments[1]}"
		return f"{"-" if not self.pol else ""}{self.term}"
	
	def full_str(self):
		s = "-[" if (not self.pol) else "["
		s += str(self.term)
		s += "]"
		return s

def flatten(term : Term, none_ok : bool = False, recr : int = 0) -> FlatTerm:
	ret = None
	if isinstance(term, str):
		ret = FlatTerm([], term, [])
	if isinstance(term, (Pi, Abs)):
		#print(recr*' '+f"Flattening term {term}...")
		flat = flatten(term.body, recr+1)
		flat.quantifiers = [(term.var, flatten(term.var_type, recr+1))] + flat.quantifiers
		ret = flat
		#print(recr*' '+f"Flattened = {ret}")
	
	if isinstance(term, App):
		flat_opt = flatten(term.operator, recr+1)
		flat_opd = flatten(term.operand, recr+1)
		flat_opt.arguments.append(flat_opd)
		ret = flat_opt
	
	if isinstance(term, FlatTerm): # Assumes all terms are entirely flat or entirely unflat
		ret = term
	
	
	if not ret:
		if none_ok:
			return None
	else:
		return ret 
	
	raise ValueError(term, type(term))

def unflatten(flat : FlatTerm, as_type : bool = False) -> Term:
	if isinstance(flat, FLiteral):
		if flat.pol:
			return unflatten(flat.term)
		return NOT(unflatten(flat.term))
	if isinstance(flat, Term):
		return flat
	if isinstance(flat, str):
		return flat
	
	if len(flat.quantifiers) > 0:
		if not as_type:
			return Abs(
				flat.quantifiers[0][0], 
				unflatten(flat.quantifiers[0][1], True), 
				unflatten(FlatTerm(flat.quantifiers[1:], flat.head, flat.arguments), as_type))
		else:
			return Pi(
				flat.quantifiers[0][0],
				unflatten(flat.quantifiers[0][1], True), 
				unflatten(FlatTerm(flat.quantifiers[1:], flat.head, flat.arguments), as_type))
		
	if len(flat.arguments) > 0:
		return App(unflatten(FlatTerm(flat.quantifiers, flat.head, flat.arguments[:-1]), as_type), unflatten(flat.arguments[-1], as_type))
	return flat.head

def unflatten_ctx(ctx : Ctx) -> Ctx:
	#dbp(f"Unflattening, ctx = ...{Ctx(ctx[-2:])}")
	ret = [(c[0], unflatten(c[1], True)) for c in ctx]
	#dbp(f"Ret = ...{Ctx(ret[-2:])}")
	return ret

def flat_substituted(unif : Unifier, in_term : FlatTerm, from_quantifier_position : int = 0) -> FlatTerm:
	'''Perform a substitution using the provided dict `unif` (note: not a unifier, just convenient printing)'''
	if unif == {}:
		return in_term
	
	# Shallow copy of quantifiers and arguments
	flat_copy = FlatTerm(in_term.quantifiers[:from_quantifier_position], in_term.head, in_term.arguments)

	# Perform substitutions in types of bound variables and check for name collisions (probably never).
	for i in range(from_quantifier_position, len(in_term.quantifiers)):
		q = in_term.quantifiers[i]
		if q[0] in unif: 
			# Stop immediately if there is a bound variable name collision. We ASSUME that a bound variable
			# won't appear in its own type, although there is theoretically nothing preventing this, as long as
			# it is bound somewhere else (or constant, or a variable...)
			return FlatTerm(flat_copy.quantifiers[:i] + in_term.quantifiers[i:], in_term.head, in_term.arguments)
		flat_copy.quantifiers.append((q[0], flat_substituted(unif, q[1])))

	# Continue substitution, potentially including the head (requiring beta-reduction)
	return flat_substituted_head(unif, flat_copy)


def flat_substituted_head(unif : Unifier, term : FlatTerm) -> FlatTerm:
	'''Simultaneous substitution of a term using the dict `unif`, involving beta-reduction'''
	if term.head in unif and isinstance(unif[term.head], FlatTerm):
		# Beta reduction case. Complicated when using spine notation! Given the structure
		# of the term and its replacement, we remove/replace a certain calculated number of
		# quantifiers and arguments, and perform substitutions again once that is done. 
		replacement = unif[term.head]
		assert isinstance(replacement, FlatTerm)
		k = len(replacement.quantifiers)
		n = len(term.arguments)

		repl_args = replacement.arguments
		repl_qfs = replacement.quantifiers[n:]
		head_repl = None

		for i in range(min(k,n)):
			s = replacement.quantifiers[i][0]
			t = term.arguments[i]

			if s == replacement.head:
				head_repl = t

			repl_args = [flat_substituted({s:t}, repl_args[j]) for j in range(len(repl_args))]
			repl_qfs = [(repl_qfs[j][0], flat_substituted({s:t}, repl_qfs[j][1])) for j in range(len(repl_qfs))]

		ret = FlatTerm(
			term.quantifiers + repl_qfs, 
			replacement.head, 
			repl_args + term.arguments[k:]
		)

		if head_repl != None: 
			# Head was previously bound but now must be replaced with one of the arguments (recursively).
			# Impossible for this to be occurs-y 
			ret = flat_substituted_head({ret.head:head_repl}, ret)
		if replacement.head in unif and not contains_symbol(unif[replacement.head], replacement.head):
			# Perform substitution recursively unless it is occurs-y
			ret = flat_substituted_head(unif, ret)

		return ret

	elif term.head in unif and isinstance(unif[term.head], str):
		# Term head is directly atomically replaceable. 
		# N.B. we can also do a quick replacement when there are no quantifiers in the replacement...
		return FlatTerm(
			term.quantifiers, 
			unif[term.head], 
			[flat_substituted(unif, a) for a in term.arguments]
		)
	else:
		# Term head has nothing to do with the substitution. Replace arguments. 
		return FlatTerm(
			term.quantifiers, 
			term.head, 
			[flat_substituted(unif, a) for a in term.arguments]
		)


def composed_flat_unifiers(unif0 : Unifier, unif1 : Unifier) -> Unifier:
	'''The union of two substitutions (with replacement). If there is overlap
	the entry from unif1 will be used, albeit transitively replaced. '''
	new_unifier = Unifier()
	for key in unif0.keys():
		if key in unif1:
			unif0[key] = unif1[key]
		else:
			new_unifier[key] = flat_substituted(unif1, unif0[key])
	for new_key in unif1.keys():
		if new_key not in new_unifier:
			if not isinstance(unif1[new_key], FlatTerm):
				raise TypeError(f"Substitution for {new_key} in unif1 expected to be FlatTerm but was {unif1[new_key]} ({type(unif1[new_key])})")
			new_unifier[new_key] = unif1[new_key]
	#print(f"Composed unifiers {unif0} and {unif1} to make {new_unifier}")
	return new_unifier

def composed_flat_unifier_list(unif_list : list[Unifier]) -> Unifier:
	'''Compose an arbitrary number of substitutions (in overwriting order)'''
	unif = Unifier()
	for u in unif_list:
		unif = composed_flat_unifiers(unif, u)
	return unif

def applied_to_eqns(eqns : Eqns, unif : Unifier):
	return Eqns([(flat_substituted(unif, e0), flat_substituted(unif, e1)) for e0, e1 in eqns])

def applied_to_ctx(ctx : Ctx, unif : Unifier):
	return Ctx([(c0, flat_substituted(unif,c1)) for c0,c1 in ctx])


# Modify the term to only contain approximate types in its quantifiers
def approximate_term(flat : FlatTerm):
	return FlatTerm(
		approximate_context(flat.quantifiers),
		flat.head,
		list(map(approximate_term, flat.arguments))
	)

def approximate_type(flat : FlatTerm):
	return FlatTerm(
		[("", approximate_type(q[1])) for q in flat.quantifiers],
		flat.head,
		[]
	)

def arguments_removed(flat : FlatTerm) -> FlatTerm:
	return FlatTerm(flat.quantifiers, flat.head, [])

def last_argument_removed(flat : FlatTerm) -> FlatTerm:
	return FlatTerm(flat.quantifiers, flat.head, flat.arguments[:-1])

def first_quantifier_removed(flat : FlatTerm) -> FlatTerm:
	return FlatTerm(flat.quantifiers[1:], flat.head, flat.arguments)

def quantified_by_context(flat : FlatTerm, ctx : Ctx):
	return FlatTerm(ctx + flat.quantifiers, flat.head, flat.arguments)

def quantifiers_removed(flat : FlatTerm) -> FlatTerm:
	return FlatTerm([], flat.head, flat.arguments)

# Types of symbols 
def approximate_context(ctx : Ctx) -> Ctx:
	actx = [(c_symbol, approximate_type(flatten(c_type))) for c_symbol,c_type in ctx]
	return actx

def approximate_flat_type_check(flat : FlatTerm, sig : Sig, bctx : Ctx, ctx : Ctx):
	approx_sig = Sig()
	approx_sig.constants = {c : unflatten(approximate_type(flatten(d)), True) for c,d in sig.constants.items()}
	return flat_type_check(approximate_term(flat), approx_sig, approximate_context(bctx), approximate_context(ctx))

def flat_type_check(flat : FlatTerm, sig : Sig, bctx : Ctx, ctx : Ctx):
	try:
		return flatten(type_check(unflatten(flat), sig, unflatten_ctx(bctx), unflatten_ctx(ctx)), True)
	except InvalidType:
		return None

def is_flat_eq(flat : FlatTerm):
	return flat.head.startswith("EQ")

def flat_eq_parts(flat : FlatTerm):
	return flat.arguments[0], flat.arguments[1]

def flat_canonical_string(flat : FlatTerm, debruijn : dict, at_level : int = 0):
	qfs = []
	for i in range(len(flat.quantifiers)):
		qfs.append(flat_canonical_string(flat.quantifiers[i][1], debruijn, at_level))
		at_level += 1
		debruijn[flat.quantifiers[i][0]] = at_level
	head = (at_level - debruijn[flat.head]) if flat.head in debruijn else flat.head
	if len(qfs) == 0 and len(flat.arguments) == 0:
		return (head,)
	return (tuple(qfs), head, tuple(flat_canonical_string(flat.arguments[i], debruijn, at_level) for i in range(len(flat.arguments))))

def copy_flat_term(flat : FlatTerm) -> FlatTerm:
	return FlatTerm(
		[(q0,copy_flat_term(q1)) for q0,q1 in flat.quantifiers],
		flat.head,
		[copy_flat_term(a) for a in flat.arguments]
	)


def term_from_flat_literal(f : FLiteral):
	return f.term if f.pol else FlatTerm([], 'not', [f.term])


def flat_aeq(s : FlatTerm, t : FlatTerm, binding : dict):
	if isinstance(s, FLiteral):
		s = term_from_flat_literal(s)
	if isinstance(t, FLiteral):
		t = term_from_flat_literal(t)
		
	if len(s.quantifiers) != len(t.quantifiers) or len(s.arguments) != len(t.arguments):
		return False
	for i in range(len(s.quantifiers)):
		if not flat_aeq(s.quantifiers[i][1], t.quantifiers[i][1], binding):
			return False
		if s.quantifiers[i][0] != t.quantifiers[i][0]:
			binding = binding.copy()
			binding[t.quantifiers[i][0]] = s.quantifiers[i][0]
	if s.head != t.head and binding.get(t.head, None) == None:
		return False
	
	return all(flat_aeq(s.arguments[i], t.arguments[i], binding) for i in range(len(s.arguments)))

def contains_symbol(term : FlatTerm, symbol : str):
	if term.head == symbol:
		return True
	for q in term.quantifiers:
		if contains_symbol(q[1], symbol):
			return True
	for a in term.arguments:
		if contains_symbol(a, symbol):
			return True
	return False