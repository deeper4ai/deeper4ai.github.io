from leo_style_parser.bin.python3 import tptp_parser as tp
from datatypes import *
from hol import Ctx
from common import *

STRUCTURE_TYPES = {prop[1] : prop[0].replace("structuretype_", "") for prop in tp.__dict__.items() if prop[0].startswith("structuretype_")}
NODE_TYPES = {prop[1] : prop[0].replace("nodetype_", "") for prop in tp.__dict__.items() if prop[0].startswith("nodetype_")}

DEBUG_PARSER = 1
def db(s):
	(not DEBUG_PARSER) or print(s)

class ParserError(Exception): pass
class PostParserError(Exception): pass

# Highly convenient classes for parsing, need to convert back to ordinary quantifier representation later
class LongQuantifier():
	symbols : Ctx
	body : Term
	base : type
	def __init__(self, symbols, body, base : type):
		self.symbols = symbols ; self.body = body ; self.base = base
	def __str__(self):
		return f"{Ctx(self.symbols)}: {self.body}"
	def to_base(self):
		if len(self.symbols) == 1:
			return self.base(self.symbols[0][0], self.symbols[0][1], self.body)
		return self.base(self.symbols[0][0], self.symbols[0][1], LongQuantifier(self.symbols[1:], self.body, self.base).to_base())

class TPTPFormula():
	dialect : str
	formula_name : str
	formula_type : str
	formula = None

	def __str__(self):
		return f"{self.dialect} {self.formula_name} {self.formula_type} ==> {self.formula} )"
	
def _long_quantifiers_removed(formula, neg_conj : bool):
	if isinstance(formula, TPTPFormula):
		if formula.formula_type == "type":
			return (formula.formula[0], _long_quantifiers_removed(formula.formula[1], neg_conj))
		if formula.formula_type == "conjecture":
			if neg_conj:
				print(f"Negating conjecture = {formula}")
				return NOT(_long_quantifiers_removed(formula.formula, neg_conj))
			return _long_quantifiers_removed(formula.formula, neg_conj)
		return _long_quantifiers_removed(formula.formula, neg_conj)
	if isinstance(formula, App):
		return App(_long_quantifiers_removed(formula.operator, neg_conj), _long_quantifiers_removed(formula.operand, neg_conj))
	if isinstance(formula, Quantifier):
		return formula.__class__(formula.var, _long_quantifiers_removed(formula.var_type, neg_conj), _long_quantifiers_removed(formula.body, neg_conj))
	if isinstance(formula, str):
		return formula
	if isinstance(formula, LongQuantifier):
		return _long_quantifiers_removed(formula.to_base(), neg_conj)
	
	raise PostParserError(formula)

def parse(filename : str, negate_conjecture : bool = False, debug_parser : bool = False):
	global DEBUG_PARSER ; DEBUG_PARSER = debug_parser
	try:
		if DEBUG_PARSER:
			print(f"Parsing file {filename}")
			print(f"Raw ASCII:\n")
			i = 1
			for line in open(filename, "r", encoding="ascii").readlines():
				print(f"{i:>3}| {line}",end="")
				i += 1
			print('\n')
		ast : tp.node = tp.parse(filename)
		if ast == None or ast.structure == 0:
			raise ParserError(filename)
		db(f"Initial parse succeeded")
		formulas = []
		for a in ast:
			db(f"Converting formula {a}...")
			converted = _long_quantifiers_removed(_parse_formula(a), negate_conjecture)
			db(f"Formula {a} converted to {converted}")
			formulas.append(converted)
		return formulas
	except ParserError as e:
		db(f"There was a parser error for object {e}")


def _parse_formula(formula : tp.node) -> TPTPFormula | Term:
	db(f"Formula {formula} has structure {STRUCTURE_TYPES[formula.structure]}:")
	for i in range(formula.numChildren):
		db(f"\t{i}: {formula[i]}")

	match formula.structure:

		case tp.structuretype_SINGLE:
			for child in formula:
				return _parse_formula(child)
		
		case tp.structuretype_none:
			db(f"\tIs just {formula}")

			# some straightforward substitutions
			if str(formula) == "$tType":
				return TP
			if str(formula) == "$o":
				return 'bool'
			if str(formula) == "$i":
				return 'ind'
			if str(formula) == "$true":
				return 'true'
			if str(formula) == "$false":
				return 'false'
			if str(formula) == "~":
				return 'not'
			
			return str(formula)
			
		case tp.structuretype_ANNONTATED:
			tf = TPTPFormula()
			tf.dialect = _parse_formula(formula[0])
			tf.formula_name = _parse_formula(formula[1])
			tf.formula_type = _parse_formula(formula[3])
			if tf.formula_type == "type":
				tf.formula = _parse_declaration(formula[5])
			else:
				tf.formula = _parse_formula(formula[5])
			return tf

		case tp.structuretype_PREFIX:
			op = _parse_formula(formula[0])
			if isinstance(op, LongQuantifier):
				op.body = _parse_formula(formula[1])
				db(f"{formula}: body is long quantifier")
				return op
			db(f"OP = {op}")
			match op:
				case "~":
					return NOT(_parse_formula(formula[1]))
				case "not":
					return NOT(_parse_formula(formula[1]))
		
		case tp.structuretype_BRACKET:
			incl = _parse_formula(formula[0])
			if isinstance(incl, str) and incl.startswith("include"):
				incl_path = _parse_formula(formula[1])
				if not isinstance(incl_path, str):
					raise ParserError
				incl_path = incl_path.replace("Axioms/", "examples/_axioms/")
				recursive_parse = parse(incl_path)
				if recursive_parse:
					return recursive_parse
				raise ParserError

			return _parse_formula(formula[1])
		
		case tp.structuretype_BINDER:
			optype = _parse_formula(formula[0])
			declarations = _parse_declaration(formula[2])
			match optype:
				case '!':
					base = All
				case '!>':
					base = Pi
				case '?':
					base = Ext
				case '@+':
					raise ParserError("Formula contains choice which we are not equipped to handle")
				case '^':
					base = Abs
			
			if base == None:
				raise ParserError(formula)
			return LongQuantifier(declarations, None, base)
		
		case tp.structuretype_OPERATOR:
			optype = _parse_formula(formula[1])
			match optype:
				case '@':
					return App(_parse_formula(formula[0]), _parse_formula(formula[2]))
				case '=':
					return App(App('eq', _parse_formula(formula[0])), _parse_formula(formula[2]))
				case '>':
					return Pi("", _parse_formula(formula[0]), _parse_formula(formula[2]))
				case '&':
					return App(App('and', _parse_formula(formula[0])), _parse_formula(formula[2]))
				case '=>':
					return App(App('impl', _parse_formula(formula[0])), _parse_formula(formula[2]))
				case '!=':
					return NOT(App(App('eq', _parse_formula(formula[0])), _parse_formula(formula[2])))
				case '<=>':
					lhs = _parse_formula(formula[0]) ; rhs = _parse_formula(formula[2])
					return AND(IMPL(lhs, rhs), IMPL(rhs, lhs))
				case '|':
					return App(App('or', _parse_formula(formula[0])), _parse_formula(formula[2]))
			db(f"Formula {formula} has unhandled operator {optype}")


	
	db(f"Formula {formula} is unhandled: {STRUCTURE_TYPES[formula.structure]}")
	raise ParserError(formula)

def _parse_declaration(formula : tp.node):
	db(f"Declaration {formula} has structure {STRUCTURE_TYPES[formula.structure]}:")
	for i in range(formula.numChildren):
		db(f"\t{i}: {formula[i]}")
	
	match formula.structure:
		case tp.structuretype_BRACKET:
			return _parse_declaration(formula[1])
		case tp.structuretype_SINGLE:
			return _parse_declaration(formula[0])
		case tp.structuretype_OPERATOR:
			if _parse_formula(formula[1]) == ":":
				return (_parse_formula(formula[0]), _parse_formula(formula[2]))
			raise ParserError
		
		case tp.structuretype_SEPERATED_SEQUENCE:
			return [_parse_declaration(child) for child in formula if str(child) != ","]
	
	db(f"Declaration {formula} unhandled")
	raise ParserError(formula)