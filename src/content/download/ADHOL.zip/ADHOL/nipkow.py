from common import *
from hol import *
from flat_term import *
from typing import Generator
from random import shuffle

DEBUG_ON = 1
def db(s):
	(not DEBUG_ON) or print(s)

class HOLTypingError(Exception):
	pass


def is_free(var : str, in_binding_ctx : Ctx):
	assert isinstance(var, str)
	return var not in hol_constants and get_from_context(in_binding_ctx, var) == None

def is_bnf(term : Term):
	if isinstance(term, (Abs,Pi)):
		return is_bnf(term.body)
	if isinstance(term, App):
		if isinstance(term.operator, (Abs,Pi)):
			return False
		return is_bnf(term.operator, term.operand)
	return True

def is_pattern(term : Term, in_binding_ctx : Ctx):
	t = flatten(term)
	return flat_is_pattern(flatten(term), in_binding_ctx)

def flat_is_pattern(flat : FlatTerm, in_binding_ctx : Ctx):
	if is_free(flat.head, in_binding_ctx + flat.quantifiers):
		
		if len(set([arg.head for arg in flat.arguments])) != len(flat.arguments):
			db(f"Flat term {flat} with free head {flat.head} is not applied to distinct symbols")
			return False
		
		for arg in flat.arguments:
			if get_from_context(in_binding_ctx + flat.quantifiers, arg.head) == None: # Var is not a bound variable
				db(f"Flat term {flat} with free head {flat.head} has non-bound argument {arg}")
				return False
			if len(arg.quantifiers) != len(arg.arguments): # Var is not eta-equivalent to its head alone
				db(f"Flat term {flat} with free head {flat.head} has non-eta-style {arg}")
				return False
			# Is it also important to check that the quantifiers match the order of the arguments?
	
	ret = all([flat_is_pattern(arg, in_binding_ctx + flat.quantifiers) for arg in flat.arguments])
	if not ret:
		db(f"Flat term {flat} had an argument which is not flat...")
	return ret


def pair_is_pattern_unifiable(term0 : Term, term1 : Term, bctx : Ctx):
	flat0 = flatten(term0) ; flat1 = flatten(term1)
	return flat_is_pattern(flat0, bctx) and flat_is_pattern(flat1, bctx) and len(flat0.quantifiers) == len(flat1.quantifiers)


def list_all_pattern_unifiers(term0 : Term, term1 : Term, ctx : Ctx, max_unifs : int = 10) -> list[Unifier]:
	flat0 = flatten(term0) ; flat1 = flatten(term1)
	if (not flat_is_pattern(flat0, [])) or (not flat_is_pattern(flat1, [])):
		db(f"Terms are not patterns")
		return None
	unifs = []
	generator = unify_flat_patterns(flat0, flat1, ctx, [])
	iters = max_unifs

	while iters > 0:
		try: 
			n = next(generator)
		except StopIteration:
			break
		unifs.append(n)
		iters -= 1
	
	if iters <= 0:
		db(f"Pattern unification exceeded max_unifs={max_unifs} generations, returning all obtained")
	return unifs

'''
Returns a generator of possible unifiers for the two terms, i.e. a disjunction. The generator will be empty if 
the two terms are not unifiable under any pattern unifier. Assumption/invariant violations will throw a HOLTypingError. 
'''
def unify_flat_patterns(flat0 : FlatTerm, flat1 : FlatTerm, global_ctx : Ctx, binding_ctx : Ctx) -> Generator[Unifier, None, None]:
	if (not flat_is_pattern(flat0, binding_ctx)):
		raise HOLTypingError(f"Not pattern: {flat0}")
	if (not flat_is_pattern(flat1, binding_ctx)):
		raise HOLTypingError(f"Not pattern: {flat1}")
	
	if len(flat0.quantifiers) != len(flat1.quantifiers):
		db(f"{flat0}=={flat1} is unsatisfiable because quantifiers are different")
		return

	free0 = is_free(flat0.head, binding_ctx + flat0.quantifiers)
	free1 = is_free(flat1.head, binding_ctx + flat1.quantifiers)

	if (not free0) and free1: # Swap flex, rigid
		tmp = flat0 ; flat0 = flat1 ; flat1 = tmp
		tmp = free0 ; free0 = free1 ; free1 = tmp

	db(f"Terms are {flat0}, {flat1}, renaming now")
	for i in range(len(flat0.quantifiers)):
		if not aeq(flat0.quantifiers[i][1], flat1.quantifiers[i][1]):
			# TODO: we will likely need to beta-eta-normalise these types.
			db(f"Quantifiers did not have a-equivalent types: {flat0.quantifiers[i]} vs. {flat1.quantifiers[i]}")
			return
		if flat1.head == flat1.quantifiers[i][0]:
			flat1.head = flat0.quantifiers[i][0]
		for i in range(len(flat1.arguments)):
			flat1.arguments[i] = flat_substituted(flat1.quantifiers[i][0], flat0.quantifiers[i][0], flat1.arguments[i])
		flat1.quantifiers[i] = (flat0.quantifiers[i][0], flat0.quantifiers[i][1])
		

	# Both terms now have the same quantifiers, so remove both and add them to the binding ctx
	binding_ctx += flat0.quantifiers
	flat0.quantifiers = Ctx()
	flat1.quantifiers = Ctx()

	db(f"Renamed, now unifying flat terms {flat0}, {flat1}...")

	if (not free0) and (not free1):
		db(f"{flat0}=={flat1} is rigid-rigid, yielding from SIMPL...")
		rigid_rigid = SIMPL(flat0, flat1, global_ctx, binding_ctx)
		while True:
			try:
				yield next(rigid_rigid)
			except StopIteration:
				break
	
	if free0 and (not free1):
		db(f"{flat0}=={flat1} is flex-rigid, yielding from MATCH...")
		flex_rigid = MATCH(flat0, flat1, global_ctx, binding_ctx)
		while True:
			try:
				yield next(flex_rigid)
			except StopIteration:
				break
			except RecursionError as e:
				dbp(f"Whoa! There was a recursion error: {e}. Terms were {flat0}, {flat1}")
				input()
				raise e

	if free0 and free1:
		db(f"{flat0}=={flat1} is flex-flex")
		if flat0.head == flat1.head:
			yield z_match(flat0, flat1, global_ctx, binding_ctx)
		else:
			yield z_unif(flat0, flat1, global_ctx, binding_ctx)

def z_match(term1 : FlatTerm, term2 : FlatTerm, ctx : Ctx, bctx : Ctx) -> Unifier:
	if len(term1.arguments) != len(term2.arguments):
		return
	body = FlatTerm([(arg.head, next_fresh_symbol(1)) for arg in term1.arguments], 'zmH' + next_fresh_symbol(), [])
	h_type = Ctx()
	for i in range(len(term1.arguments)):
		if aeq(term1.arguments[i].head, term2.arguments[i].head): # TODO: flattened version of aeq
			body.arguments.append(term1.arguments[i])
			h_type.append((next_fresh_symbol(), next_fresh_symbol(1))) # this should be the type of term1.arguments[i]
	ctx.append((body.head, long_pi(*h_type, next_fresh_symbol(1)))) # this should be x1 -> ... -> tF (whatever that is)
	return Unifier({term1.head : body})

def z_unif(term1 : FlatTerm, term2 : FlatTerm, ctx : Ctx, bctx : Ctx) -> Unifier:
	shared_H = 'zuH' + next_fresh_symbol()
	h_type = Ctx()
	body1 = FlatTerm([(arg.head, next_fresh_symbol(1)) for arg in term1.arguments], shared_H, [])
	body2 = FlatTerm([(arg.head, next_fresh_symbol(1)) for arg in term2.arguments], shared_H, [])
	
	# Intersect the two sets of arguments 
	for arg in term1.arguments:
		for coarg in term2.arguments:
			if arg.head == coarg.head:
				body1.arguments.append(arg)
				body2.arguments.append(arg)
				h_type.append((arg, next_fresh_symbol()))
				break
	
	ctx.append((shared_H, long_pi(*h_type, next_fresh_symbol()))) # this should be z1 -> ... -> tF
	return Unifier({term1.head : body1, term2.head : body2})

