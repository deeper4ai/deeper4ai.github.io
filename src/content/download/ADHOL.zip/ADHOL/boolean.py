from hol import *


def push_negation(formula : Term):
	if is_unary_app(formula, "not"):
		assert isinstance(formula, App)

		if is_unary_app(formula.operand, "not"):
			return push_negation(formula.operand.operand)
		
		elif is_binary_app(formula.operand, "and"):
			lhs = push_negation(NOT(formula.operand.operator.operand))
			rhs = push_negation(NOT(formula.operand.operand))
			return OR(lhs, rhs)
		
		elif is_binary_app(formula.operand, "or"):
			lhs = push_negation(NOT(formula.operand.operator.operand))
			rhs = push_negation(NOT(formula.operand.operand))
			return AND(lhs, rhs)
		
		elif isinstance(formula.operand, All):
			return Ext(formula.operand.var, formula.operand.var_type, push_negation(NOT(formula.operand.body)))
		elif isinstance(formula.operand, Ext):
			return All(formula.operand.var, formula.operand.var_type, push_negation(NOT(formula.operand.body)))
		
		else:
			return formula
	
	elif isinstance(formula, App):
		return App(push_negation(formula.operator), push_negation(formula.operand))
	elif isinstance(formula, (All,Ext)):
		return formula.__class__(formula.var, formula.var_type, push_negation(formula.body))
	else:
		return formula

def eliminate_implication(formula : Term) -> Term:

	debug_elim_impl = 0
	db = lambda s : (not debug_elim_impl) or dbp(s)

	db(f"Eliminating implication in {formula}")
	if is_binary_app(formula, "impl"):
		lhs = formula.operator.operand
		rhs = formula.operand
		return OR(
			NOT(eliminate_implication(lhs)),
			eliminate_implication(rhs)
		)
	elif isinstance(formula, App):
		return App(
			eliminate_implication(formula.operator),
			eliminate_implication(formula.operand)
		)
	elif isinstance(formula, Quantifier):
		return formula.__class__(
			formula.var,
			formula.var_type,
			eliminate_implication(formula.body)
		)
	else:
		return formula

def distribute_repeatedly(formula : Term) -> Term:
	times = 0
	while True:
		formula, changed = distribute(formula)
		if not changed:
			return formula
		else:
			times += 1

def distribute(formula : Term) -> tuple[Term, bool]:
	debug_dist = 0
	db = lambda s : (not debug_dist) or dbp(s)

	if is_binary_app(formula, "or"):
		assert isinstance(formula, App)
		if is_binary_app(formula.operand, "and"):
			assert isinstance(formula.operator, App)
			res = distribute(
				AND(
					OR(copy_term(formula.operator.operand), copy_term(formula.operand.operator.operand)),
					OR(copy_term(formula.operator.operand), copy_term(formula.operand.operand))
				)
			)
			#db(f"			Changed {formula} to {res[0]}")
			return res[0], True
		elif is_binary_app(formula.operator.operand, "and"):
			assert isinstance(formula.operator, App)
			res = distribute(
				AND(
					OR(copy_term(formula.operator.operand.operator.operand), copy_term(formula.operand)),
					OR(copy_term(formula.operator.operand.operand), copy_term(formula.operand))
				)
			)
			#db(f"			Changed {formula} to {res[0]}")
			return res[0], True
	if isinstance(formula, App):
		lhs = distribute(formula.operator)
		rhs = distribute(formula.operand)
		return App(lhs[0], rhs[0]), lhs[1] or rhs[1]
	if isinstance(formula, Quantifier):
		body, changed = distribute(formula.body)
		#db(f"Quantifier, changed; is {body}")
		return formula.__class__(
			formula.var, formula.var_type, body
		), changed
	
	return formula, False


def skolemise(formula : Term, sig : Sig, context : Ctx, universal_bindings : Ctx, recursion : int = 0) -> tuple[Term, Ctx]:
	# Note that this procedure is not YET sound with respect to Henkin semantics. See Benzmuller (1998)
	debug_skolem = 0
	db = lambda s : (not debug_skolem) or print(recursion*'\t' + str(s))
	db(f"Skolemising {formula}...")

	if isinstance(formula, (Ext, )):
		db(f"Formula = {formula.body}, var = {formula.var}, type = {formula.var_type}")
		ct = copy_term(formula.body)
		skolem_term = ""
		skolem_symbol = ""
		skolem_symbol_type = ""

		if len(universal_bindings) == 0:
			skolem_symbol_type = formula.var_type
			skolem_symbol = sig.next_constf() if isinstance(skolem_symbol_type, Pi) else sig.next_const()
			skolem_term = skolem_symbol
		else:
			skolem_symbol = sig.next_constf()
			skolem_term = long_app(skolem_symbol, *[u[0] for u in universal_bindings])
			skolem_symbol_type = long_pi(*universal_bindings, formula.var_type)
			db(f"Skolem term was {skolem_term}, Skolem symbol type was {skolem_symbol_type}, universal_bindings was {universal_bindings}")

		sig.constants[skolem_symbol] = skolem_symbol_type
		sig.replace_in_equalities(formula.var, skolem_term)
		db(f"Added existential skolem term {skolem_term} with type {skolem_symbol_type} for {formula.var}")
		for ctx in (context, universal_bindings):
			for i in range(len(ctx)):
				ctx[i] = (ctx[i][0], substituted(formula.var, skolem_term, ctx[i][1]))
		
		ct = substituted(formula.var, skolem_term, ct)
		if formula.var == "B22":
			print(f"CT (substituted) = {ct}")
		sk = skolemise(ct, sig, context, universal_bindings,  recursion + 1)
		#sig.constants[formula.var] = skolem_symbol_type

		return sk
	
	elif isinstance(formula, All):
		db(f"ALL had var {formula.var} with type {formula.var_type}")
		forall_var = formula.var
		formula.body = substituted(formula.var, forall_var, formula.body)
		formula.var_type = substituted(formula.var, forall_var, formula.var_type)
		context.append((forall_var, formula.var_type))
		skolemised = skolemise(formula.body, sig, context, universal_bindings + [(forall_var, formula.var_type)], recursion + 1)

		db(f"Added universally qfd symbol {forall_var} to ctx with type {formula.var_type}")
		return skolemised
	
	elif isinstance(formula, Quantifier):
		generic_qf_var = sig.next_bound()
		sk = formula.__class__(
			generic_qf_var, skolemise(formula.var_type, sig, context, universal_bindings, recursion+1), 
			skolemise(substituted(formula.var, generic_qf_var, formula.body), sig, context, universal_bindings, recursion + 1)
		)
		return sk
	
	elif isinstance(formula, App):
		oper = skolemise(formula.operator, sig, context, universal_bindings, recursion + 1)
		opnd = skolemise(formula.operand, sig, context, universal_bindings, recursion + 1)
		return App(oper, opnd)
	else:
		return formula
		

def _to_cnf(formula : Term) -> CNF:
	# Assumes everything has already been distributed
	if is_binary_app(formula, "or"):
		return CNF([to_clause(formula)])
	elif is_binary_app(formula, "and"):
		assert isinstance(formula, App)
		assert isinstance(formula.operator, App)
		return CNF(_to_cnf(formula.operator.operand) + _to_cnf(formula.operand))
	else:
		return CNF([to_clause(formula)])
	

def to_clause(or_expression : Term) -> Clause:
	debug_clausify = 0
	db = lambda s : (not debug_clausify) or dbp(s)

	#db(f"{or_expression} clausifying.........................")
	if isinstance(or_expression, str):
		#db(f"{or_expression}: is a string, turning into literal")
		return Clause([Literal(or_expression, True)])
	elif isinstance(or_expression, Abs):
		#db(f"{or_expression}: is Abs, turning into literal despite ill-typedness")
		return Clause([Literal(or_expression, True)])
	elif is_unary_app(or_expression, "not"):
		assert isinstance(or_expression, App)
		#db(f"{or_expression}: not, turning into negated literal")
		return Clause([Literal(or_expression.operand, False)])
	elif (isinstance(or_expression, App) and not (isinstance(or_expression.operator, App) and or_expression.operator.operator == "or")):
		#db(f"{or_expression}: is other kind of App (operator={or_expression.operator}), turning into literal...")
		return Clause([Literal(or_expression, True)])

	assert isinstance(or_expression, App), or_expression
	rhs = or_expression.operand
	if isinstance(or_expression.operator, str):
		#db(f"{or_expression}: str application, turning into literal")
		return Clause([Literal(or_expression, True)])

	assert isinstance(or_expression.operator, App)
	lhs = or_expression.operator.operand
	if is_unary_app(lhs, "not"):
		assert isinstance(lhs, App)
		#db(f"{or_expression}: LHS is NOT, ...")
		return Clause(to_clause(rhs) + [Literal(lhs.operand, False)])

	if is_binary_app(lhs, "or"):
		assert isinstance(lhs, App)
		assert isinstance(lhs.operator, App)
		#db(f"{or_expression}: LHS is applied OR, ret={Clause(to_clause(lhs.operator.operand) + to_clause(lhs.operand) + to_clause(rhs))}")
		return Clause(to_clause(lhs.operator.operand) + to_clause(lhs.operand) + to_clause(rhs))
	if isinstance(lhs, Term) or isinstance(lhs, str):
		#db(f"{or_expression}: LHS {lhs} is some other term or string, ret={Clause(to_clause(rhs) + [Literal(lhs, True)])}")
		return Clause(to_clause(rhs) + [Literal(lhs, True)])
	#db(f"{or_expression}: unknown, returning empty clause")
	return Clause([])



def leibnizify(ctx : Ctx, sig : Sig, term : Term) -> None:
	if isinstance(term, App) and isinstance(term.operator, App) and is_eq(term):
		eqt = sig.type_for_equality_symbol(term.operator.operator)
		leib = sig.next_leib()
		term.operator.operator = Abs("lzX", eqt, Abs("lzY", eqt, All(leib, Pi(sig.next_bound(), eqt, "bool"), IMPL(App(leib, "lzX"), App(leib, "lzY"))))) 
		leibnizify(ctx, sig, term.operator.operand)
		leibnizify(ctx, sig, term.operand)
	elif isinstance(term, App):
		leibnizify(ctx, sig, term.operator)
		leibnizify(ctx, sig, term.operand)
	elif isinstance(term, Quantifier):
		leibnizify(ctx, sig, term.body)


def cnf_convert(context : Ctx, sig : Sig, t : Term) -> CNF:
	#leibnizify(context, sig, t)
	#print(f"Context before CNF conversion was {context}")
	return _to_cnf(distribute_repeatedly(skolemise(push_negation(eliminate_implication(beta_reduce_repeatedly(copy_term(t)))), sig, context, [])))

